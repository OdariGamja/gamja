#include "game.h"
#include <SDL2/SDL.h> 
#include <SDL2/SDL_mixer.h>
#include <stdio.h>



Mix_Chunk *lobbyBGM = NULL;
Mix_Chunk *IngameBGM = NULL;


//lobby
Mix_Chunk *PressStart = NULL;
Mix_Chunk *Connect = NULL;
Mix_Chunk *FadeInOut = NULL;
Mix_Chunk *Start = NULL;


//Ingame
Mix_Chunk *Attack = NULL;
Mix_Chunk *KnockDown = NULL;
Mix_Chunk *Coin = NULL;
Mix_Chunk *Atm = NULL;
Mix_Chunk *BlackOut = NULL;
Mix_Chunk *Throw = NULL;
Mix_Chunk *Fall = NULL;
Mix_Chunk *RaiseUp = NULL;
Mix_Chunk *Die = NULL;

//train
Mix_Chunk *UpTrain = NULL;
Mix_Chunk *DownTrain = NULL;
Mix_Chunk *HitbyTrain = NULL;
Mix_Chunk *Announce = NULL;
Mix_Chunk *Shinkansen = NULL;
Mix_Chunk *PinPon = NULL;




void InitSound (void){

    // オーディオデバイスの初期化
    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT, 2, 1024) < 0) {
        printf("ローディング失敗 SDL_mixer.\n");
        SDL_Quit();
        exit(-1);
    }

    Mix_AllocateChannels(16);
    //chunk

    PressStart = Mix_LoadWAV("sound/run.mp3");
    if (!PressStart) {
        printf("run.mp3ローディング失敗: %s\n", Mix_GetError());
    }










}