#include<SDL2/SDL_mixer.h>
#include<stdio.h>
#include<stdlib.h>
#include"game.h"

extern int my_id;
extern CharaInfo *gCharaHead;

void InitSound(void)//0124追加
{
    if(SDL_Init(SDL_INIT_AUDIO) < 0){
        PrintError("failed to SDL_Init\n");
        return;
    }

    if(Mix_Init(MIX_INIT_MP3) == 0){
        PrintError("failed to Mix_Init\n");
        return;
    }

    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT, 2, 1024) == -1){
        PrintError("failed to Mix_OpenAudio\n");
        return;
    }

    return;
} 

typedef enum{
    SE_Attack,
    SE_Throw,
    SE_KnockDown,
    SE_Spin,
    SE_TrainMove,
    SE_TrainDoor,
    SE_ATMShake,
    SE_CointoVendor,
    
} SE_Type;



//効果音の読み込み（クライアント）
void InitSound_Load(GameInfo *gGame){
    gGame->SE_Load[SE_Attack] = Mix_LoadWAV("sound/player/piko.wav");
    gGame->SE_Load[SE_Throw] = Mix_LoadWAV("sound/player/Motion-Swish06-1.wav");
    gGame->SE_Load[SE_KnockDown] = Mix_LoadWAV("sound/player/dizze.wav");
    gGame->SE_Load[SE_Spin] = Mix_LoadWAV("sound/player/big-explosion-1.wav");
    gGame->SE_Load[SE_TrainMove] = Mix_LoadWAV("sound/Trains/train01.wav");
    gGame->SE_Load[SE_TrainDoor] = Mix_LoadWAV("sound/Trains/traindoor.wav");
    gGame->SE_Load[SE_ATMShake] = Mix_LoadWAV("sound/CoinATMVendor/moneyjarajara.wav");
    gGame->SE_Load[SE_CointoVendor] = Mix_LoadWAV("sound/CoinATMVendor/coin_get_01_high.wav");
}

//===================================================
//キャラクタのmovesttsの値が変わると効果音を再生する
//===================================================
void PlaySound(GameInfo *gGame){
    CharaInfo *myplayer = GetPlayerChara(my_id);//自分の情報

    for(CharaInfo *ch = gCharaHead; ch; ch = ch->next){
        
        //前の状態と同じなら再生しない
        if( ch->movestts == ch->audio_state.beforeMovestts)
            continue;
        //if(ch->type == CT_COIN && CT_PLAYER0 <= ch->type && ch->type <= CT_PLAYER3)
        //    continue;

    //==============
    //再生する場合
    //=============
        //再生されている効果音を止める
        //if(ch->type != CT_ATM){
            if(ch->audio_state.chanel != -1){//再生されている場合
                Mix_HaltChannel(ch->audio_state.chanel);
                ch->audio_state.chanel = -1;
            }
        //}

        int kindofSE = GetSE_Type(ch);

        //対応する効果音があれば再生する
        if(kindofSE != -1){
            //一回のみ再生
            if(kindofSE == SE_Spin || kindofSE == SE_ATMShake || kindofSE == SE_CointoVendor || kindofSE == SE_TrainDoor){
            //    if(ch->audio_state.chanel < 0)//再生中は鳴らさない
                ch->audio_state.chanel = Mix_PlayChannel(-1, gGame->SE_Load[kindofSE], 0);
            }
            else{//繰り返し再生
                ch->audio_state.chanel = Mix_PlayChannel(-1, gGame->SE_Load[kindofSE], -1);
            }
        }


        //現在のmovesttsを保存
        ch->audio_state.beforeMovestts = ch->movestts;
        ch->audio_state.beforeStts = ch->stts;
        
        //距離に応じた音量の調整
        UpdateVolume(myplayer,ch);
    }
}

//===============================
//movesttsに対応する効果音を返す
//===============================
int GetSE_Type(CharaInfo *ch){
    switch(ch->movestts){
            case ANI_RightAttack:
            case ANI_LeftAttack:
            case ANI_DownAttack:
            case ANI_UpAttack:
                return SE_Attack;
                break;
            //case ANI_TrainDoorCLOSE:
            case ANI_TrainDoorOPEN:
                return SE_TrainDoor;
                break;
            case ANI_ATM_LIGHTOFF_VIBRATE:
                return SE_ATMShake;
                break;
            case ANI_VENDER_PUMP:
                return SE_CointoVendor;
                break;
            case ANI_HIT_RIGHT:
            case ANI_HIT_LEFT:
            case ANI_HIT_DOWN:
            case ANI_HIT_UP:
                return -1;
                break;
            case ANI_KNOCKDOWN:
                return SE_KnockDown;
                break;
            case ANI_RAISE_RIGHT:
            case ANI_RAISE_LEFT:
            case ANI_RAISE_DOWN:
            case ANI_RAISE_UP:
                break;
            case ANI_SPIN:
                return SE_Spin;
                break;
            default:
                break;
            }

    switch(ch->stts){
        case CS_Fly:
            return SE_Throw;
            break;
        default:
            break;

    }



    //電車の効果音
    if(ch->type == CT_TRAIN){//奥の電車
        if(ch->movestts == ANI_TrainDoorCLOSE && (0 < ch->point.x + 7500 || ch->point.x < MAP_Width))//電車の座標がホーム内かつ扉が閉まっている
            return SE_TrainMove;
    }
    if(ch->type == CT_TRAIN_PASS){//手前の電車
        if(ch->movestts == ANI_TrainDoorCLOSE && (0 < ch->point.x + 7500 || ch->point.x < MAP_Width))//電車の座標がホーム内かつ扉が閉まっている
            return SE_TrainMove;
    }
    return -1;
}

//=================================================
//操作プレイヤーと音源の距離に応じて音量を調整する
//=================================================
#define MAXDistance 1920 //全画面表示のときの画面端まで

void UpdateVolume(CharaInfo *myplayer, CharaInfo *sound_sorce)
{

    //再生していない場合
    if(sound_sorce->audio_state.chanel == -1)
        return;

//距離に応じて音量を調整する

    //電車と自分は常に最大音量
    if(sound_sorce->type == CT_TRAIN || sound_sorce == myplayer){
        Mix_Volume(sound_sorce->audio_state.chanel, MIX_MAX_VOLUME);
        return;
    }


    //音源と自分の距離を計算（x軸のみ）
    float d_x = myplayer->point.x - sound_sorce->point.x;
    float distance = fabsf(d_x);//絶対値

    float scale = 1.0f - distance / MAXDistance;
    if(scale < 0)
        scale = 0;


    int SoundVolume = (int)(MIX_MAX_VOLUME *scale);

    Mix_Volume(sound_sorce->audio_state.chanel, SoundVolume);//距離に応じた音量に設定
} 


void CloseSound(void){

    Mix_CloseAudio();
    Mix_Quit();
}


//SoundInfoの初期化（サーバ）
//void InitSoundInfo(GameInfo *gGame){
    //全部0で初期化
//    for(int i = 0; i < MAX_SE_NUMBER; i++){
//        gGame->SE_Info[i].PlayerID = 0;//初期化できてないかも
//       gGame->SE_Info[i].x = 0;
//    }
    //動かないやつの座標を代入
//    for(CharaInfo *ch = ServergCharaHead; ch; ch->next){
//        switch(ch->type){
//            case CT_ATM:
//                gGame->SE_Info[ATM_Shake].x = ch->point.x;
//                break;
//            case CT_Vendor:
//                gGame->SE_Info[CointoVendor].x = ch->point.x;
//                break;
//        }
//    }
//}

//扱いやすいように関数化しました(サーバで使いたい)
//void PlaySound_Server(GameInfo *gGame, int event, int playerID){ //引数：イベント、なるやつ、myid
//gGame->SE_Info[event].PlayerID = playerID;

//動くやつ
 /*   for(CharaInfo *ch = ServergCharaHead; ch; ch->next){
        switch(ch->type){
            case CT_TRAIN:
                gGame->SE_Info[Train_Moving].x = ch->point.x;
                gGame->SE_Info[Train_Door].x = ch->point.x;
                break;

            case CT_IMG:
                gGame->SE_Info[Shinkansen_Moving].x = ch->point.x;
                break; 
            case CT_Lever:
                gGame->SE_Info[EmergencyButton].x = ch->point.x;
                break;
            default:
            break;
        }
               
    }

}*/



//効果音を鳴らす（クライアント）
//#define MAXDistance 1920 / 2 //全画面表示のときの画面端まで
//void PlaySound_Client(GameInfo *gGame, SoundInfo *SE_Info){

//    CharaInfo *myplayer = GetPlayerChara(my_id);//自分の情報

//空いているチャンネルを取得
//    int ChunkChunel = Mix_PlayChannel(-1, gGame->SE_Load[SE_Info->event], 0);
//    if(ChunkChunel == -1) return;

//音と自分の距離を計算（x軸のみ）
//    float d_x = myplayer->point.x - SE_Info->x;
//    float distance = abs(d_x);//絶対値

//距離に応じて音量を調整する
//    float scale = 1.0f - distance / MAXDistance;
//    if(scale < 0)
//        scale = 0;

//    int SoundVolume = (int)(MIX_MAX_VOLUME *scale);

//自分の音は最大
//    if(SE_Info->playerID == my_id)
//        SoundVolume = MIX_MAX_VOLUME;//音源の最大音量

//    Mix_Volume(ChunkChunel ,SoundVolume);//距離に応じた音量に設定
//}
