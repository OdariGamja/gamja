//server.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include "game.h"

#define SERVER_PORT 5000
#define MAX_CLIENT 4

int client_sock[MAX_CLIENT];

CharaInfo players[CHARATYPE_NUM];

void* ClientThread(void* arg) {
    int id = *(int*)arg;
    free(arg);
    while (1) {
        Keystts input;
        int r = read(client_sock[id], &input, sizeof(input));
        if (r <= 0) break;

        // 입력이 있을 때만 출력 debug
        if (input.up || input.down || input.left || input.right) {
            printf("Client %d input: up=%d down=%d left=%d right=%d\n",
                   id, input.up, input.down, input.left, input.right);
        }

        // 입력 반영
        if (input.up) players[id].point.y -= MOVE_SPEED;
        if (input.down) players[id].point.y += MOVE_SPEED;
        if (input.left) players[id].point.x -= MOVE_SPEED;
        if (input.right) players[id].point.x += MOVE_SPEED;

        // 전체 브로드캐스트
        for (int i = 0; i < MAX_CLIENT; i++)
            if (client_sock[i] != -1){
                ssize_t ret = write(client_sock[i], players, sizeof(players));
                if (ret < 0) perror("write failed");
            } 
    }
    close(client_sock[id]);
    client_sock[id] = -1;
    return NULL;
}

int main() {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(SERVER_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    bind(sockfd, (struct sockaddr*)&addr, sizeof(addr));
    listen(sockfd, MAX_CLIENT);

    for (int i = 0; i < MAX_CLIENT; i++) client_sock[i] = -1;

    printf("Server listening on port %d\n", SERVER_PORT);
    while (1) {
        int csock = accept(sockfd, NULL, NULL);
        int id = -1;
        for (int i = 0; i < MAX_CLIENT; i++) {
            if (client_sock[i] == -1) { client_sock[i] = csock; id = i; break; }
        }
        if (id != -1) {
            pthread_t th;
            int* pid = malloc(sizeof(int));
            *pid = id;
            pthread_create(&th, NULL, ClientThread, pid);
        } else {
            close(csock);
        }
    }
    return 0;
}
