#ifndef GAME_H
#define GAME_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>

#define WD_Width 1980
#define WD_Height 1080
#define MAP_Width 5640
#define MAP_Height 3204
#define CAMERA_W 1485
#define CAMERA_H 810
#define MAX_NPC 30
#define MAX_PATH 256
#define MAX_LINEBUF 256
#define MAX_PLAYERLEVEL 5
#define MAX_BLOODPRESSURE 511
#define DANCE_CHANNEL 1
#define KNOCK_CHANNEL 2
#define WALK_CHANNEL 3
#define MANHOLE_CHANNEL 4
#define GAMEOVER_CHANNEL 5
#define SLAP_CHANNEL 6
#define CLEAR_CHANNEL 7
#define WHOOP_CHANNEL 8
#define SHUT_CHANNEL 9
#define SURPRISE_CHANNEL 10
typedef struct CharaInfo_t CharaInfo;

/* キャラクタータイプ */
typedef enum {
    CT_Manhole        = 0,
    CT_Tree           = 1,
    CT_Buliding1      = 2,
    CT_Buliding2      = 3,
    CT_Buliding3      = 4,
    CT_PoliceStation  = 5,
    CT_Church         = 6,
    CT_Door           = 7,
    CT_Player         = 8,
    CT_Villiger       = 9,
    CT_Yakuza         = 10,
    CT_Jesus          = 11,
    CT_Police         = 12,
    CT_Car            = 13,
    CT_Cross          = 14
} CharaType;
#define CHARATYPE_NUM 15


/* キャラクタータイプ別情報 */
typedef struct {
    int w, h;
    char* path;
    SDL_Point aninum; 
    SDL_Texture* img;
} CharaTypeInfo;


/* キャラクターの状態 */
typedef enum {
    CS_Normal = 0,
    CS_Chase = 1,
    CS_Disable = 2, 
    CS_BackHome = 3,
    CS_Dance = 4
} CharaStts;

/*ドアの状態*/
typedef enum {
    DOOR_Closed,
    DOOR_Ringed,
    DOOR_Opened
} DoorStts;

/*マンホールの状態*/
typedef enum {
    Manhole_Closed,
    Manhole_Opened
} ManholeStts;

/*キャラクタアニメーション状態*/
typedef enum {
    ANI_Stop = 0,
    ANI_RunRight = 1,
    ANI_RunLeft = 2,
    ANI_RunDown = 3,
    ANI_RunUp = 4,
    ANI_Ringthebell = 5,
    ANI_InOut_Manhole = 6,
    ANI_Dance = 7,
    ANI_Throw_Left = 8,
    ANI_Throw_Right = 9
} CharaMoveStts;

/*マンホール出入り方向*/
typedef enum {
    MANHOLE_None = 0,
    MANHOLE_Enter,
    MANHOLE_Exit
} ManholeDirection;

/* キャラクターの情報 */
typedef struct CharaInfo_t {
    CharaStts stts;
    int exp;
    int level;
    DoorStts doorstts; 
    ManholeStts manholestts;
    ManholeDirection manholeDir;
    SDL_bool ringing;
    Uint32 ringStartTime;
    CharaMoveStts Movestts;
    CharaType type;
    CharaTypeInfo* entity;
    SDL_Rect rect;
    SDL_Rect imgsrc;
    int dir;
    SDL_FPoint vel;
    SDL_FPoint point;
    SDL_Point ani;  
    struct CharaInfo_t* next;
    CharaInfo* Doorfrom;
    Uint32 jesusBornTime;
} CharaInfo;    

/* キー入力の状態 */
typedef struct {
    SDL_bool right;
    SDL_bool left;
    SDL_bool down;
    SDL_bool up;
    SDL_bool space;
} Keystts;

/* ゲームの状態 */
typedef enum {
    GS_Ready = 0,
    GS_Playing = 1,
    GS_End = 2,
    GS_GameOver = 3,
    GS_Clear = 4,
    GS_YakuzaScene = 5
} GameStts;

/* ゲームの情報 */
typedef struct {
    CharaInfo* player;
    GameStts stts;
    SDL_Window* window;
    SDL_Renderer* render;
    SDL_Texture* bg;
    SDL_Texture* UI_Exp[MAX_PLAYERLEVEL];
    SDL_Texture* UI_BloodPressure;
    SDL_Point dp;
    Keystts input;
    float timeDelta;
} GameInfo;

/* グローバル変数 */
extern GameInfo gGame;
extern CharaTypeInfo gCharaType[CHARATYPE_NUM];
extern CharaInfo* gCharaHead;
extern char gImgFilePath[CHARATYPE_NUM][MAX_PATH];
extern int InfrontOfTheDoor;
extern int OnTheManhole;
extern SDL_Rect CurrentManhole;
extern SDL_Rect CurrentDoor;
extern int availableNpcCount;
extern float BloodPressure;
extern int gStartMenuFrame;
extern int JesusShootCross;
extern SDL_bool isChaseMusicPlaying ;
extern SDL_bool isGameoverSoundPlayed;
extern SDL_bool isSlapSoundPlayed;
extern SDL_TimerID timerID;
extern SDL_TimerID expTimerID;
extern SDL_TimerID UpdateNPCTimerID;
extern int YakuzaScene ;
extern Uint32 currentTime ;
extern Uint32 startTime; 

// 音楽関連変数
extern Mix_Music *music;    
extern Mix_Music *chaseMusic; 

// 効果音関連変数
extern Mix_Chunk *knockChunk;
extern Mix_Chunk *runChunk;
extern Mix_Chunk *ManholeChunk;
extern Mix_Chunk *GameoverChunk;
extern Mix_Chunk *SlapChunk;
extern Mix_Chunk *DanceChunk; 
extern Mix_Chunk *ClearChunk;
extern Mix_Chunk *WhoopChunk;
extern Mix_Chunk *ShutChunk;
extern Mix_Chunk *SurpriseChunk; 

/*グローバル関数*/
extern int InitWindow(const char* bg_file);
extern void InitCharaInfo(CharaInfo* ch);
extern int InitSystem(const char* chara_data_file,const char* position_data_file);
extern void RenderWindow(void);
extern void DestroyWindow(void);
extern void DestroySystem(void);
extern int PrintError(const char* msg);
extern void MoveChara(CharaInfo* ch);
extern void UpdateCharaterInfo(CharaInfo* ch);
extern void AnimateHuman(CharaInfo* ch);
extern void AnimateDoor(CharaInfo* ch);
extern void AnimateManhole(CharaInfo* ch);
extern SDL_bool Collision(CharaInfo* ci, CharaInfo* cj);
extern CharaInfo* NpcAppear(SDL_Rect door_rect);
extern CharaInfo* availableNpc[MAX_NPC];
extern void InitMapData(void);
extern void Chase(CharaInfo* npc, CharaInfo* player);
extern void GoBackHome(CharaInfo* npc, SDL_Rect* home);
extern void CalculateExp_BloodPressure(CharaInfo* ch);
extern void RenderScene(CharaInfo* ch);
extern void UpdateNPC(void);
extern int ShowRestart(int selectedIndex);
extern void ShowClear(void);    
extern void StartMenu(int selectedIndex);
extern void YakuzaAppear(void);

#endif 