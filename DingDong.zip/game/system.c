#include "game.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINEBUF 256

// 補正の方向
typedef enum {
    AD_LR,  // 左右
    AD_UD,  // 上下
    AD_NONE // 補正してないlast_dir
} AdjustDir;

GameInfo gGame;
CharaInfo* gCharaHead = NULL;               // キャラクターリストヘッド
CharaTypeInfo gCharaType[CHARATYPE_NUM];   // キャラクタータイプ別情報
char gImgFilePath[CHARATYPE_NUM][MAX_PATH]; // 画像ファイルパス保存用
SDL_Rect CurrentManhole;  //マンホールの位置保存用
SDL_Rect CurrentDoor; //ドアの位置保存用
CharaInfo* availableNpc[MAX_NPC];//npcの格納構造体
int InfrontOfTheDoor = 0;//ドアの前にあるかどうかを識別する変数
int OnTheManhole = 0;//マンホールの前にあるかどうかを識別する変数
int availableNpcCount = 0;
float BloodPressure = 0;//血圧
SDL_bool isChaseMusicPlaying = SDL_FALSE;
void UpdateNPC(void);

int PrintError(const char* msg) {
    fprintf(stderr, "Error: %s\n", msg);
    return -1;
}

//システム初期化
int InitSystem(const char* chara_data_file, const char* position_data_file)
{
    int ret = 0;

    //キャラクタタイプ別情報読み込む
    FILE* fp = fopen(chara_data_file, "r");
    if (fp == NULL) {
        return PrintError("failed to open chara data file.");
    }
    int typeno = 0;
    char linebuf[MAX_LINEBUF];
    while (fgets(linebuf, MAX_LINEBUF, fp)) {
        if (linebuf[0] == '#') continue; 

        if (typeno < CHARATYPE_NUM) {
            if (3 != sscanf(linebuf, "%d%d%s",
                            &(gCharaType[typeno].w),
                            &(gCharaType[typeno].h),
                            gImgFilePath[typeno])) {
                ret = PrintError("failed to read the chara image data.");
                goto CLOSEFILE_CHARA;
            }
            gCharaType[typeno].path = gImgFilePath[typeno];
            typeno++;
        }
    }
CLOSEFILE_CHARA:
    fclose(fp);
    if (ret < 0) return ret;

    //キャラクタ位置及び情報読み込み
    fp = fopen(position_data_file, "r");
    if (fp == NULL) {
        return PrintError("failed to open position data file.");
    }

    while (fgets(linebuf, MAX_LINEBUF, fp)) {
        if (linebuf[0] == '#') continue;

        CharaInfo* ch = (CharaInfo*)malloc(sizeof(CharaInfo));
        if (!ch) {
            ret = PrintError("failed to allocate the chara data.");
            goto CLOSEFILE_POSITION;
        }

        ch->next = gCharaHead;
        gCharaHead = ch;

        if (7 != sscanf(linebuf, "%u%f%f%d%d%d%d",
                        (unsigned int*)&(ch->type),
                        &(ch->point.x),
                        &(ch->point.y),
                        &(ch->rect.x),
                        &(ch->rect.y),
                        &(ch->rect.w),
                        &(ch->rect.h))) {
            ret = PrintError("failed to load position data.");
            goto CLOSEFILE_POSITION;
        }

        if (ch->type >= CHARATYPE_NUM) {
    PrintError("Invalid character type.");
    continue;
}
        ch->entity = &gCharaType[ch->type];
        InitCharaInfo(ch);
    }

    if (gGame.player == NULL) {
    PrintError("Player 초기화 실패 (gGame.player == NULL)");
    return -1;
}

CLOSEFILE_POSITION:
    fclose(fp);

InitMapData();

    return ret;
}


//キャラクタ情報初期化
void InitCharaInfo(CharaInfo* ch)
{
    if (!ch) return;

    ch->entity = &gCharaType[ch->type];
    ch->stts = CS_Normal;
    ch->dir = 1;
    ch->vel.x = 0;
    ch->vel.y = 0;
    ch->point.x = (int)ch->point.x;
    ch->point.y = (int)ch->point.y;
    ch->ani.x = 0;
    ch->Doorfrom = NULL;
    ch->Movestts = ANI_Stop;

    ch->rect.w = ch->entity->w;
    ch->rect.h = ch->entity->h;
    ch->rect.x = (int)ch->point.x;
    ch->rect.y = (int)ch->point.y;

    ch->imgsrc.x = 0;
    ch->imgsrc.y = 0;
    ch->imgsrc.w = ch->entity->w;
    ch->imgsrc.h = ch->entity->h;

    // タイプ別初期化
    switch (ch->type) {
        case CT_Player:
            gGame.player = ch;
            ch->exp = 0;
            ch->level = 1;
            ch->ringing = SDL_FALSE;
            ch->ringStartTime = 0;
            break;

        case CT_Door:
            ch->doorstts = DOOR_Closed;
            break;

        case CT_Car:
            ch->vel.y = 500;
            break;

        case CT_Yakuza:
            ch->vel.x = 50;
            ch->vel.y = 50;
            ch->imgsrc.w = 32;
            ch->imgsrc.h = 64;
            break;

        case CT_Cross:
            ch->stts = CS_Disable;
            ch->vel.x = 500;
            ch->vel.y = 500;
            ch->entity->w = 200;
            ch->entity->h = 200;
            break;

        case CT_Jesus:
            ch->entity->w = 200;
            ch->entity->h = 240;
            break;

        default:
            break;
    }

    // 建物ではない場合
    if (ch->type != CT_Buliding1 && ch->type != CT_Buliding2 &&
        ch->type != CT_Buliding3 && ch->type != CT_PoliceStation && ch->type != CT_Church) {
        ch->rect.w = ch->entity->w;
        ch->rect.h = ch->entity->h;
        ch->imgsrc.w = ch->entity->w;
        ch->imgsrc.h = ch->entity->h;
    }

    // 建物はあたり判定位置補正
    if (ch->type == CT_Buliding1 || ch->type == CT_Buliding2 ||
        ch->type == CT_Buliding3 || ch->type == CT_PoliceStation || ch->type == CT_Church) {
        ch->rect.y -= 10;
    }

    // NPC登録
    if (ch->type == CT_Villiger || ch->type == CT_Police ||
        ch->type == CT_Jesus   || ch->type == CT_Yakuza) {

        ch->stts = CS_Disable;

        if (availableNpcCount >= MAX_NPC) {
           printf("NPC 登録失敗\n");
        } else {
            availableNpc[availableNpcCount++] = ch;
        }
    }
}

//当たり判定補正
AdjustDir AdjustPoint(CharaInfo* cadj, CharaInfo* cfix, SDL_Rect* rt)
{
    AdjustDir ret = AD_NONE;
    /* 判定が不要な組み合わせを除外 */
    if (cadj->stts == CS_Disable || cfix->stts == CS_Disable)
        return ret;

    // 補正する方向を決める
    // 側面を全て含むときはその方   
    if (rt->w == cadj->rect.w)
        ret = AD_UD;
    else if (rt->h == cadj->rect.h)
        ret = AD_LR;
    // 一部を含むときは短い方
    else if (rt->w > rt->h)
        ret = AD_UD;
    else if (rt->w < rt->h)
        ret = AD_LR;
    // 縦横同じときは速度の大きい方
    else if (fabsf(cadj->vel.x) > fabsf(cadj->vel.y))
        ret = AD_LR;
    else
        ret = AD_UD;

    /* 補正 */
    if (ret == AD_LR) { // x方向
        int dx = cadj->rect.x - (int)(cadj->point.x);
        cadj->point.x += (cadj->rect.x == rt->x) ? rt->w : -rt->w;
        cadj->rect.x = cadj->point.x + dx;

    } else { // y方向
        int dy = cadj->rect.y - (int)(cadj->point.y);
        cadj->point.y += (cadj->rect.y == rt->y) ? rt->h : -rt->h;
        cadj->rect.y = cadj->point.y + dy;
    }
    return ret;
}

//キャラクタstts管理
void UpdateCharaterInfo(CharaInfo* ch)
{
    if (ch->type != CT_Player) return;

    Uint32 now = SDL_GetTicks();

    // ===== マンホール進入 =====
    if (gGame.input.space && OnTheManhole && ch->Movestts != ANI_InOut_Manhole && 
    (ch->stts == CS_Normal || ch->stts == CS_Disable)){
        
        // 効果音
        if (ManholeChunk) {
            Mix_PlayChannel(MANHOLE_CHANNEL, ManholeChunk, 0);
        }
        ch->Movestts = ANI_InOut_Manhole;
        ch->manholeDir = MANHOLE_Enter;
        ch->ani.x = 0; 
        gGame.input.space = SDL_FALSE;

        ch->point.x = CurrentManhole.x + 15;
        ch->point.y = CurrentManhole.y - 50;

        for (CharaInfo* c = gCharaHead; c; c = c->next) {
            if (c->type == CT_Manhole && 
                c->rect.x == CurrentManhole.x && 
                c->rect.y == CurrentManhole.y) {
                c->manholestts = Manhole_Opened;
            }
        }
        
    }

    // ===== マンホールから出る =====
    if (gGame.input.space && ch->Movestts != ANI_InOut_Manhole && ch->stts == CS_Disable) {
        // 効果音
        if (ManholeChunk) {
            Mix_PlayChannel(MANHOLE_CHANNEL, ManholeChunk, 0);
        }
        ch->Movestts = ANI_InOut_Manhole;
        ch->manholeDir = MANHOLE_Exit;
        ch->ani.x = 0; 
        gGame.input.space = SDL_FALSE;

        for (CharaInfo* c = gCharaHead; c; c = c->next) {
            if (c->type == CT_Manhole &&
                c->rect.x == CurrentManhole.x &&
                c->rect.y == CurrentManhole.y) {
                c->manholestts = Manhole_Opened;
            }
        }
    }

    // ===== ドアをノック =====
    if (gGame.input.space && InfrontOfTheDoor && ch->Movestts != ANI_Ringthebell && !ch->ringing) {
        ch->Movestts = ANI_Ringthebell;
        ch->ringStartTime = now;
        ch->ringing = SDL_TRUE;
        gGame.input.space = SDL_FALSE;

        for (CharaInfo* c = gCharaHead; c; c = c->next) {
            if (c->type == CT_Door &&
                c->rect.x == CurrentDoor.x &&
                c->rect.y == CurrentDoor.y) {
                c->doorstts = DOOR_Ringed;
                c->ringStartTime = now;
            }
        }
        // 効果音
        if (knockChunk) {
            Mix_PlayChannel(KNOCK_CHANNEL, knockChunk, 0);
        }
        return;
    }

    // =====　ノックのアニメーション終了 =====
    if (ch->ringing && ch->Movestts == ANI_Ringthebell && now - ch->ringStartTime >= 500) {
        ch->Movestts = ANI_Stop;
        ch->ringing = SDL_FALSE;
    }

    // ===== ドアの状態復元 =====
    for (CharaInfo* c = gCharaHead; c; c = c->next) {
        if (c->type == CT_Door) {
            if (c->doorstts == DOOR_Ringed && now - c->ringStartTime >= 500) {
                c->doorstts = DOOR_Opened;
                c->ringStartTime = now;
            } else if (c->doorstts == DOOR_Opened && now - c->ringStartTime >= 1500) {
                c->doorstts = DOOR_Closed;
                
                NpcAppear(c->rect);
            }
        }
    }

    // マンホールの出入りが終わったら蓋を閉める
    if (ch->stts == CS_Disable || ch->stts == CS_Normal) {
        if(ch->Movestts != ANI_InOut_Manhole){
            for (CharaInfo* c = gCharaHead; c; c = c->next) {
            if (c->type == CT_Manhole &&
                c->rect.x == CurrentManhole.x &&
                c->rect.y == CurrentManhole.y) {
                c->manholestts = Manhole_Closed;
                }
            }   
        }
    }
    
    //========== dance =========
    // ====== spaceを押したら ======
    if (gGame.input.space && ch->stts == CS_Normal && !OnTheManhole && !InfrontOfTheDoor) {
        SDL_bool foundChasingNpc = SDL_FALSE;
        for (int i = 0; i < availableNpcCount; i++) {
            if (availableNpc[i]->stts == CS_Chase) {
                foundChasingNpc = SDL_TRUE;
                break;
            }
        }
    
        if (foundChasingNpc) {
            ch->stts = CS_Dance;
            ch->Movestts = ANI_Dance;
        }
    }

    // ====== spaceを放すと ======
    if (!gGame.input.space && ch->stts == CS_Dance) {
        ch->stts = CS_Normal;
        ch->Movestts = ANI_Stop;
    }
}


//当たり判定
SDL_bool Collision(CharaInfo* ci, CharaInfo* cj)
{
    if (ci->stts == CS_Disable || cj->stts == CS_Disable)
        return SDL_FALSE;

    SDL_Rect ir;
    if (SDL_IntersectRect(&(ci->rect), &(cj->rect), &ir)){
    // プレイヤーと
        if (ci->type == CT_Player || cj->type == CT_Player) {
            CharaInfo* cp = (ci->type == CT_Player) ? ci : cj;
            CharaInfo* co = (ci->type == CT_Player) ? cj : ci;

            if (co->type == CT_Buliding1 || co->type == CT_PoliceStation || co->type == CT_Buliding2 || co->type == CT_Buliding3 ||co->type == CT_Church ) {
                SDL_Rect adjusted = co->rect;
                adjusted.y += 50;  // 上の部分を少し下ろす
                adjusted.h -= 50;  
                if (SDL_IntersectRect(&(cp->rect), &adjusted, &ir)) {
                    AdjustPoint(cp, co, &ir);
                }
            }
            if (co->type == CT_Door) {
                InfrontOfTheDoor = 1;
                CurrentDoor = co->rect;
            }
            if (co->type == CT_Tree ) {
                SDL_Rect adjusted = co->rect;
                adjusted.h -= 50;  // あたり判定を調節
                if (SDL_IntersectRect(&(cp->rect), &adjusted, &ir)) {
                    AdjustPoint(cp, co, &ir);
                }
            }
            if (co->type == CT_Manhole) {
                OnTheManhole = 1;
                CurrentManhole.x = (int)co->point.x;
                CurrentManhole.y = (int)co->point.y;
                CurrentManhole.w = co->rect.w;
                CurrentManhole.h = co->rect.h;
            }
            
            if(co->type == CT_Villiger || co->type == CT_Yakuza
            || co->type == CT_Police || co->type == CT_Car || co->type == CT_Cross)
            {
                if (Mix_PlayingMusic() == 1) { // 他の音楽(背景音楽)が再生中の場合は中止
                    Mix_HaltMusic();
                }
                RenderScene(co);
                
            }
        }
    }
    return SDL_FALSE;
}

//NPCstts管理
void UpdateNPC(void) {

    for (int i = 0; i < availableNpcCount; i++) {
        if (availableNpc[i] == NULL) {
            printf("availableNpc[%d] is NULL!\n", i);
            continue;
        }
    }

    for (int i = 0; i < availableNpcCount; i++) {
        CharaInfo* npc = availableNpc[i];
        if (npc == NULL || npc->entity == NULL) {
            printf("NPC[%d] is invalid (null or entity null)\n", i);
            continue;
        }

        if (npc->stts == CS_Disable || npc->type == CT_Jesus || npc->type == CT_Cross) continue;

        float dx = gGame.player->point.x - npc->point.x;
        float dy = gGame.player->point.y - npc->point.y;
        float distSq = dx * dx + dy * dy;
        float followDistance = 60.0f;

        // プレイヤーがNormal状態で、NPCとプレイヤー間の距離が追跡距離より遠く離れている時(追跡開始)
        if (gGame.player->stts != CS_Disable && distSq > followDistance * followDistance) {
            npc->stts = CS_Chase;
            Chase(npc, gGame.player);

            // 追跡音楽が再生中でない場合にのみ転換
            if (!isChaseMusicPlaying) {
                if (Mix_PlayingMusic() == 1) { // 他の音楽(背景音楽)が再生中の場合は中止
                    Mix_HaltMusic();
                }
                if (chaseMusic != NULL) {
                    if (Mix_PlayMusic(chaseMusic, -1) == -1) { // chaseMusic 反復再生
                        printf("Error playing chase music: %s\n", Mix_GetError());
                    } else {
                        isChaseMusicPlaying = SDL_TRUE; // 追跡音楽が再生中であることを表示
                    }
                } else {
                    printf("Chase music not loaded: %s\n", Mix_GetError());
                }
            }

        } else { // プレーヤーがDisable状態であるか、またはNPCとプレーヤー間の距離が近づいたとき（追跡終了）
            //プレーヤーがDisable状態のときにGoBack Home関数を呼び出す
            if (gGame.player->stts == CS_Disable) {
                SDL_Rect home = {CurrentDoor.x , CurrentDoor.y + 200};
                GoBackHome(npc, &home);

                // 追跡音楽だけを中止し、BGMはそのまま維持
                if (isChaseMusicPlaying) {
                    printf("Stopping chase music due to player disable\n");
                    Mix_HaltMusic();
                    isChaseMusicPlaying = SDL_FALSE;
                    // BGMがロードされていて、現在何の音楽も再生中でなければ再生
                    if (Mix_PlayingMusic() == 0 && music != NULL) {
                        if (Mix_PlayMusic(music, -1) == -1) {
                            printf("Error playing background music: %s\n", Mix_GetError());
                        } else {
                            printf("Background music resumed after chase\n");
                        }
                    }
                }
            }else {
                // 追跡距離に入ったり、プレイヤーが止まったりした場合、NPCも止まったり、他の行動をするようにする
                npc->stts = CS_Normal; 
                npc->vel.x = 0;
                npc->vel.y = 0;

                // 元の音楽に切り替わり（追跡状態から外れたとき）
                if (isChaseMusicPlaying) { // 追跡音楽が再生中のみ停止し、BGMに切り替える
                    printf("Stopping chase music and resuming background with fade out\n");
                    Mix_FadeOutMusic(1000); 
                    isChaseMusicPlaying = SDL_FALSE;
                    
                    // BGMが現在再生中でない場合はフェードイン開始
                    if (music != NULL && (Mix_PlayingMusic() != 1 || Mix_FadingMusic() != MIX_FADING_IN)) {
                        if (Mix_PlayMusic(music, -1) == -1) {
                            printf("Error playing background music: %s\n", Mix_GetError());
                        }
                    } else if (music == NULL) {
                        printf("Background music not loaded: %s\n", Mix_GetError());
                    }
                }
                // もし、何の音楽も再生できず、musicがロードされていれば再生
                else if (Mix_PlayingMusic() == 0 && music != NULL) {
                    if (Mix_PlayMusic(music, -1) == -1) {
                        printf("Error playing background music: %s\n", Mix_GetError());
                    }
                }
            }
        }

        // 速度を適用して位置更新を追加
        float deltaTime = 0.016f;
        npc->point.x += npc->vel.x * deltaTime;
        npc->point.y += npc->vel.y * deltaTime;

        // 衝突ボックスアップデート
        npc->rect.x = (int)npc->point.x;
        npc->rect.y = (int)npc->point.y;
        npc->rect.w = npc->entity->w;
        npc->rect.h = npc->entity->h;
    }
    
    for (int i = 0; i < availableNpcCount; i++) {
    if (availableNpc[i] == NULL) {
        printf("availableNpc[%d] is NULL!\n", i);
    }
}
}


//経験値と血圧値の計算
void CalculateExp_BloodPressure(CharaInfo* ch)
{
    if (gGame.player == NULL) return;

    if((ch -> type == CT_Villiger  || ch -> type == CT_Yakuza) && ch -> stts == CS_Chase && gGame.stts == GS_Playing){
        if(gGame.player->stts == CS_Dance){
            gGame.player -> exp += 4;  
            BloodPressure += 3.6;
            if(BloodPressure > MAX_BLOODPRESSURE){
                BloodPressure = MAX_BLOODPRESSURE;
            }
        }else{
            gGame.player -> exp++;  
            BloodPressure += 0.9;
            if(BloodPressure > MAX_BLOODPRESSURE)
                BloodPressure = MAX_BLOODPRESSURE;
        }
        if(gGame.player -> exp >= 122){
            gGame.player -> level++;
            if(gGame.player -> level > MAX_PLAYERLEVEL){
                gGame.player -> level = MAX_PLAYERLEVEL;
            }
            gGame.player -> exp = 0;
        }
    }
    if(BloodPressure == MAX_BLOODPRESSURE){
        gGame.stts = GS_Clear;
    }
}

//システム破棄
void DestroySystem(void) {
    CharaInfo* ch = gCharaHead;
    while (ch) {
        CharaInfo* next = ch->next;
        free(ch);
        ch = next;
    }
    gCharaHead = NULL;
}