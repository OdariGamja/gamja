#include "game.h"
#include "AStar.h"
#include <stdlib.h>
#include <math.h>

#define TILE_SIZE 60
#define GRID_WIDTH  (MAP_Width / TILE_SIZE)   // 94
#define GRID_HEIGHT (MAP_Height / TILE_SIZE)  // 53
#define MAX_PATH_LEN 200

int map_data[GRID_HEIGHT][GRID_WIDTH];  // MAP_Height × MAP_Widthは大きすぎて、タイル単位の配列に変更

//A*ライブラリ用ノードキー構造体 
typedef struct {
    int x, y;
} GridNodeKey;

//  ノードキー比較関数 
int NodeComparator(void* key1, void* key2, void* context) {
    GridNodeKey* a = (GridNodeKey*)key1;
    GridNodeKey* b = (GridNodeKey*)key2;
    if (a->x != b->x) return a->x - b->x;
    return a->y - b->y;
}

// ノード近隣探索関数 
void NodeNeighbors(ASNeighborList list, void* nodeKey, void* context) {
    const GridNodeKey pos = *(const GridNodeKey*)nodeKey;
    int (*map)[GRID_WIDTH] = context;

    GridNodeKey neighbors[4] = {
        {pos.x + 1, pos.y},
        {pos.x - 1, pos.y},
        {pos.x, pos.y + 1},
        {pos.x, pos.y - 1}
    };

    for (int i = 0; i < 4; i++) {
        GridNodeKey n = neighbors[i];
        if (n.x >= 0 && n.x < GRID_WIDTH && n.y >= 0 && n.y < GRID_HEIGHT) {
            if (map[n.y][n.x] == 0) { //移動可能タイル
                ASNeighborListAdd(list, &n, 1.0f); 
            }
        }
    }
}

//  ヒューリスティック関数(マンハッタン通り) 
float PathCostHeuristic(void* key1, void* key2, void* context) {
    GridNodeKey* a = (GridNodeKey*)key1;
    GridNodeKey* b = (GridNodeKey*)key2;
    return fabsf((float)(a->x - b->x)) + fabsf((float)(a->y - b->y));
}

// ASPathNodeSource構造体初期化 
ASPathNodeSource pathNodeSource = {
    .nodeSize = sizeof(GridNodeKey),
    .nodeComparator = NodeComparator,
    .nodeNeighbors = NodeNeighbors,
    .pathCostHeuristic = PathCostHeuristic,
    .earlyExit = NULL
};

//  FindPath 関数 
int FindPath(int startX, int startY, int goalX, int goalY, GridNodeKey* pathBuffer, int maxPathLen) {
    GridNodeKey start = { startX, startY };
    GridNodeKey goal = { goalX, goalY };
    
    ASPath path = ASPathCreate(&pathNodeSource, map_data, &start, &goal);
    if (!path) {

    return 0;
}

    int count = (int)ASPathGetCount(path);
    if (count > maxPathLen) count = maxPathLen;

    for (int i = 0; i < count; i++) {
        GridNodeKey* node = ASPathGetNode(path, i);
        pathBuffer[i] = *node;
    }
    ASPathDestroy(path);

    if (!path) {

    return 0;
}
    return count;  // パスノード数の返還
}


// 既存の関数
void InitMapData(void) {
    // 全体を移動可能（0）に初期化
    for (int y = 0; y < GRID_HEIGHT; y++) {
        for (int x = 0; x < GRID_WIDTH; x++) {
            map_data[y][x] = 0;
        }
    }

    //障害物エリア設定 - 例えば建物の位置に合わせて1に設定
    for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
        if (ch->type == CT_Buliding1 || ch->type == CT_Tree || ch->type == CT_PoliceStation ||
        ch->type == CT_Buliding2 ||ch->type == CT_Buliding3 || ch->type == CT_Church) {
            int margin = 1;  // ピクセル単位の余裕
            int startX = (int)((ch->rect.x + margin) / TILE_SIZE);
            int startY = (int)((ch->rect.y + margin) / TILE_SIZE); 
            int endX = (int)((ch->rect.x + ch->rect.w - margin) / TILE_SIZE)-1;
            int endY = (int)((ch->rect.y + ch->rect.h - margin) / TILE_SIZE)-2;

            for (int y = startY; y <= endY && y < GRID_HEIGHT; y++) {
                for (int x = startX; x <= endX && x < GRID_WIDTH; x++) {
                    map_data[y][x] = 1;
                }
            }
        }
    }
}

//マップをタイルに分ける
void WorldToGrid(float x, float y, int* gridX, int* gridY) {
    *gridX = (int)(x / TILE_SIZE);
    *gridY = (int)(y / TILE_SIZE);
}

//追跡関数
void Chase(CharaInfo* npc, CharaInfo* player) {
    
    int npcX, npcY, playerX, playerY;
    WorldToGrid(npc->point.x, npc->point.y, &npcX, &npcY);
    WorldToGrid(player->point.x, player->point.y, &playerX, &playerY);
     
    GridNodeKey path[MAX_PATH_LEN];
    //PathFinding開始
    int path_len = FindPath(npcX, npcY, playerX, playerY, path, MAX_PATH_LEN);

    if (path_len > 1) {
        int nextX = path[1].x;
        int nextY = path[1].y;

        float targetX = nextX * TILE_SIZE + TILE_SIZE/2;
        float targetY = nextY * TILE_SIZE + TILE_SIZE/2;

        float dx = targetX - npc->point.x;
        float dy = targetY - npc->point.y;
        float dist = sqrtf(dx*dx + dy*dy);

        //警察の場合
        if(npc -> type == CT_Police){
            float speed = 200.0f;
            if (dist > 0) {
            if (fabsf(dx) > fabsf(dy)) {
                // X方向を先に移動
                npc->vel.x = (dx > 0) ? speed : -speed;
                npc->vel.y = 0;
            } else {
                // Y方向を先に移動
                npc->vel.x = 0;
                npc->vel.y = (dy > 0) ? speed : -speed;
            }
        }
        }else{//他の場合
            float speed = 100.0f;  // 速度
            if (dist > 0) {
                if (fabsf(dx) > fabsf(dy)) {
                    // X方向を先に移動
                    npc->vel.x = (dx > 0) ? speed : -speed;
                    npc->vel.y = 0;
                } else {
                    // Y方向を先に移動
                    npc->vel.x = 0;
                    npc->vel.y = (dy > 0) ? speed : -speed;
                }
            }
        }
        
        //アニメーション方向設定
        if (fabsf(npc->vel.x) > fabsf(npc->vel.y)) {
            npc->Movestts = (npc->vel.x > 0) ? ANI_RunRight : ANI_RunLeft;
        } else {
            npc->Movestts = (npc->vel.y > 0) ? ANI_RunDown : ANI_RunUp;
        }
            npc->dir = (npc->vel.x >= 0) ? 1 : -1;
            npc->stts = CS_Chase;
        } else {
            npc->vel.x = 0;
            npc->vel.y = 0;
            npc->Movestts = ANI_Stop;
            npc->stts = CS_Normal;
        }

}

//家に帰る関数(Chase関数とほぼ同一)
void GoBackHome(CharaInfo* npc, SDL_Rect* home) {
    if (npc == NULL) {

    return;
}
    int npcX, npcY, homeX, homeY;
    WorldToGrid(npc->point.x, npc->point.y, &npcX, &npcY);
    WorldToGrid(home->x + home->w / 2, home->y + home->h / 2, &homeX, &homeY);

    GridNodeKey path[MAX_PATH_LEN];
    //PathFinding開始
    int path_len = FindPath(npcX, npcY, homeX, homeY, path, MAX_PATH_LEN);

    if (path_len > 1) {
        int nextX = path[1].x;
        int nextY = path[1].y;

        float targetX = nextX * TILE_SIZE + TILE_SIZE / 2;
        float targetY = nextY * TILE_SIZE + TILE_SIZE / 2;

        float dx = targetX - npc->point.x;
        float dy = targetY - npc->point.y;
        float dist = sqrtf(dx*dx + dy*dy);

        float speed = 180.0f;

        if (dist > 0) {
            if (fabsf(dx) > fabsf(dy)) {
                // X方向を先に移動
                npc->vel.x = (dx > 0) ? speed : -speed;
                npc->vel.y = 0;
            } else {
                // Y方向を先に移動
                npc->vel.x = 0;
                npc->vel.y = (dy > 0) ? speed : -speed;
            }
        }

        //アニメーション方向設定
        if (fabsf(npc->vel.x) > fabsf(npc->vel.y)) {
            npc->Movestts = (npc->vel.x > 0) ? ANI_RunRight : ANI_RunLeft;
        } else {
            npc->Movestts = (npc->vel.y > 0) ? ANI_RunDown : ANI_RunUp;
        }
        npc->dir = (npc->vel.x >= 0) ? 1 : -1;
        npc->stts = CS_BackHome;
        } else {
            npc->vel.x = 0;
            npc->vel.y = 0;
            npc->Movestts = ANI_Stop;
            npc->stts = CS_Disable;
        }
}


