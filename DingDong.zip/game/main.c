/*PathFinding アルゴリズム著作権*/
/* Astar*/
/* Copyright (c) 2012, Sean Heber. All rights reserved.*/
/*https://github.com/BigZaphod/AStar*/

#include <stdio.h>
#include <SDL2/SDL.h> 
#include <SDL2/SDL_mixer.h>
#include "game.h"
#include <joyconlib.h>

SDL_bool InputEvent(void);
void StartMenu(int selectedIndex);
void EndGame(void);
void ResetGameState(void);
void MoveChara(CharaInfo* ch);
extern void UpdateCharaterInfo(CharaInfo* ch);

static int selectedIndex = 0;
// タイマー
int gStartMenuFrame = 0;
int framecnt = 0;
SDL_TimerID timerID;
SDL_TimerID expTimerID;
SDL_TimerID UpdateNPCTimerID;
Uint32 startTime = 0;
SDL_bool fadeOut = SDL_FALSE;
SDL_bool isGameoverSoundPlayed = SDL_FALSE;
SDL_bool isSlapSoundPlayed = SDL_FALSE;
Uint8 fadeAlpha = 0;
Uint32 lastFootstepTime = 0;
Uint32 footstepInterval = 550; 

// BGN関連変数
Mix_Music *music = NULL;      // BGM
Mix_Music *chaseMusic = NULL; // 追跡音楽

// 効果音関連変数
Mix_Chunk *knockChunk = NULL;
Mix_Chunk *runChunk = NULL;
Mix_Chunk *ManholeChunk = NULL;
Mix_Chunk *GameoverChunk = NULL;
Mix_Chunk *SlapChunk = NULL;
Mix_Chunk *DanceChunk = NULL;
Mix_Chunk *ClearChunk = NULL;
Mix_Chunk *WhoopChunk = NULL;
Mix_Chunk *ShutChunk = NULL;
Mix_Chunk *SurpriseChunk = NULL;

Uint32 currentTime = 0;

//アニメーションタイマー
Uint32 AniTimer(Uint32 interval, void* param) {
    gGame.timeDelta = 0.1f;
    for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
        AnimateHuman(ch);
        AnimateDoor(ch);
        AnimateManhole(ch); 
    }
    gStartMenuFrame = (gStartMenuFrame + 1) % 2;
    return interval;
    
}

//経験値、血圧の計算タイマー
Uint32 ExpTimer(Uint32 interval, void* param) {
    gGame.timeDelta = 0.1f;

    for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
            CalculateExp_BloodPressure(ch);
        }
    return interval;
}

//NPCの状態計算タイマー(PathFinding)
Uint32 UpdateNPCTimer(Uint32 interval, void* param) {
    gGame.timeDelta = 0.1f;
    UpdateNPC(); 
    return interval;
}

//メイン関数
int main(int argc, char* argv[]) {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0) {
        return PrintError(SDL_GetError());
    }

    
    if (InitSystem("chara.data", "position.data") < 0) {
        PrintError("failed to initialize System");
        EndGame();
        return 1;
    }

    if (InitWindow("src/bg.png") < 0) {
        PrintError("InitWindow ローディング失敗");
        SDL_Quit();
        return 1;
    }
    // SDL_mixer 초기화
    if ((Mix_Init(MIX_INIT_MP3) & MIX_INIT_MP3) != MIX_INIT_MP3) {
        printf("ローディング失敗 SDL_mixer Error: %s\n", Mix_GetError());
        return -1;
    }

    // オーディオデバイスの初期化
    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT, 2, 1024) < 0) {
        printf("ローディング失敗 SDL_mixer.\n");
        SDL_Quit();
        exit(-1);
    }
  

    //bgm
    if ((music = Mix_LoadMUS("sound/bgm.mp3")) == NULL) {
        printf("ローディング失敗 bgm.mp3: %s\n", Mix_GetError());
        Mix_CloseAudio(); 
        SDL_Quit();
        exit(-1);
    }

    if ((chaseMusic = Mix_LoadMUS("sound/chase.mp3")) == NULL) {
        printf("chase.mp3 ローディング失敗: %s\n", Mix_GetError());
        return -1;  
    }
    
    

    Mix_AllocateChannels(16);
    //chunk
    runChunk = Mix_LoadWAV("sound/run.mp3");
    if (!runChunk) {
        printf("run.mp3ローディング失敗: %s\n", Mix_GetError());
    }

    knockChunk = Mix_LoadWAV("sound/knock.mp3");
    if (!knockChunk) {
        printf("knock ローディング失敗: %s\n", Mix_GetError());
    }
    ManholeChunk = Mix_LoadWAV("sound/Manhole.wav");
    if (!ManholeChunk) {
        printf("manhole ローディング失敗: %s\n", Mix_GetError());
    }
    GameoverChunk = Mix_LoadWAV("sound/gameover.wav");
    if (!GameoverChunk) {
        printf("gameover ローディング失敗: %s\n", Mix_GetError());
    }
    SlapChunk = Mix_LoadWAV("sound/whip.wav");
    if (!SlapChunk) {
        printf("slap ローディング失敗: %s\n", Mix_GetError());
    }
    DanceChunk = Mix_LoadWAV("sound/dance.wav");
    if (!DanceChunk) {
        printf("dance ローディング失敗: %s\n", Mix_GetError());
    }
    ClearChunk = Mix_LoadWAV("sound/clear.wav");
    if (!ClearChunk) {
        printf("clear ローディング失敗: %s\n", Mix_GetError());
    }
    WhoopChunk = Mix_LoadWAV("sound/whoop.wav");
    if (!WhoopChunk) {
        printf("whoop ローディング失敗: %s\n", Mix_GetError());
    }
    ShutChunk = Mix_LoadWAV("sound/shut.wav");
    if (!ShutChunk) {
        printf("shut ローディング失敗: %s\n", Mix_GetError());
    }
    SurpriseChunk = Mix_LoadWAV("sound/surprise.wav");
    if (!SurpriseChunk) {
        printf("surprise ローディング失敗: %s\n", Mix_GetError());
    }

    //volume調整
    Mix_VolumeChunk(knockChunk, MIX_MAX_VOLUME / 4);
    Mix_VolumeChunk(ManholeChunk, MIX_MAX_VOLUME);
    Mix_VolumeChunk(WhoopChunk, MIX_MAX_VOLUME);


    gGame.stts = GS_Ready;

    // タイマー開始（0.1秒ごとに実行）
        expTimerID = SDL_AddTimer(2000, ExpTimer, NULL);
        timerID = SDL_AddTimer(50, AniTimer, &framecnt);
        UpdateNPCTimerID = SDL_AddTimer(50, UpdateNPCTimer, &framecnt);
    // ====== スタートメニューループ ======
    SDL_bool startLoop = SDL_TRUE;
    
    Mix_FadeInMusic(music, -1, 1000);
    while (startLoop) {
        StartMenu(selectedIndex);
        SDL_Delay(16); 
        InputEvent();

        if (gGame.input.space) {
            if (selectedIndex == 0) {
                gGame.stts = GS_Playing;
            } else {
                gGame.stts = GS_End;
            }
            break;
        }
    }

    // 終了を選択したら
    if (gGame.stts == GS_End) {
        EndGame();
        return 0;
    }

    // ====== メインループ ======
    SDL_bool loogflg = SDL_TRUE;
    
    startTime = SDL_GetTicks();
    while (loogflg && gGame.stts != GS_End && gGame.stts != GS_Clear) {
        loogflg = InputEvent();

        if(gGame.player -> Movestts == ANI_Ringthebell){
            startTime = SDL_GetTicks();
        }
        
        if (gGame.stts == GS_GameOver) {

            startTime = 0;
            currentTime = 0;
            // ゲームオーバー効果音を一度だけ再生
            if (GameoverChunk && !isGameoverSoundPlayed) {
                Mix_PlayChannel(GAMEOVER_CHANNEL, GameoverChunk, 0);
                isGameoverSoundPlayed = SDL_TRUE; 
            }
            
            ShowRestart(selectedIndex); // 再起動メニュー画面レンダリング

            if (gGame.input.space) {
                if (selectedIndex == 0) {
                    
                    ResetGameState(); // ゲーム状態の初期化とBGMの再起動
                    isGameoverSoundPlayed = SDL_FALSE;
                    isSlapSoundPlayed = SDL_FALSE;
                    // タイマー再起動
                    expTimerID = SDL_AddTimer(1000, ExpTimer, NULL);
                    timerID = SDL_AddTimer(50, AniTimer, &framecnt);
                    UpdateNPCTimerID = SDL_AddTimer(50, UpdateNPCTimer, &framecnt);
                    startTime = SDL_GetTicks();
                } else {
                    EndGame();
                    break;
                }
            }
            continue; 
        }

        // シーンレンダリング時間チェック
        if(gGame.stts == GS_Playing){
            currentTime = SDL_GetTicks();

            // プレイヤーが存在する時だけ
            if (gGame.player) {
                if (gGame.player->Movestts == ANI_Stop) {
                    // 10秒間、何の動作もない時
                    if (currentTime - startTime >= 10000) {
                        RenderScene(gGame.player);//暇すぎて死亡
                        startTime = currentTime; // 再び5秒カウント
                    }
                } else {
                    //動いたらタイマー初期化
                    startTime = currentTime;
                }

            }    
        }

        if (gGame.stts == GS_YakuzaScene) {
        // カットシーン処理
        YakuzaAppear(); 
        SDL_Delay(1000);
        YakuzaScene = 1;

        for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
            if (ch->type == CT_Yakuza) {
                ch->stts = CS_Normal;//ヤクザ出現
                ch-> Doorfrom = NULL;
            }
        }
        gGame.stts = GS_Playing; 
        continue; 
        }

        //キャラクタ情報処理
        for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
            MoveChara(ch);
            UpdateCharaterInfo(ch);
        }


        // ダンス効果音の再生/中止ロジック
        if (gGame.player && gGame.player->stts == CS_Dance) { 
            // プレイヤーがダンス状態のとき、DANCE_CHANNELで何も再生されていない場合は再生
            if (Mix_Playing(DANCE_CHANNEL) == 0) {
                Mix_PlayChannel(DANCE_CHANNEL, DanceChunk, -1);
            }
            // 踊るときは足音中止（他に動きがないので）
            Mix_HaltChannel(WALK_CHANNEL);
        } else {
            // プレイヤーがダンス状態でない時、DANCE_CHANNELで再生中の効果音中止
            if (Mix_Playing(DANCE_CHANNEL) == 1) {
                Mix_HaltChannel(DANCE_CHANNEL);
            }
        }

        // 足音効果音処理
        Uint32 now = SDL_GetTicks();
        if ((gGame.input.up || gGame.input.down || gGame.input.left || gGame.input.right)
            && now - lastFootstepTime > footstepInterval) {
            Mix_PlayChannel(WALK_CHANNEL, runChunk, 0);
            lastFootstepTime = now;
        }
        
        //グローバル変数初期化及び当たり判定計算
        InfrontOfTheDoor = 0;
        OnTheManhole = 0;
        for (CharaInfo* p = gCharaHead; p; p = p->next) {
            for (CharaInfo* q = p->next; q; q = q->next) {
                Collision(p, q);
            }
        }
        //レンダリング
        RenderWindow();
        framecnt++;
        SDL_Delay(16); 
    }
    //クリアならクリア画面出力
    if (gGame.stts == GS_Clear) {
        ShowClear();
    }

    EndGame();
    return 0;
}

//再起動関数
void ResetGameState(void) {
    //既存のキャラクターはすべて解除
    CharaInfo* ch = gCharaHead;
    while (ch) {
        CharaInfo* next = ch->next;
        free(ch);
        ch = next;
    }
    gCharaHead = NULL;

    //ゲームステータス初期化
    gGame.player = NULL;
    gGame.stts = GS_Playing;

    gGame.input.up = SDL_FALSE;
    gGame.input.down = SDL_FALSE;
    gGame.input.left = SDL_FALSE;
    gGame.input.right = SDL_FALSE;
    gGame.input.space = SDL_FALSE;

    //NPCリスト初期化
    for (int i = 0; i < MAX_NPC; i++) {
        availableNpc[i] = NULL;
    }
    availableNpcCount = 0;
    YakuzaScene = 0;
    //血圧などゲーム変数の初期化
    BloodPressure = 0;
    InfrontOfTheDoor = 0;
    OnTheManhole = 0;
    JesusShootCross = 0;
    CurrentDoor = (SDL_Rect){0,0,0,0};
    CurrentManhole = (SDL_Rect){0,0,0,0};
    currentTime= SDL_GetTicks(); 
    startTime = SDL_GetTicks(); 
    
    //InitSystemの再呼び出し(ファイルを読んで新たにキャラクターをセッティング)
    if (InitSystem("chara.data", "position.data") < 0) {
        PrintError("ResetGameState failed: InitSystem error");
    }
    Mix_FadeInMusic(music, -1, 1000);
}



//ゲーム終了担当
void EndGame(void) {
    // UI_Exp テクスチャ 解除
    for (int i = 0; i < MAX_PLAYERLEVEL; i++) {
        if (gGame.UI_Exp[i]) {
            SDL_DestroyTexture(gGame.UI_Exp[i]);
            gGame.UI_Exp[i] = NULL;   
        }
    }
   
    // 音楽解除
    if (music) {
        Mix_FreeMusic(music);
        music = NULL;                
    }
    if (chaseMusic) {
        Mix_FreeMusic(chaseMusic);
        chaseMusic = NULL;          
    }
    if (ManholeChunk) {
        Mix_FreeChunk(ManholeChunk);
        ManholeChunk = NULL;         
    }
    if (knockChunk) {
        Mix_FreeChunk(knockChunk);
        knockChunk = NULL;           
    }
    if (runChunk) {
        Mix_FreeChunk(runChunk);
        runChunk = NULL;            
    }
    if (GameoverChunk) {
        Mix_FreeChunk(GameoverChunk);
        GameoverChunk = NULL;           
    }
    if (DanceChunk) {
        Mix_FreeChunk(DanceChunk);
        DanceChunk = NULL;            
    }

    // SDL_mixer 終了
    Mix_CloseAudio();

    //タイマー解除
    if (timerID) {
        SDL_RemoveTimer(timerID);
        timerID = 0;
    }

    if (expTimerID) {
        SDL_RemoveTimer(expTimerID);
        expTimerID = 0;
    }

    if (UpdateNPCTimerID) {
        SDL_RemoveTimer(UpdateNPCTimerID);
        UpdateNPCTimerID = 0;
    }
    
    // ゲームウィンドウとレンダラー解除
    DestroyWindow();

    // SDL終了
    SDL_Quit();
}

//移動処理
void MoveChara(CharaInfo* ch) {
    if (!ch || ch->stts == CS_Disable) return;

    // 車
    if (ch->type == CT_Car) {
        ch->point.y += ch->vel.y * gGame.timeDelta;
        ch->rect.y = (int)ch->point.y;

        if (ch->point.y > MAP_Height) {
            ch->point.y = -5000;
        }
        return;
    }

    //プレイヤー移動
    if (ch->type == CT_Player) {
        if (ch->ringing || ch->Movestts == ANI_InOut_Manhole || ch->stts == CS_Dance) return;

        float speed = 150.0f;
        ch->vel.x = 0;
        ch->vel.y = 0;

        if (gGame.input.up) {
            ch->vel.y = -speed;
            ch->Movestts = ANI_RunUp;
        }
        else if (gGame.input.down) {
            ch->vel.y = speed;
            ch->Movestts = ANI_RunDown;
        }
        else if (gGame.input.left) {
            ch->vel.x = -speed;
            ch->Movestts = ANI_RunLeft;
        }
        else if (gGame.input.right) {
            ch->vel.x = speed;
            ch->Movestts = ANI_RunRight;
        }
        else {
            ch->Movestts = ANI_Stop;
        }
    }
    // 十字架移動処理
    if (ch->type == CT_Cross) {
        ch->point.x += ch->vel.x ;
        ch->point.y += ch->vel.y ;
        if (ch->point.x < 0 || ch->point.x > MAP_Width || ch->point.y < 0 || ch->point.y > MAP_Height) {
            ch->stts = CS_Disable;
            ch->vel.x = 0;
            ch->vel.y = 0;
            return;
        }
        ch->rect.x = (int)ch->point.x;
        ch->rect.y = (int)ch->point.y;
        return; 
    }


    //共通移動処理(プレイヤー+NPC)
    ch->point.x += ch->vel.x * gGame.timeDelta;
    ch->point.y += ch->vel.y * gGame.timeDelta;   

    // 境界処理
    if (ch->point.x < 0) ch->point.x = 0;
    if (ch->point.y < 0) ch->point.y = 0;
    if (ch->point.x + ch->rect.w > MAP_Width)
        ch->point.x = MAP_Width - ch->rect.w;
    if (ch->point.y + ch->rect.h > MAP_Height)
        ch->point.y = MAP_Height - ch->rect.h;

    // 位置反映
    if (ch->type == CT_Buliding1 || ch->type == CT_Buliding2 || ch->type == CT_Buliding3 ||
        ch->type == CT_PoliceStation || ch->type == CT_Church) {
        ch->rect.x = (int)ch->point.x;
        ch->rect.y = (int)ch->point.y - 50; 
    } else {
        ch->rect.x = (int)ch->point.x;
        ch->rect.y = (int)ch->point.y;
    }
}


//入力処理
SDL_bool InputEvent(void) {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                return SDL_FALSE;

            case SDL_KEYDOWN:
                switch (event.key.keysym.sym) {
                    case SDLK_ESCAPE: 
                        return SDL_FALSE;
                    case SDLK_w: 
                        gGame.input.up = SDL_TRUE; 
                        if(gGame.stts == GS_GameOver || gGame.stts == GS_Ready){
                            selectedIndex = (selectedIndex - 1 + 2) % 2;    
                        }
                        break;
                    case SDLK_s: 
                        gGame.input.down = SDL_TRUE; 
                        if(gGame.stts == GS_GameOver || gGame.stts == GS_Ready){
                            selectedIndex = (selectedIndex - 1 + 2) % 2;    
                        }
                        break;
                    case SDLK_a: 
                        
                        gGame.input.left = SDL_TRUE; 
                        
                        break;
                    case SDLK_d:
                        
                        gGame.input.right = SDL_TRUE; 
                        
                        break;
                    case SDLK_SPACE:
                        gGame.input.space = SDL_TRUE;
                
                        break;
                }
                break;

            case SDL_KEYUP:
                switch (event.key.keysym.sym) {
                    case SDLK_w: 
                        gGame.input.up = SDL_FALSE; 

                        break;
                    case SDLK_s: 
                        gGame.input.down = SDL_FALSE; 
                 
                        break;
                    case SDLK_a: 
                        gGame.input.left = SDL_FALSE; 
           
                        break;
                    case SDLK_d: 
                        gGame.input.right = SDL_FALSE; 
             
                        break;
                    case SDLK_SPACE:
                        gGame.input.space = SDL_FALSE;
                        break;
                }
                break;
        }
    }
    return SDL_TRUE;
}


