#include "game.h"
#include <SDL2/SDL_image.h>
#include <stdlib.h>
#include <time.h>
#include <stdlib.h>  

int ShowRestart(int selectedIndex);
void ShowClear(void);
int YakuzaScene = 0;//ヤクザ登場シーンが出たかどうかを識別する変数
int JesusShootCross = 0;//Jesusが十字架を投げたかどうかを識別する変数
Uint32 lastJesusFrameTime = 0;//Jesusが十字架を投げるアニメーションの速度調整のための変数
const Uint32 jesusFrameDelay = 50; //Jesusが十字架を投げるアニメーションの速度調整のための変数

//ウインドウ初期化
int InitWindow(const char *bg_file)
{
    if (IMG_Init(IMG_INIT_PNG) != IMG_INIT_PNG) {
        return PrintError("failed to initialize SDL_image");
    }

    gGame.window = SDL_CreateWindow("game window", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                WD_Width, WD_Height, SDL_WINDOW_FULLSCREEN_DESKTOP);
    if (!gGame.window) return PrintError(SDL_GetError());

    gGame.render = SDL_CreateRenderer(gGame.window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!gGame.render) return PrintError(SDL_GetError());

    SDL_Surface *surf = IMG_Load(bg_file);
    if (!surf) return PrintError("failed to load background image");

    gGame.bg = SDL_CreateTextureFromSurface(gGame.render, surf);
    SDL_FreeSurface(surf);
    if (!gGame.bg) return PrintError(SDL_GetError());

    //キャラクターテクスチャの読み込み 
    for (int i = 0; i < CHARATYPE_NUM; i++) {
        SDL_Surface *s = IMG_Load(gCharaType[i].path);
        if (!s) return PrintError("failed to load character image");

        gCharaType[i].img = SDL_CreateTextureFromSurface(gGame.render, s);
        SDL_FreeSurface(s);
        if (!gCharaType[i].img) return PrintError(SDL_GetError());
    }
    // 初期画面表示位置 
    gGame.dp.x = 0;
    gGame.dp.y = 0;

    //経験値UI
    for (int i = 0; i < MAX_PLAYERLEVEL; i++) {
        char filename[64];
        sprintf(filename, "src/level%d.png", i + 1);

        SDL_Surface* surf = IMG_Load(filename);
        if (!surf) return PrintError("failed to load exp UI image");

        gGame.UI_Exp[i] = SDL_CreateTextureFromSurface(gGame.render, surf);
        SDL_FreeSurface(surf);
        if (!gGame.UI_Exp[i]) return PrintError("failed to create exp UI texture");
    }

    //血圧 UI
    SDL_Surface* sBP = IMG_Load("src/blood.png");
    if (!sBP) return PrintError("failed to load ui_blood.png");
    gGame.UI_BloodPressure = SDL_CreateTextureFromSurface(gGame.render, sBP);
    SDL_FreeSurface(sBP);
    if (!gGame.UI_BloodPressure) return PrintError("failed to create UI_BloodPressure texture");


    return 0;
}

//ウィンドウ解除
void DestroyWindow(void)
{
    for (int i = 0; i < CHARATYPE_NUM; i++) {
        if (gCharaType[i].img) {
            SDL_DestroyTexture(gCharaType[i].img);
            gCharaType[i].img = NULL;
        }
    }
    if (gGame.bg) {
        SDL_DestroyTexture(gGame.bg);
        gGame.bg = NULL;
    }
    if (gGame.render) {
        SDL_DestroyRenderer(gGame.render);
        gGame.render = NULL;
    }
    if (gGame.window) {
        SDL_DestroyWindow(gGame.window);
        gGame.window = NULL;
    }

    IMG_Quit();
}

//画面座標設定(プレイヤー中心)
static void SetDispPoint(void)
{
    if (!gGame.player) return;

    int dp_x = (int)gGame.player->point.x - CAMERA_W / 2;
    int dp_y = (int)gGame.player->point.y - CAMERA_H / 2;

    if (dp_x < 0) dp_x = 0;
    if (dp_y < 0) dp_y = 0;
    if (dp_x > MAP_Width - CAMERA_W) dp_x = MAP_Width - CAMERA_W;
    if (dp_y > MAP_Height - CAMERA_H) dp_y = MAP_Height - CAMERA_H;

    gGame.dp.x = dp_x;
    gGame.dp.y = dp_y;
}

//キャラクタ及びオブゼット描画
void RenderWindow(void)
{
    SetDispPoint();

    SDL_Rect src_bg = { gGame.dp.x, gGame.dp.y, CAMERA_W, CAMERA_H };
    SDL_Rect dst_bg;

    SDL_RenderClear(gGame.render);

    // 元の倍率計算
    float scale_x = (float)WD_Width / CAMERA_W;
    float scale_y = (float)WD_Height / CAMERA_H;

    // 縦横比維持用統一倍率
    float scale = (scale_x < scale_y) ? scale_x : scale_y;

    // 中央揃えのオフセット計算
    int offset_x = (int)((WD_Width  - CAMERA_W * scale) / 2);
    int offset_y = (int)((WD_Height - CAMERA_H * scale) / 2);

    dst_bg.x = offset_x;
    dst_bg.y = offset_y;
    dst_bg.w = (int)(CAMERA_W * scale);
    dst_bg.h = (int)(CAMERA_H * scale);

    if (SDL_RenderCopy(gGame.render, gGame.bg, &src_bg, &dst_bg) < 0) {
        PrintError(SDL_GetError());
    }

    // キャラクタータイプ順に並べ替えられたリストに基づいてレンダリング
    for (int t = 0; t < CHARATYPE_NUM; t++) {
        for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {//タイプ順にレンダリング
            if (ch->stts == CS_Disable) 
                continue;
            if (!ch->entity || !ch->entity->img) 
                continue;
            if (ch->type != t) 
                continue;  

            SDL_Rect src_char = ch->imgsrc;
            int cam_x = (int)(ch->point.x) - gGame.dp.x;
            int cam_y = (int)(ch->point.y) - gGame.dp.y;

            SDL_Rect dst_char = {
                offset_x + (int)(cam_x * scale),
                offset_y + (int)(cam_y * scale),
                (int)(ch->entity->w * scale),
                (int)(ch->entity->h * scale)
            };

            if (SDL_RenderCopy(gGame.render, ch->entity->img, &src_char, &dst_char) < 0) {
                PrintError(SDL_GetError());
            }
        }
    }


    //経験値 UI
    int level = gGame.player->level;
    if (level < 1) 
        level = 1;
    if (level > MAX_PLAYERLEVEL) 
        level = MAX_PLAYERLEVEL;

    SDL_Texture* expTex = gGame.UI_Exp[level - 1];
    SDL_Rect dstExp = { 20, 20, 600, 200 };
    if (expTex)
        SDL_RenderCopy(gGame.render, expTex, NULL, &dstExp);


    // UI血圧数値 右上
    if (gGame.UI_BloodPressure) {
        int bp_w = 550;  
        int bp_h = 130;   
        SDL_Rect bpDst = {
            WD_Width - bp_w - 20, 
            20,                    
            bp_w,
            bp_h
        };
        SDL_RenderCopy(gGame.render, gGame.UI_BloodPressure, NULL, &bpDst);
    }

    //exp bar
    SDL_Rect expBar = {
    236,    
    156,    
    gGame.player -> exp*3,   
    13    
    };
    SDL_SetRenderDrawColor(gGame.render, 0, 0, 255, 255);
    SDL_RenderFillRect(gGame.render, &expBar);

    SDL_Rect BloodPressureBar = {
        1427,
        114,
        BloodPressure,
        15
    };
    SDL_SetRenderDrawColor(gGame.render, 255, 0, 0, 255);
    SDL_RenderFillRect(gGame.render, &BloodPressureBar);
    SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 255); 
    SDL_RenderPresent(gGame.render);
}

//Jesusが十字架を投げる関数
void JesusThrowCross(CharaInfo* ch) {

    if (!Mix_Playing(WHOOP_CHANNEL)) {//効果音
        Mix_PlayChannel(WHOOP_CHANNEL, WhoopChunk, 0);
    }

    //十字架の位置を
    for (CharaInfo* c = gCharaHead; c; c = c->next) {
        if (c->type == CT_Cross && c->stts == CS_Disable) {
            // Jesusの位置に
            c->point.x = ch->point.x;
            c->point.y = ch->point.y;

            //現れるようにする
            c->stts = CS_Normal;

            // 速度方向計算（プレイヤーの方へ）
            float dx = gGame.player->point.x - c->point.x;
            float dy = gGame.player->point.y - c->point.y;
            float len = sqrtf(dx * dx + dy * dy);
            if (len == 0) len = 1;

            float speed = 80.0f; // 十字架の飛ぶ速度調節

            c->vel.x = (dx / len) * speed;
            c->vel.y = (dy / len) * speed;
            c->ani.x = 0;
            return; 
        }
    }
}

//人間を描画
void AnimateHuman(CharaInfo* ch) {
    if (ch->type != CT_Player && ch->type != CT_Villiger && ch->type != CT_Yakuza && ch->type != CT_Police && ch->type != CT_Jesus ) return;

    if(ch -> type == CT_Jesus && ch -> stts != CS_Disable){
        Uint32 currentTime = SDL_GetTicks();
        if (currentTime - lastJesusFrameTime < jesusFrameDelay) 
            return; // Jesusだけゆっくり
        lastJesusFrameTime = currentTime;
        
        // 全体フレーム数(横8マス)
        int frame_num = 8;
        // フレームサイズ
        int frame_w = 128;
        int frame_h = 128; 
        
        // Jesusの登場後2秒間ANI_Stop強制維持
        // 2秒間はANI_Stop固定&ani.xも固定
        if (currentTime - ch->jesusBornTime < 2000) {
            ch->Movestts = ANI_Stop;
            ch->imgsrc.y = 0 * frame_h;
            ch->imgsrc.w = frame_w;
            ch->imgsrc.h = frame_h;
            ch->imgsrc.x = 0;  
            return; 
        } 
        else {
            // 3秒以降のみ投げモーション進入可能
            if (!JesusShootCross) {
                if (gGame.player->point.x - ch->point.x < 0) {
                    ch->Movestts = ANI_Throw_Right;
                } else {
                    ch->Movestts = ANI_Throw_Left;
                }
            }
        }

        //プレイヤーがマンホールに入ったらJesusを非表示
        if(ch -> type ==CT_Jesus && ch -> stts == CS_Normal && gGame.player -> stts == CS_Disable){
            ch -> stts = CS_Disable;
            ch->point.x = -1000;
            ch->point.y = -1000;
            JesusShootCross = 0;
        }
        
        //Jesusのアニメーション処理
        switch(ch->Movestts) {  
            case ANI_Stop://停止
                ch->imgsrc.y = 0 * frame_h;
                ch->ani.x = (ch->ani.x + 1) % frame_num;
                break;
            case ANI_Throw_Left://左に投げる
                ch->imgsrc.y = 1 * frame_h; 
                if (ch->ani.x < frame_num - 1) {
                        ch->ani.x++;
                    } else {
                        JesusShootCross = 1;
                        ch->Movestts = ANI_Stop;
                        ch->ani.x = 0; 
                        JesusThrowCross(ch);
                    }
                break;
            case ANI_Throw_Right://右に投げる
                ch->imgsrc.y = 2 * frame_h;
                if (ch->ani.x < frame_num - 1) {
                        ch->ani.x++;
                    } else {
                        JesusShootCross = 1;
                        ch->Movestts = ANI_Stop;
                        ch->ani.x = 0; 
                        JesusThrowCross(ch);
                    }
                break;
            default:
                break;
            }

        // フレームサイズ設定
        ch->imgsrc.w = frame_w;
        ch->imgsrc.h = frame_h;
        // 現在のフレーム位置の計算
        ch->imgsrc.x = ch->ani.x * frame_w;
        }

    else if(ch->type == CT_Player || ch->type == CT_Villiger || ch->type == CT_Police){
        //CT_Player、CT_Villiger、CT_Policeのアニメーション
        int frame_num = 8;
        int frame_w = 32;
        int frame_h = 64;
        int angry = (ch->type == CT_Villiger) ? gGame.player->level - 1 : 0;
        if (angry < 0) angry = 0; 
        int base_row = 0;

        switch (ch->Movestts) {
            case ANI_Stop:
                base_row = 0;
                break;
            case ANI_RunRight:
                base_row = 1;
                break;
            case ANI_RunLeft:
                base_row = 2;
                break;
            case ANI_RunDown:
                base_row = 3;
                break;
            case ANI_RunUp:
                base_row = 4;
                break;
            case ANI_Ringthebell://ノックするとき
                ch->imgsrc.y = 5 * frame_h;
                ch->ani.x = (ch->ani.x + 1) % frame_num;
                goto post_y_set;
            case ANI_InOut_Manhole://マンホールに入るとき
                if (ch->manholeDir == MANHOLE_Enter) {
                    ch->imgsrc.y = 6 * frame_h;
                    if (ch->ani.x < frame_num - 1) {
                        ch->ani.x++;
                    } else {
                        ch->Movestts = ANI_Stop;
                        ch->stts = CS_Disable;
                    }
                } else if (ch->manholeDir == MANHOLE_Exit) {//出るとき
                    ch->imgsrc.y = 7 * frame_h;
                    if (ch->ani.x < frame_num - 1) {
                        ch->ani.x++;
                    } else {
                        ch->Movestts = ANI_Stop;
                        ch->stts = CS_Normal;
                    }
                }
                goto post_y_set;
            case ANI_Dance://踊るとき
                ch->imgsrc.y = 8 * frame_h;
                ch->ani.x = (ch->ani.x + 1) % frame_num;
                goto post_y_set;
            default:
                break;
        }

        // 動きに関するy座標の設定
        ch->imgsrc.y = (base_row + angry * 5) * frame_h;
        ch->ani.x = (ch->ani.x + 1) % frame_num;

        post_y_set:
        ch->imgsrc.w = frame_w;
        ch->imgsrc.h = frame_h;
        ch->imgsrc.x = ch->ani.x * frame_w;
    }else if(ch->type == CT_Yakuza){//ヤクザの場合
        int frame_num = 8;
        int frame_w = 64;
        int frame_h = 128;

        // プレイヤーレベルに基づいて怒りの段階を決定(赤くなる)
        int angry = gGame.player->level - 1;
        if (angry < 0) angry = 0;

        int base_row = 0;

        switch (ch->Movestts) {
            case ANI_Stop:
                base_row = 0;
                break;
            case ANI_RunRight:
                base_row = 1;
                break;
            case ANI_RunLeft:
                base_row = 2;
                break;
            case ANI_RunDown:
                base_row = 3;
                break;
            case ANI_RunUp:
                base_row = 4;
                break;
            default:
                break;
        }

        ch->imgsrc.y = (base_row + angry * 5) * frame_h;
        ch->ani.x = (ch->ani.x + 1) % frame_num;

        ch->imgsrc.w = frame_w;
        ch->imgsrc.h = frame_h;
        ch->imgsrc.x = ch->ani.x * frame_w;
    }

}

//ヤクザ出現
void YakuzaAppear(void)
{

    YakuzaScene = 0;
    Mix_HaltChannel(DANCE_CHANNEL); 
    Mix_HaltChannel(KNOCK_CHANNEL);
    Mix_HaltChannel(WALK_CHANNEL);
    Mix_HaltChannel(MANHOLE_CHANNEL);
    Mix_HaltChannel(WHOOP_CHANNEL);

    SDL_Surface* surf = IMG_Load("src/yakuza_appear1.png");
    if (!surf) {
        PrintError("failed to load yakuza_appear1.png");
        return;
    }

    SDL_Texture* tex = SDL_CreateTextureFromSurface(gGame.render, surf);
    SDL_FreeSurface(surf);
    if (!tex) {
        PrintError("failed to create texture from yakuza_appear1.png");
        return;
    }
    // 1番目の画像出力
    SDL_RenderClear(gGame.render);
    SDL_RenderCopy(gGame.render, tex, NULL, NULL);
    SDL_RenderPresent(gGame.render);
    SDL_DestroyTexture(tex);

    SDL_Delay(500);//待機

    // 2番目の画像出力
    surf = IMG_Load("src/yakuza_appear2.png");
    if (!surf) {
        PrintError("failed to load yakuza_appear2.png");
        return;
    }

    tex = SDL_CreateTextureFromSurface(gGame.render, surf);
    SDL_FreeSurface(surf);
    if (!tex) {
        PrintError("failed to create texture from yakuza_appear2.png");
        return;
    }
    SDL_RenderClear(gGame.render);
    SDL_RenderCopy(gGame.render, tex, NULL, NULL);
    SDL_RenderPresent(gGame.render);

    if (ShutChunk) {
        Mix_PlayChannel(SHUT_CHANNEL, ShutChunk, 0);
    }
    
    SDL_Delay(700);
    if (SurpriseChunk) {//効果音
        Mix_PlayChannel(SURPRISE_CHANNEL, SurpriseChunk, 0);
    }

    SDL_DestroyTexture(tex);
    
}

//ドアのアニメーション処理
void AnimateDoor(CharaInfo* ch) {
    if (ch->type != CT_Door) return;
    if (ch->stts == CS_Disable) return;

    // フレーム数
    int frame_num = 6;

    // フレームサイズ
    int frame_w = 100;
    int frame_h = 150;

    ch->ani.x = (ch->ani.x + 1) % frame_num;

    switch (ch->doorstts) {
        case DOOR_Closed:
            ch->imgsrc.y = 0 * frame_h;
            break;
        case DOOR_Ringed:
            ch->imgsrc.y = 1 * frame_h;
            break;
        case DOOR_Opened:
            ch->imgsrc.y = 2 * frame_h;
            break;
    }

    ch->imgsrc.x = ch->ani.x * frame_w;
    ch->imgsrc.w = frame_w;
    ch->imgsrc.h = frame_h;
}

//マンホールのアニメーション処理
void AnimateManhole(CharaInfo* ch) {
    if (ch->type != CT_Manhole) return;
    if (ch->stts == CS_Disable) return;

    // フレームサイズ
    int frame_w = 96;
    int frame_h = 75;

    switch (ch->manholestts) {
        case Manhole_Closed:
            ch->imgsrc.y = 0 * frame_h;
            break;
        case Manhole_Opened:
            ch->imgsrc.y = 1 * frame_h;
            break;
    }
    ch->imgsrc.w = frame_w;
    ch->imgsrc.h = frame_h;
}

//スタートメニューの描画
void StartMenu(int selectedIndex)
{
    
    static SDL_Texture* startTex = NULL;
    if (!startTex) {
        SDL_Surface* startsurf = IMG_Load("src/start.png");
        if (!startsurf) {
            PrintError("failed to load start.png");
            return;
        }

        startTex = SDL_CreateTextureFromSurface(gGame.render, startsurf);
        SDL_FreeSurface(startsurf);
        if (!startTex) {
            PrintError("failed to create texture from start.png");
            return;
        }
    }

    // 現在のフレームに該当するソースの位置
    SDL_Rect srcRect = {1980 * gStartMenuFrame, 0, 1980, 1080};
    SDL_Rect dstRect = {0, 0, 1980, 1080};

    SDL_RenderClear(gGame.render);
    SDL_RenderCopy(gGame.render, startTex, &srcRect, &dstRect);

    //PlayとQuitボタンの選択
    SDL_Rect start = {830, 770, 240, 120};
    SDL_Rect quitBtn = {830, 930, 240, 120};
    SDL_Rect select = (selectedIndex == 0) ? start : quitBtn;

    SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 0);
    SDL_RenderDrawRect(gGame.render, &select);

    SDL_RenderPresent(gGame.render);
}

//ゲームオーバーの画面出力
void RenderScene(CharaInfo* ch)
{   
    //効果音中止
    Mix_HaltChannel(DANCE_CHANNEL); 
    Mix_HaltChannel(KNOCK_CHANNEL);
    Mix_HaltChannel(WALK_CHANNEL);
    Mix_HaltChannel(MANHOLE_CHANNEL);
    Mix_HaltChannel(WHOOP_CHANNEL);

    //効果音
    if (SlapChunk && !isSlapSoundPlayed) {
        Mix_PlayChannel(SLAP_CHANNEL, SlapChunk, 0);
        isSlapSoundPlayed = SDL_TRUE;
    }

    gGame.stts = GS_GameOver;
    //すべての音楽を停止
    if (Mix_PlayingMusic() == 1) {
        printf("RenderScene: Halting all music.\n");
        Mix_HaltMusic(); 
    }
    isChaseMusicPlaying = SDL_FALSE; 

    // すべてのタイマーを停止
    if (timerID != 0) {
        SDL_RemoveTimer(timerID); timerID = 0;
    }
    if (expTimerID != 0) {
        SDL_RemoveTimer(expTimerID); expTimerID = 0;
    }
    if (UpdateNPCTimerID != 0) {
        SDL_RemoveTimer(UpdateNPCTimerID); UpdateNPCTimerID = 0;
    }

    //暇すぎて死亡
    if(ch->type == CT_Player){    
        SDL_Surface* surf = IMG_Load("src/gameover_by_alone.png");
        if (!surf) {
            PrintError("failed to load gameover_by_villager.png");
            return;
        }

        SDL_Texture* gameoverTex = SDL_CreateTextureFromSurface(gGame.render, surf);
        SDL_FreeSurface(surf);
        if (!gameoverTex) {
            PrintError("failed to create texture from gameover_by_villager.png");
            return;
        }

        SDL_RenderClear(gGame.render);
        SDL_RenderCopy(gGame.render, gameoverTex, NULL, NULL);

        SDL_RenderPresent(gGame.render);
        SDL_DestroyTexture(gameoverTex);
    }
    if(ch->type == CT_Villiger){//住民に捕まって死亡
        SDL_Surface* surf = IMG_Load("src/gameover_by_villager.png");
        if (!surf) {
            PrintError("failed to load gameover_by_villager.png");
            return;
        }

        SDL_Texture* gameoverTex = SDL_CreateTextureFromSurface(gGame.render, surf);
        SDL_FreeSurface(surf);
        if (!gameoverTex) {
            PrintError("failed to create texture from gameover_by_villager.png");
            return;
        }

        SDL_RenderClear(gGame.render);
        SDL_RenderCopy(gGame.render, gameoverTex, NULL, NULL);

        SDL_RenderPresent(gGame.render);
        SDL_DestroyTexture(gameoverTex);
    }
    if(ch->type == CT_Police){//警察に捕まって死亡
        SDL_Surface* surf = IMG_Load("src/policecatch.png");
        if (!surf) {
            PrintError("failed to load policecatch.png");
            return;
        }

        SDL_Texture* gameoverTex = SDL_CreateTextureFromSurface(gGame.render, surf);
        SDL_FreeSurface(surf);
        if (!gameoverTex) {
            PrintError("failed to create texture from policecatch.png");
            return;
        }

        SDL_RenderClear(gGame.render);
        SDL_RenderCopy(gGame.render, gameoverTex, NULL, NULL);

        SDL_RenderPresent(gGame.render);
        SDL_DestroyTexture(gameoverTex);
    }
    if(ch->type == CT_Cross){//Jesusに死亡
        SDL_Surface* surf = IMG_Load("src/gameover_by_jesus.png");
        if (!surf) {
            PrintError("failed to load policecatch.png");
            return;
        }

        SDL_Texture* gameoverTex = SDL_CreateTextureFromSurface(gGame.render, surf);
        SDL_FreeSurface(surf);
        if (!gameoverTex) {
            PrintError("failed to create texture from policecatch.png");
            return;
        }

        SDL_RenderClear(gGame.render);
        SDL_RenderCopy(gGame.render, gameoverTex, NULL, NULL);

        SDL_RenderPresent(gGame.render);
        SDL_DestroyTexture(gameoverTex);
    }
    if(ch->type == CT_Yakuza){//ヤクザに捕まって死亡
        SDL_Surface* surf = IMG_Load("src/gameover_by_yakuza.png");
        if (!surf) {
            PrintError("failed to load yakuzacatch.png");
            return;
        }

        SDL_Texture* gameoverTex = SDL_CreateTextureFromSurface(gGame.render, surf);
        SDL_FreeSurface(surf);
        if (!gameoverTex) {
            PrintError("failed to create texture from policecatch.png");
            return;
        }

        SDL_RenderClear(gGame.render);
        SDL_RenderCopy(gGame.render, gameoverTex, NULL, NULL);

        SDL_RenderPresent(gGame.render);
        SDL_DestroyTexture(gameoverTex);
    }
    if(ch->type == CT_Car){//車にひかれて死亡
        SDL_Surface* surf = IMG_Load("src/gameover_by_car.png");
        if (!surf) {
            PrintError("failed to load policecatch.png");
            return;
        }

        SDL_Texture* gameoverTex = SDL_CreateTextureFromSurface(gGame.render, surf);
        SDL_FreeSurface(surf);
        if (!gameoverTex) {
            PrintError("failed to create texture from policecatch.png");
            return;
        }

        SDL_RenderClear(gGame.render);
        SDL_RenderCopy(gGame.render, gameoverTex, NULL, NULL);

        SDL_RenderPresent(gGame.render);
        SDL_DestroyTexture(gameoverTex);
    }
    SDL_Delay(1000);
    
}

//クリア画面
void ShowClear(void)
{   
    if (Mix_PlayingMusic() == 1) {
        printf("RenderScene: Halting all music.\n");
        Mix_HaltMusic(); // 現在再生中のすべての音楽停止
    }
    
    Mix_HaltChannel(DANCE_CHANNEL); 
    Mix_HaltChannel(KNOCK_CHANNEL); 
    Mix_HaltChannel(WALK_CHANNEL); 
    Mix_HaltChannel(MANHOLE_CHANNEL); 
    Mix_HaltChannel(GAMEOVER_CHANNEL); 
    Mix_HaltChannel(SLAP_CHANNEL); 
    Mix_HaltChannel(WHOOP_CHANNEL); 

    if (ClearChunk) {
        Mix_PlayChannel(CLEAR_CHANNEL, ClearChunk, 0);
    }

    // 1. 黒い画面を先に見せる
    SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 255);
    SDL_RenderClear(gGame.render);
    SDL_RenderPresent(gGame.render);
    SDL_Delay(1000); // 1秒間黒い画面を維持

    // 2. クリア画像のインポート
    SDL_Surface* surf = IMG_Load("src/clear.png");  
    if (!surf) {
        PrintError("failed to load clear.png");
        return;
    }
    SDL_Texture* clearTex = SDL_CreateTextureFromSurface(gGame.render, surf);
    SDL_FreeSurface(surf);
    if (!clearTex) {
        PrintError("failed to create texture from clear.png");
        return;
    }

    // 3. イメージアルファ値どんどん上げる(フェードイン)
    for (int alpha = 0; alpha <= 255; alpha += 5) {
        SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 255);  
        SDL_RenderClear(gGame.render);
        SDL_SetTextureAlphaMod(clearTex, alpha); 
        SDL_RenderCopy(gGame.render, clearTex, NULL, NULL);
        SDL_RenderPresent(gGame.render);
        SDL_Delay(30);  
    }

    SDL_Delay(5000); 
    SDL_DestroyTexture(clearTex);
}

//リスタート画面描画
int ShowRestart(int selectedIndex)
{   
    
    if (Mix_PlayingMusic() == 1) {
        printf("RenderScene: Halting all music.\n");
        Mix_HaltMusic(); // 現在再生中のすべての音楽停止
    }

    SDL_Surface* surf = IMG_Load("src/restart.png");
    if (!surf) {
        PrintError("failed to load restart.png");
        return -1;
    }
    SDL_Texture* restartTex = SDL_CreateTextureFromSurface(gGame.render, surf);
    SDL_FreeSurface(surf);
    if (!restartTex) {
        PrintError("failed to create restart.png texture");
        return -1;
    }

    SDL_SetRenderDrawColor(gGame.render, 0, 0, 0, 0);
    SDL_RenderClear(gGame.render);
    SDL_RenderCopy(gGame.render, restartTex, NULL, NULL);

    //restartとquitボタン選択
    SDL_Rect restart = {880, 850, 200, 80};
    SDL_Rect quitBtn = {880, 930, 200, 80};
    SDL_Rect select = (selectedIndex == 0) ? restart : quitBtn;

    SDL_SetRenderDrawColor(gGame.render, 255, 0, 0, 255);
    SDL_RenderDrawRect(gGame.render, &select);

    SDL_RenderPresent(gGame.render);
    SDL_DestroyTexture(restartTex);

    return selectedIndex == 0 ? 1 : 0;
}

//ドアの前にNPC出現処理
CharaInfo* NpcAppear(SDL_Rect door_rect)
{   
    // 追跡音楽再生
    if (Mix_PlayingMusic() == 0) {
        printf("Switching to chase music\n");
        Mix_HaltMusic();  // 既存音楽中止
        if (Mix_PlayMusic(chaseMusic, -1) == -1) {
            printf("Error playing chase music: %s\n", Mix_GetError());
        }
    }

    if (availableNpcCount == 0) 
        return NULL;
    
    //ノックしたドアの情報をdoorに格納
    CharaInfo* door = NULL;
    for (CharaInfo* c = gCharaHead; c; c = c->next) {
        if (c->type == CT_Door &&
            c->rect.x == door_rect.x &&
            c->rect.y == door_rect.y) {
            door = c;
            break;
        }
    }
    if (!door) 
        return NULL;

    CharaInfo* npc = NULL;
    for (int i = availableNpcCount - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        CharaInfo* tmp = availableNpc[i];
        availableNpc[i] = availableNpc[j];
        availableNpc[j] = tmp;
    }

    //警察署と教会の位置を格納
    SDL_bool PoliceDoor = (door->rect.x == 4200 && door->rect.y == 1100);
    SDL_bool ChurchDoor = (door->rect.x == 250 && door->rect.y == 2450);

    // すでに登場したことのあるNPCのうち、このドアから出てきた人を探す
    for (int i = 0; i < availableNpcCount; i++) {
        if (availableNpc[i]->Doorfrom == door) {
            npc = availableNpc[i];
            break;
        }
    }

    // なければ登場したことのないNPCから選択
    if (!npc) {
        if (PoliceDoor) {
            for (int i = 0; i < availableNpcCount; i++) {
                CharaInfo* c = availableNpc[i];
                if (c->Doorfrom == NULL && c->type == CT_Police) {
                    npc = c;
                    npc->Doorfrom = door;
                    npc->stts = CS_Normal;
                    break;
                }
            }
        }

        if (ChurchDoor) {//イエス・キリストの再臨
            for (int i = 0; i < availableNpcCount; i++) {
                CharaInfo* c = availableNpc[i];
                if (c->Doorfrom == NULL && c->type == CT_Jesus) {
                    npc = c;
                    npc->Doorfrom = door;
                    npc->stts = CS_Normal;
                    npc->jesusBornTime = SDL_GetTicks();
                    break;
                }
            }
        }

        // 一般探索(ここにヤクザ登場条件追加)
        if (!npc) {
            for (int i = 0; i < availableNpcCount; i++) {
                CharaInfo* c = availableNpc[i];
                if (c->Doorfrom == NULL) {
                    // 警察、Jesusの条件をフィルタリング
                    if ((c->type == CT_Police && !PoliceDoor) || (c->type == CT_Jesus && !ChurchDoor))
                        continue;

                    // ヤクザ条件:プレイヤーレベル1以上でランダムに登場
                    if (c->type == CT_Yakuza) {
                        if (gGame.player->level < 1) 
                            continue; //レベル不足なら移る
                        if (rand() % 100 >= 40)  // 40%の確率
                            continue;
                    }
                    npc = c;
                    npc->Doorfrom = door;
                    if (c->type == CT_Yakuza) {
                        gGame.stts = GS_YakuzaScene;
                    }
                    break;
                }
            }
        }
    }

    if (!npc) 
        return NULL;

    //出現位置補正
    npc->point.x = door_rect.x + 30;
    npc->point.y = door_rect.y + 100;
    npc->rect.x = (int)npc->point.x;
    npc->rect.y = (int)npc->point.y;
    if(npc -> type != CT_Yakuza){
       npc->stts = CS_Normal;   
    }
    npc->Doorfrom = NULL;

    return npc; 
}
