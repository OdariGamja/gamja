#ifndef SERVER_SYSTEM_H
#define SERVER_SYSTEM_H
#define TICK_MS 33

#define THROW_POWER_X 5000.0f
#define THROW_POWER_UP 50000.0f
#define THROW_POWER_DOWN 7000.0f
#define THROW_GRAVITY 15000.0f

#define FALL_WAIT_MS 1000

// 停電イベント用設定 by yzk
#define BLACKOUT_DELAY_MS 2000    // スイッチを押してから停電するまでの時間 (2秒)
#define BLACKOUT_TIME_MS 5000     // 停電が続く時間 (10秒)
#define BLACKOUT_COOLDOWN_MS 3000 // 停電終了後、再使用可能になるまでの時間
// ここまでyzk

#include "game.h"

extern CharaInfo *SevergCharaHead;

extern SDL_Rect fallRect;
extern SDL_Rect fallRect2;

typedef struct
{
    float x;
    float y;
} RespawnPoint;

extern RespawnPoint gRespawnPoints[4];

// �?�??????��?��????��?��???????? NPC ???????????��?��?��???????????
int InitServerChara(const char *position_data_file, CharaInfo players[], int max_players);

// �?�???��??
SDL_bool CollisionPlayer(CharaInfo *a, CharaInfo *b);
SDL_bool Collision(CharaInfo *ci, CharaInfo *cj);
SDL_bool FlyCollision(CharaInfo *a, CharaInfo *b);
int PrintError(const char *msg);
void UpdateScaleServer(CharaInfo *ch);
long long now_ms();
void Attack(CharaInfo *ch); //??��???????????
void UpdateAttackRects(CharaInfo *ch);
void TrapInTrain(CharaInfo *ch);
extern int traindoor;
extern int InTheTrain;
extern int TrapHumanSpeed;
extern int uptrainx;
extern int InTheRail;

void MergeSinkansenPlayerPoint(CharaInfo *ch);
void ThrowObject(CharaInfo *ch);
void UpdateATM(CharaInfo *atm);
void UpdateKnockdown(CharaInfo *ch);
void ReleaseHold(CharaInfo *holder, CharaInfo *obj);
void UpdateVendor(CharaInfo *ch);
void CheckDeathZone(CharaInfo *ch, SDL_Rect fallRect);
void RespawnCheck(CharaInfo *ch);
void UpdateFall(CharaInfo *ch, SDL_Rect fallRect);
void KillPlayer(CharaInfo *ch);
void UpdateInvincible(CharaInfo *ch);
void StartHitByTrain(CharaInfo *ch);
void UpdateHitByTrain(CharaInfo *ch);
void UpdateTrainRailFall(CharaInfo *ch);

// by yzk
void UpdatePillar_L(CharaInfo *ch);
void HitPillar_L(CharaInfo *pillar, CharaInfo *attacker);
// ここまで yzk
#endif
