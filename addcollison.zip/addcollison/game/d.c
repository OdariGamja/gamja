#include <SDL2/SDL.h>
#include <stdio.h>
#include "server_system.h"

#define WIN_W 800
#define WIN_H 600

int main()
{
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stderr, "SDL Init Error: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Window* win = SDL_CreateWindow("Hitbox Debug", 100, 100, WIN_W, WIN_H, 0);
    SDL_Renderer* rend = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);

    if (!win || !rend) {
        fprintf(stderr, "SDL Create Error: %s\n", SDL_GetError());
        return 1;
    }

    // 初期化（NPCとプレイヤー）
    InitServerChara("position.data");

    int running = 1;
    SDL_Event e;
    while (running) {
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) running = 0;
        }

        SDL_SetRenderDrawColor(rend, 0, 0, 0, 255); // 黒背景
        SDL_RenderClear(rend);

        // NPCを赤で描画
        SDL_SetRenderDrawColor(rend, 255, 0, 0, 255);
        for (CharaInfo* npc = SevergCharaHead; npc; npc = npc->next) {
            SDL_RenderDrawRect(rend, &npc->rect);
        }

        // プレイヤーを緑で描画
        SDL_SetRenderDrawColor(rend, 0, 255, 0, 255);
        for (CharaInfo* pl = PlayerCharaHead; pl; pl = pl->next) {
            SDL_RenderDrawRect(rend, &pl->rect);
        }

        SDL_RenderPresent(rend);

        SDL_Delay(100); // 10fpsくらいで更新
    }

    SDL_DestroyRenderer(rend);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}
