#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/time.h>
#include <math.h>
#include "game.h"

#define PORT 5000
#define MAX_CLIENT 4
#define TICK_MS 33

typedef struct { float x, y; } NetPos;

int clients[MAX_CLIENT];
struct sockaddr_in client_addr[MAX_CLIENT];
socklen_t client_len[MAX_CLIENT];
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;

CharaInfo players[MAX_CLIENT];

ssize_t writen_udp(int fd, void *buf, size_t n, struct sockaddr_in *addr){
    return sendto(fd, buf, n, 0, (struct sockaddr*)addr, sizeof(*addr));
}

void MoveServer(CharaInfo *ch){
    if(!ch) return;
    float vx=0, vy=0;
    if(ch->input.right) vx+=MOVE_SPEED;
    if(ch->input.left) vx-=MOVE_SPEED;
    if(ch->input.down) vy+=MOVE_SPEED;
    if(ch->input.up) vy-=MOVE_SPEED;
    if(vx && vy){ vx/=sqrtf(2); vy/=sqrtf(2); }
    ch->point.x+=vx; ch->point.y+=vy;
    ch->rect.x=(int)ch->point.x; ch->rect.y=(int)ch->point.y;
}

long long now_ms(){ struct timeval tv; gettimeofday(&tv,NULL); return (long long)tv.tv_sec*1000+tv.tv_usec/1000; }

void* RecvLoop(void* a){
    int fd = *(int*)a;
    Keystts inp;
    struct sockaddr_in from;
    socklen_t fromlen = sizeof(from);

    while(1){
        ssize_t r = recvfrom(fd, &inp, sizeof(inp), 0, (struct sockaddr*)&from, &fromlen);
        if(r<=0) continue;

        int id=-1;
        pthread_mutex_lock(&mtx);
        // 클라이언트 주소가 기존에 없으면 새 ID 할당
        for(int i=0;i<MAX_CLIENT;i++){
            if(clients[i]==0){
                clients[i]=1;
                client_addr[i]=from;
                client_len[i]=fromlen;
                id=i; break;
            } else if(client_addr[i].sin_addr.s_addr==from.sin_addr.s_addr && client_addr[i].sin_port==from.sin_port){
                id=i; break;
            }
        }
        if(id>=0) players[id].input=inp;
        pthread_mutex_unlock(&mtx);
    }
    return NULL;
}

void* GameLoop(void* a){
    long long last = now_ms();
    while(1){
        long long cur = now_ms();
        long long dt = cur-last;
        if(dt<TICK_MS){ usleep((TICK_MS-dt)*1000); continue; }
        last=cur;

        pthread_mutex_lock(&mtx);
        for(int i=0;i<MAX_CLIENT;i++) MoveServer(&players[i]);

        NetPos pack[MAX_CLIENT];
        for(int i=0;i<MAX_CLIENT;i++){ pack[i].x=players[i].point.x; pack[i].y=players[i].point.y; }

        for(int i=0;i<MAX_CLIENT;i++){
            if(clients[i]) writen_udp(*(int*)a, pack, sizeof(pack), &client_addr[i]);
        }
        pthread_mutex_unlock(&mtx);
    }
    return NULL;
}

int main(){
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in addr={0};
    addr.sin_family=AF_INET;
    addr.sin_port=htons(PORT);
    addr.sin_addr.s_addr=INADDR_ANY;

    bind(s,(struct sockaddr*)&addr,sizeof(addr));

    pthread_t recv_th, game_th;
    pthread_create(&recv_th,NULL,RecvLoop,&s);
    pthread_create(&game_th,NULL,GameLoop,&s);

    pthread_join(recv_th,NULL);
    pthread_join(game_th,NULL);
    return 0;
}
