//system.c

#include "game.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_LINEBUF 256

GameInfo gGames[CHARATYPE_NUM];  // 모든 플레이어 상태
CharaInfo* gCharaHead = NULL;    // 캐릭터 리스트 헤드
CharaTypeInfo gCharaType[CHARATYPE_NUM];
char gImgFilePath[CHARATYPE_NUM][MAX_PATH];

typedef enum { AD_LR, AD_UD, AD_NONE } AdjustDir;

int PrintError(const char* msg) {
    fprintf(stderr, "Error: %s\n", msg);
    return -1;
}

int InitSystem(const char* chara_data_file, const char* position_data_file, int my_id) {
    int ret = 0;
    FILE* fp = fopen(chara_data_file, "r");
    if (!fp) return PrintError("failed to open chara data file.");

    int typeno = 0;
    char linebuf[MAX_LINEBUF];
    while (fgets(linebuf, MAX_LINEBUF, fp)) {
        if (linebuf[0] == '#') continue;
        if (typeno < CHARATYPE_NUM) {
            if (3 != sscanf(linebuf, "%d%d%s",
                            &gCharaType[typeno].w,
                            &gCharaType[typeno].h,
                            gImgFilePath[typeno])) {
                ret = PrintError("failed to read the chara image data.");
                goto CLOSE_CHARA;
            }
            gCharaType[typeno].path = gImgFilePath[typeno];
            typeno++;
        }
    }
CLOSE_CHARA:
    fclose(fp);
    if (ret < 0) return ret;

    fp = fopen(position_data_file, "r");
    if (!fp) return PrintError("failed to open position data file.");

    gCharaHead = NULL;
    for (int i = 0; i < CHARATYPE_NUM; i++) {
        gGames[i].player = NULL;
        memset(&gGames[i].input, 0, sizeof(gGames[i].input));
    }

    while (fgets(linebuf, MAX_LINEBUF, fp)) {
        if (linebuf[0] == '#') continue;
        CharaInfo* ch = malloc(sizeof(CharaInfo));
        if (!ch) { ret = PrintError("failed to allocate chara"); goto CLOSE_POSITION; }
        ch->next = gCharaHead;
        gCharaHead = ch;

        if (7 != sscanf(linebuf, "%u%f%f%d%d%d%d",
                        (unsigned int*)&ch->type,
                        &ch->point.x,
                        &ch->point.y,
                        &ch->rect.x,
                        &ch->rect.y,
                        &ch->rect.w,
                        &ch->rect.h)) {
            ret = PrintError("failed to load position data"); goto CLOSE_POSITION;
        }
        if (ch->type >= CHARATYPE_NUM) { free(ch); continue; }
        ch->entity = &gCharaType[ch->type];
        InitCharaInfo(ch);
    }

    // 현재 플레이어 설정
    GameInfo* game = &gGames[my_id];
    game->player = NULL;
    for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
        if (ch->type == CT_PLAYER0 + my_id) {
            game->player = ch;
            break;
        }
    }
    if (!game->player) ret = PrintError("Player init failed");

CLOSE_POSITION:
    fclose(fp);
    return ret;
}


//オブゼット状態初期化
void InitCharaInfo(CharaInfo* ch) {
    if (!ch || ch->type >= CHARATYPE_NUM) return;
    ch->entity = &gCharaType[ch->type];
    ch->stts = CS_Normal;
    ch->vel.x = ch->vel.y = 0;
    ch->point.x = (int)ch->point.x;
    ch->point.y = (int)ch->point.y;
    ch->ani.x = 0;
    ch->rect.w = ch->entity->w;
    ch->rect.h = ch->entity->h;
    ch->rect.x = (int)ch->point.x;
    ch->rect.y = (int)ch->point.y;
    ch->imgsrc.x = ch->imgsrc.y = 0;
    ch->imgsrc.w = ch->entity->w;
    ch->imgsrc.h = ch->entity->h;
}


void MoveChara(CharaInfo* ch, GameInfo* game) {
    if (!ch || !game) return;
    if (!ch || ch->stts == CS_Disable) return; // 움직일 수 없는 상태면 무시

    //printf("[DEBUG PTR] ch=%p type=%d pos=%p\n", ch, ch->type, &ch->point);

    

    float vx = 0, vy = 0;
    Keystts* input = &ch->input;

    if (input->right) vx += MOVE_SPEED;
    if (input->left)  vx -= MOVE_SPEED;
    if (input->down)  vy += MOVE_SPEED;
    if (input->up)    vy -= MOVE_SPEED;

    // 대각선 이동 보정
    if (vx != 0 && vy != 0) {
        vx /= sqrtf(2.0f);
        vy /= sqrtf(2.0f);
    }

    // 위치 갱신
    ch->point.x += vx;
    ch->point.y += vy;

    // 화면 밖으로 못 나가게 제한
    if (ch->point.x < 0) ch->point.x = 0;
    if (ch->point.y < 0) ch->point.y = 0;
    if (ch->point.x + ch->rect.w > MAP_Width)  ch->point.x = MAP_Width - ch->rect.w;
    if (ch->point.y + ch->rect.h > MAP_Height) ch->point.y = MAP_Height - ch->rect.h;

    // rect 위치 갱신
    ch->rect.x = (int)ch->point.x;
    ch->rect.y = (int)ch->point.y;
}


SDL_bool InputEvent(GameInfo* game) {
    if (!game) return SDL_FALSE;

    SDL_Event e;
    SDL_bool running = SDL_TRUE;

    while (SDL_PollEvent(&e)) {
        switch (e.type) {
            case SDL_QUIT:
                running = SDL_FALSE;
                break;

            case SDL_KEYDOWN:
                switch (e.key.keysym.sym) {
                    case SDLK_d: game->input.right = SDL_TRUE; break;
                    case SDLK_a: game->input.left  = SDL_TRUE; break;
                    case SDLK_s: game->input.down  = SDL_TRUE; break;
                    case SDLK_w: game->input.up    = SDL_TRUE; break;
                    case SDLK_SPACE: game->input.space = SDL_TRUE; break;
                    case SDLK_ESCAPE: running = SDL_FALSE; break;
                }
                break;

            case SDL_KEYUP:
                switch (e.key.keysym.sym) {
                    case SDLK_d: game->input.right = SDL_FALSE; break;
                    case SDLK_a: game->input.left  = SDL_FALSE; break;
                    case SDLK_s: game->input.down  = SDL_FALSE; break;
                    case SDLK_w: game->input.up    = SDL_FALSE; break;
                    case SDLK_SPACE: game->input.space = SDL_FALSE; break;
                }
                break;
        }
    }

    return running;
}



void DestroySystem(void) {
    CharaInfo* ch = gCharaHead;
    while (ch) {
        CharaInfo* next = ch->next;
        free(ch);
        ch = next;
    }
    gCharaHead = NULL;
}

