// window.c
#include "game.h"
#include <SDL2/SDL_image.h>
#include <stdlib.h>

extern CharaInfo *gCharaHead;

//========================
// ウインドウ初期化
//========================
int InitWindow(GameInfo *gGame, const char *title, const char *bg_file, int width, int height)
{
    printf("[INIT] InitWindow() called\n");

    if ((IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG) != IMG_INIT_PNG)
        return PrintError("failed to initialize SDL_image");

    gGame->window = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                     width, height, SDL_WINDOW_FULLSCREEN_DESKTOP);//SDL_WINDOW_FULLSCREEN_DESKTOP

    printf("[INIT] window=%p\n", gGame->window);

    gGame->render = SDL_CreateRenderer(gGame->window, -1, SDL_RENDERER_ACCELERATED);
    printf("[INIT] renderer=%p\n", gGame->render);

    // 배경 로드
    SDL_Surface *surf = IMG_Load(bg_file);
    printf("[INIT] background surface=%p (%s)\n", surf, bg_file);

    gGame->bg = SDL_CreateTextureFromSurface(gGame->render, surf);
    SDL_FreeSurface(surf);
    printf("[INIT] background texture=%p\n", gGame->bg);

    // 캐릭터 로드
    for (int i = 0; i < CHARATYPE_NUM; i++)
    {
        printf("\n[INIT] LOADING CHARACTER TYPE %d\n", i);

        SDL_Surface *s = IMG_Load(gCharaType[i].path);
        if (!s) return PrintError("failed to load character image");

        printf("[INIT] character surface=%p path=%s size=%d x %d\n",
               s, gCharaType[i].path, s->w, s->h);

        gCharaType[i].img = SDL_CreateTextureFromSurface(gGame->render, s);

        printf("[INIT] gCharaType[%d].img=%p\n", i, gCharaType[i].img);

        int fullW = s->w;
        int fullH = s->h;
        int frameW = gCharaType[i].w;
        int frameH = gCharaType[i].h;

        gCharaType[i].aninum.x = fullW / frameW;
        gCharaType[i].aninum.y = fullH / frameH;

        printf("[INIT] Frames: %d x %d (frame size %d x %d)\n",
               gCharaType[i].aninum.x, gCharaType[i].aninum.y,
               frameW, frameH);

        SDL_FreeSurface(s);
    }

    gGame->cam.x = 0;
    gGame->cam.y = 0;
    gGame->cam.w = WD_Width;
    gGame->cam.h = WD_Height;

    printf("[INIT] Camera initialized (%d,%d,%d,%d)\n",
           gGame->cam.x, gGame->cam.y, gGame->cam.w, gGame->cam.h);

    return 0;
}




//========================
// ゲーム描画
//========================
void DrawGame(GameInfo *gGame)
{
    /*printf("\n[DRAW] DrawGame() frame start\n");
    printf("[DRAW] Camera = (%d,%d)\n", gGame->cam.x, gGame->cam.y);*/

    SDL_RenderClear(gGame->render);

    SDL_Rect camRect = { gGame->cam.x, gGame->cam.y, gGame->cam.w, gGame->cam.h };
    SDL_Rect dstBg = { 0, 0, gGame->cam.w, gGame->cam.h };

    SDL_RenderCopy(gGame->render, gGame->bg, &camRect, &dstBg);

    // 臨時配列で Chara Info* コピー
    CharaInfo* arr[128]; // 最大キャラクター数
    int n = 0;
    for (CharaInfo* ch = gCharaHead; ch; ch = ch->next)
        arr[n++] = ch;

    // y値を基準に昇順整列
    for (int i = 0; i < n-1; i++) {
        for (int j = i+1; j < n; j++) {
            if(arr[i]->type == CT_COIN){//coinの場合の出力順番補正
                if (arr[i]->point.y > 208 + arr[j]->point.y) {
                    CharaInfo* tmp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = tmp;
                }
            }else if (arr[i]->point.y > arr[j]->point.y) {
                CharaInfo* tmp = arr[i];
                arr[i] = arr[j];
                arr[j] = tmp;
                }
        }
    }

    // 整列された順序で描く
    for (int i = 0; i < n; i++) {
        CharaInfo* ch = arr[i];
        if (ch->type == CT_COIN && ch->stts != CS_Normal){
            continue;
        }


        float yMin = 500.0f;
        float yMax = 1200.0f;
        float scaleMin = 0.5f;
        float scaleMax = 1.8f;

        float t = (ch->point.y - yMin) / (yMax - yMin);
        if (t < 0) t = 0;
        if (t > 1) t = 1;
        float scale = scaleMin + t * (scaleMax - scaleMin);

        SDL_Rect dst = {
            (int)(ch->point.x - gGame->cam.x),
            (int)(ch->point.y - gGame->cam.y),
            (int)(ch->rect.w * scale),
            (int)(ch->rect.h * scale)
        };

        SDL_RenderCopy(gGame->render, ch->entity->img, &ch->imgsrc, &dst);
    }
    SDL_RenderPresent(gGame->render);
}





//========================
// アニメーション更新
//========================
void UpdateAnimation(GameInfo *gGame, float dt)
{
    for (CharaInfo *ch = gCharaHead; ch; ch = ch->next)
    {
        int maxX = ch->entity->aninum.x;  // 가로 프레임 개수

        /* ------------------------------------------------------
           1) movesttsによるani.y(縦行)設定
           ------------------------------------------------------ */
        switch (ch->movestts)
        {
            case ANI_Stop:
                ch->ani.y = 0;    // 停止
                break;

            case ANI_RunRight:
                ch->ani.y = 0;    // 右
                break;

            case ANI_RunLeft:
                ch->ani.y = 0;    // 左　
                break;

            case ANI_RunDown:
                ch->ani.y = 0;    // 下
                break;

            case ANI_RunUp:
                ch->ani.y = 0;    // 上
                break;
        }

        /* ------------------------------------------------------
           2) キャラクター別フレーム時間累積(acc)を別に保存しなければならない
           ------------------------------------------------------ */
        ch->aniTimer += dt;   

        if (ch->aniTimer >= 0.05f)   // 0.05秒ごとにフレーム++ 
        {
            ch->ani.x++;
            if (ch->ani.x >= maxX)
                ch->ani.x = 0;

            ch->aniTimer = 0;
        }

        /* ------------------------------------------------------
           3) スプライトシート座標計算
           ------------------------------------------------------ */
        int frameW = ch->entity->w;
        int frameH = ch->entity->h;

        ch->imgsrc.x = ch->ani.x * frameW;
        ch->imgsrc.y = ch->ani.y * frameH;
        ch->imgsrc.w = frameW;
        ch->imgsrc.h = frameH;
    }
}





//========================
// カメラアップデート
//========================
void UpdateCamera(GameInfo* gGame, CharaInfo* player)
{
    float px = player->point.x + player->rect.w / 2;
    float py = player->point.y + player->rect.h / 2;

    // ズーム計算
    float yMin = 500.0f;      // ズーム最大(拡大)
    float yMax = 800.0f;     // ズーム最小(基本)
    float zoomMin = 1.0f;     // yMax
    float zoomMax = 1.8f;     // yMin

    float t = (py - yMin) / (yMax - yMin);
    if (t < 0) t = 0;
    if (t > 1) t = 1;

    float zoom = zoomMax - t * (zoomMax - zoomMin);  // 線形補正

    // SDL全体のレンダリングにスケール適用
    SDL_RenderSetScale(gGame->render, zoom, zoom);

    // カメラは常に同じサイズ（ウィンドウサイズのまま）
    float targetX = px - (gGame->cam.w / 2) / zoom;
    float targetY = py - (gGame->cam.h / 2) / zoom;

    // マップ境界チェック
    if (targetX < 0) targetX = 0;
    if (targetY < 0) targetY = 0;
    if (targetX > MAP_Width  - gGame->cam.w / zoom)
        targetX = MAP_Width  - gGame->cam.w / zoom;
    if (targetY > MAP_Height - gGame->cam.h / zoom)
        targetY = MAP_Height - gGame->cam.h / zoom;

    gGame->cam.x = (int)targetX;
    gGame->cam.y = (int)targetY;

    printf("[CAM] y=%.0f zoom=%.2f cam=(%d,%d) cam w h =(%d,%d)\n", py, zoom, gGame->cam.x, gGame->cam.y,gGame->cam.w, gGame->cam.h);
}





//========================
// 종료 처리
//========================
void CloseWindow(GameInfo *gGame)
{
    printf("[CLOSE] CloseWindow()\n");

    if (!gGame)
        return;

    if (gGame->bg)
        printf("[CLOSE] Destroying background\n"), SDL_DestroyTexture(gGame->bg);

    for (int i = 0; i < CHARATYPE_NUM; i++)
    {
        if (gCharaType[i].img) {
            printf("[CLOSE] Destroy char texture %d\n", i);
            SDL_DestroyTexture(gCharaType[i].img);
        }
    }

    if (gGame->render)
        printf("[CLOSE] Destroy renderer\n"), SDL_DestroyRenderer(gGame->render);
    if (gGame->window)
        printf("[CLOSE] Destroy window\n"), SDL_DestroyWindow(gGame->window);

    IMG_Quit();
}
