// simplified_client_fixed.c
// 修正版クライアント：non-blocking recv + damp補間 + input rate limit + no SDL_AddTimer

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <netinet/tcp.h>   // ← 追加

#include "game.h"

#define PORT 5000
#define MAX_CLIENT 4
extern CharaInfo *gCharaHead;
typedef struct { float x,y; } NetPos;

int my_id = 0;
int sock = -1;
NetPos latest[MAX_CLIENT];
pthread_mutex_t pm = PTHREAD_MUTEX_INITIALIZER;

/* network helpers */
ssize_t writen(int fd, const void *buf, size_t n) {
    size_t left = n; const char *p = buf;
    while (left > 0) {
        ssize_t w = write(fd, p, left);
        if (w <= 0) return -1;
        left -= w; p += w;
    }
    return n;
}

/* recv thread: non-blocking recv, only latest snapshot is kept */
void *RecvLoop(void *arg) {
    (void)arg;
    while (1) {
        NetPos buf[MAX_CLIENT];
        ssize_t r = recv(sock, buf, sizeof(buf), 0);
        if (r == (ssize_t)sizeof(buf)) {
            pthread_mutex_lock(&pm);
            memcpy(latest, buf, sizeof(buf));
            pthread_mutex_unlock(&pm);
            continue;
        } else if (r == 0) {
            // server closed
            break;
        } else if (r < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                // no data now
                usleep(1000); // 1ms backoff
                continue;
            } else {
                perror("recv");
                break;
            }
        } else {
            // partial read: try to accumulate? for simplicity drop partial
            usleep(1000);
            continue;
        }
    }
    return NULL;
}

/* send input (simple wrapper) */
void SendInput(Keystts *input) {
    if (!input) return;
    if (writen(sock, input, sizeof(Keystts)) != sizeof(Keystts)) {
        // non-fatal: we'll print once
        perror("SendInput write failed");
    }
}

/* Exponential damping helper for smooth follow */
static inline float damp_alpha(float responsiveness, float dt) {
    // responsiveness: larger -> faster follow. dt in seconds.
    return 1.0f - expf(-responsiveness * dt);
}

int main(int argc, char *argv[]) {
    if (argc < 3) { printf("usage: %s <id> <server-ip>\n", argv[0]); return 1; }
    my_id = atoi(argv[1]);

    // init game structures and window (uses your existing system/window code)
    InitSystem("chara.data", "position.data", my_id);
    InitWindow(&gGames[my_id], "Test", "bg.png", 1280, 720);

    // initial latest positions from file
    for (CharaInfo *ch = gCharaHead; ch; ch = ch->next) {
        if (ch->type >= CT_PLAYER0 && ch->type < CT_PLAYER0 + MAX_CLIENT) {
            int i = ch->type - CT_PLAYER0;
            latest[i].x = ch->point.x;
            latest[i].y = ch->point.y;
        }
    }

    // connect
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) { perror("socket"); return 1; }

    struct sockaddr_in sv = {0};
    sv.sin_family = AF_INET;
    sv.sin_port = htons(PORT);
    inet_pton(AF_INET, argv[2], &sv.sin_addr);

    if (connect(sock, (struct sockaddr *)&sv, sizeof(sv)) < 0) {
        perror("connect");
        close(sock);
        return 1;
    }

    // disable Nagle
    int flag = 1;
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));

    // make socket non-blocking for recv thread
    int flags = fcntl(sock, F_GETFL, 0);
    fcntl(sock, F_SETFL, flags | O_NONBLOCK);

    // start recv thread
    pthread_t rth;
    pthread_create(&rth, NULL, RecvLoop, NULL);
    pthread_detach(rth);

    // remove SDL_AddTimer usage; use our main loop
    // main fixed-timestep loop for client rendering (60 fps)
    const Uint32 CLIENT_TICK_MS = 16;
    Uint32 next_tick = SDL_GetTicks() + CLIENT_TICK_MS;
    Uint32 last_time = SDL_GetTicks();

    // input send rate limiting (e.g. 30 Hz)
    Uint32 lastSend = 0;
    const Uint32 SEND_INTERVAL_MS = 33;

    SDL_bool running = SDL_TRUE;
    while (running) {
        Uint32 now = SDL_GetTicks();
        if (now < next_tick) {
            // short sleep to avoid busyspin, but keep accuracy
            SDL_Delay(1);
            continue;
        }

        // compute delta (seconds)
        float dt = (now - last_time) / 1000.0f;
        last_time = now;

        // input handling (updates gGames[my_id].input)
        running = InputEvent(&gGames[my_id]);

        // rate-limit input sends
        if (now - lastSend >= SEND_INTERVAL_MS) {
            SendInput(&gGames[my_id].input);
            lastSend = now;
        }

        // apply server-sent latest positions to local characters using damped interpolation
        pthread_mutex_lock(&pm);
        CharaInfo *ch = gCharaHead;
        int i = 0;
        const float responsiveness = 12.0f; // higher = snappier
        float a = damp_alpha(responsiveness, dt);
        for (i = 0; i < MAX_CLIENT && ch; i++, ch = ch->next) {
            ch->point.x += (latest[i].x - ch->point.x) * a;
            ch->point.y += (latest[i].y - ch->point.y) * a;
            ch->rect.x = (int)ch->point.x;
            ch->rect.y = (int)ch->point.y;
        }
        pthread_mutex_unlock(&pm);

        // animation update using dt
        UpdateAnimation(&gGames[my_id], dt);

        // draw
        DrawGame(&gGames[my_id]);

        // advance tick & drift correction
        next_tick += CLIENT_TICK_MS;
        Uint32 now2 = SDL_GetTicks();
        if (now2 > next_tick + CLIENT_TICK_MS) next_tick = now2 + CLIENT_TICK_MS;
    }

    // cleanup
    CloseWindow(&gGames[my_id]);
    DestroySystem();
    close(sock);
    return 0;
}
