// improved_client_prediction.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <netinet/tcp.h>
#include <math.h>
#include <stdint.h>
#include <errno.h>
#include <sys/time.h>
#include "game.h"

#define PORT 5000
#define MAX_CLIENT 4

typedef struct { uint32_t seq; float x,y; } NetPos;

int my_id, sock;
NetPos latest[MAX_CLIENT];
uint32_t last_seq[MAX_CLIENT];
float pred_x[MAX_CLIENT], pred_y[MAX_CLIENT];
float last_vx[MAX_CLIENT], last_vy[MAX_CLIENT];
long long last_recv_time[MAX_CLIENT];
pthread_mutex_t pm = PTHREAD_MUTEX_INITIALIZER;

extern CharaInfo *gCharaHead;

// -------------------------- 유틸 --------------------------
static long long now_ms() {
    struct timeval tv; gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec*1000 + tv.tv_usec/1000;
}

ssize_t readn(int fd, void *buf, size_t n) {
    size_t left = n; char *p = buf;
    while(left>0){
        ssize_t r = read(fd,p,left);
        if(r<0){ if(errno==EINTR) continue; return -1;}
        if(r==0) return (n-left);
        left -= r; p+=r;
    }
    return n;
}
ssize_t writen(int fd, const void *buf, size_t n) {
    size_t left=n; const char* p=buf;
    while(left>0){
        ssize_t w = write(fd,p,left);
        if(w<=0){ if(errno==EINTR) continue; return -1; }
        left -= w; p+=w;
    }
    return n;
}

// -------------------------- 수신 스레드 --------------------------
void *RecvLoop(void *a) {
    int flag=1; setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &flag,sizeof(flag));
    NetPos buf[MAX_CLIENT];

    while(1){
        ssize_t r = readn(sock, buf, sizeof(buf));
        long long now = now_ms();
        if(r<=0){ fprintf(stderr,"[RecvLoop] readn failed r=%zd\n",r); break; }

        pthread_mutex_lock(&pm);
        for(int i=0;i<MAX_CLIENT;i++){
            uint32_t seq = buf[i].seq;
            if(seq==0) continue;
            if(last_seq[i]!=0 && seq>last_seq[i]+1){
                uint32_t lost = seq - last_seq[i] -1;
                printf("[SEQ GAP] player=%d lost=%u\n",i,lost);
            }
            if(seq<=last_seq[i]) continue;
            // ------------------- 속도 예측 계산 -------------------
            float dt = 0.033f; // 서버 tick 가정
            last_vx[i] = (buf[i].x - latest[i].x)/dt;
            last_vy[i] = (buf[i].y - latest[i].y)/dt;
            pred_x[i] = buf[i].x;
            pred_y[i] = buf[i].y;
            last_recv_time[i] = now;

            latest[i] = buf[i];
            last_seq[i] = seq;
        }
        pthread_mutex_unlock(&pm);
    }
    close(sock);
    return NULL;
}

// -------------------------- 입력 전송 --------------------------
void SendInput(Keystts *input){
    long long t0=SDL_GetTicks();
    ssize_t w=writen(sock,input,sizeof(Keystts));
    long long t1=SDL_GetTicks();
    if(t1-t0>30) printf("[WARN] SendInput slow: %lld ms\n", t1-t0);
    if(w!=sizeof(Keystts)) printf("write failed: %zd\n",w);
}

// -------------------------- 애니메이션 --------------------------
Uint32 AnimCB(Uint32 i, void *p){ UpdateAnimation((GameInfo*)p,i/1000.0f); return i; }

// -------------------------- 메인 --------------------------
int main(int argc,char*argv[]){
    if(argc<3){ printf("usage: <id> <server-ip>\n"); return 0; }
    my_id=atoi(argv[1]);

    InitSystem("chara.data","position.data",my_id);
    InitWindow(&gGames[my_id],"Test","bg.png",1280,720);

    for(int i=0;i<MAX_CLIENT;i++){
        latest[i].seq=0; latest[i].x=0; latest[i].y=0;
        last_seq[i]=0; pred_x[i]=0; pred_y[i]=0;
        last_vx[i]=0; last_vy[i]=0; last_recv_time[i]=0;
    }

    for(CharaInfo*ch=gCharaHead; ch; ch=ch->next){
        if(ch->type>=CT_PLAYER0 && ch->type<CT_PLAYER0+MAX_CLIENT){
            int i = ch->type-CT_PLAYER0;
            latest[i].x=ch->point.x; latest[i].y=ch->point.y;
            pred_x[i]=ch->point.x; pred_y[i]=ch->point.y;
        }
    }

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if(sock<0){ perror("socket"); return 1; }

    struct sockaddr_in sv={0};
    sv.sin_family=AF_INET;
    sv.sin_port=htons(PORT);
    inet_pton(AF_INET, argv[2], &sv.sin_addr);

    int flag=1;
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &flag,sizeof(flag));
    if(connect(sock,(struct sockaddr*)&sv,sizeof(sv))<0){ perror("connect"); close(sock); return 1;}

    pthread_t th;
    if(pthread_create(&th,NULL,RecvLoop,NULL)!=0){ perror("pthread_create"); close(sock); return 1;}
    pthread_detach(th);

    SDL_AddTimer(16,AnimCB,&gGames[my_id]);

    Uint32 last_sdl = SDL_GetTicks();
    SDL_bool run=SDL_TRUE;

    while(run){
        Uint32 now_sdl=SDL_GetTicks();
        float dt=(now_sdl-last_sdl)/1000.0f;
        gGames[my_id].timeDelta=dt;
        last_sdl=now_sdl;

        run=InputEvent(&gGames[my_id]);
        SendInput(&gGames[my_id].input);

        pthread_mutex_lock(&pm);
        CharaInfo *ch=gCharaHead;
        for(int i=0;i<MAX_CLIENT && ch;i++,ch=ch->next){
            // ------------------- 예측 기반 위치 적용 -------------------
            long long elapsed = now_ms() - last_recv_time[i];
            float px = pred_x[i] + last_vx[i]*elapsed/1000.0f;
            float py = pred_y[i] + last_vy[i]*elapsed/1000.0f;

            float dx = px - ch->point.x;
            float dy = py - ch->point.y;
            float dist = sqrtf(dx*dx + dy*dy);

            if(dist>200.0f){
                ch->point.x = px;
                ch->point.y = py;
            } else {
                float t = fminf(1.0f, dt*10.0f);
                ch->point.x += dx*t;
                ch->point.y += dy*t;
            }
            ch->rect.x=(int)ch->point.x;
            ch->rect.y=(int)ch->point.y;
        }
        pthread_mutex_unlock(&pm);

        DrawGame(&gGames[my_id]);
        SDL_Delay(8);
    }

    CloseWindow(&gGames[my_id]);
    DestroySystem();
    close(sock);
    return 0;
}
