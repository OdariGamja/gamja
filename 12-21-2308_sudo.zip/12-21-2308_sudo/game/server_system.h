#ifndef SERVER_SYSTEM_H
#define SERVER_SYSTEM_H
#define TICK_MS 33

#define THROW_POWER_X 5000.0f
#define THROW_POWER_UP 50000.0f
#define THROW_POWER_DOWN 7000.0f
#define THROW_GRAVITY 15000.0f

#include "game.h"

extern CharaInfo *SevergCharaHead;

// �?�??????��?��????��?��???????? NPC ???????????��?��?��???????????
int InitServerChara(const char *position_data_file, CharaInfo players[], int max_players);

// �?�???��??
SDL_bool CollisionPlayer(CharaInfo *a, CharaInfo *b);
SDL_bool Collision(CharaInfo *ci, CharaInfo *cj);
int PrintError(const char *msg);
void UpdateScaleServer(CharaInfo *ch);
long long now_ms();
void Attack(CharaInfo *ch); //??��???????????
void UpdateAttackRects(CharaInfo *ch);
void TrapInTrain(CharaInfo *ch);
extern int traindoor;
extern int InTheTrain;
extern int TrapHumanSpeed;

void ThrowObject(CharaInfo *ch);
SDL_bool FlyCollison(CharaInfo *a, CharaInfo *b);
void UpdateATM(CharaInfo *atm);
void UpdateKnockdown(CharaInfo *ch);
void ReleaseHold(CharaInfo *holder, CharaInfo *obj);
void UpdateVendor(CharaInfo *ch);
#endif
