// UI.c
#include "game.h"
#include <SDL2/SDL_image.h>
#include <stdlib.h>
#include <stdio.h>

SDL_Texture *startBackTex = NULL;
SDL_Texture *titleTex     = NULL;
SDL_Texture *startTex     = NULL;
SDL_Texture *quitTex      = NULL;

void LoadStartTextures(GameInfo *gGame)
{
    startBackTex = IMG_LoadTexture(gGame->render, "img/startback.png");
    titleTex     = IMG_LoadTexture(gGame->render, "img/TITLE.png");
    startTex     = IMG_LoadTexture(gGame->render, "img/start.png");
    quitTex      = IMG_LoadTexture(gGame->render, "img/quit.png");

    if(!startBackTex || !titleTex || !startTex || !quitTex) {
        printf("Failed to load textures: %s\n", IMG_GetError());
        exit(1);
    }
}

void FreeStartTextures()
{
    if(startBackTex) SDL_DestroyTexture(startBackTex);
    if(titleTex)     SDL_DestroyTexture(titleTex);
    if(startTex)     SDL_DestroyTexture(startTex);
    if(quitTex)      SDL_DestroyTexture(quitTex);
}

// タイトルとホタン登場
int IntroAnimation(GameInfo *gGame, int come)
{
    SDL_RenderClear(gGame->render);
    SDL_RenderCopy(gGame->render, startBackTex, NULL, NULL);

    SDL_Rect titleSrc = {0,0,990,240};
    SDL_Rect startSrc = {0,0,400,176};
    SDL_Rect quitSrc  = {0,0,400,176};

    // 移動計算
    SDL_Rect title    = { -1500 + come, 100, 990, 240 };
    SDL_Rect startBtn = { 2400 - come, 400, 400, 176 };
    SDL_Rect quitBtn  = { 2400 - come, 550, 400, 176 };


    // 停止位置指定
    if (title.x >= 300) title.x = 300;
    if (startBtn.x <= 400) startBtn.x = 400;
    if (quitBtn.x <= 400) quitBtn.x = 400;


    SDL_RenderCopy(gGame->render, titleTex, &titleSrc, &title);
    SDL_RenderCopy(gGame->render, startTex, &startSrc, &startBtn);
    SDL_RenderCopy(gGame->render, quitTex , &quitSrc , &quitBtn);

    SDL_RenderPresent(gGame->render);

    // 到着判定
    int title_arrived = (title.x == 300);
    int start_arrived = (startBtn.x == 400);
    int quit_arrived  = (quitBtn.x == 400);

    // すべて届くまでアニメ
    if (!title_arrived || !start_arrived || !quit_arrived)
        return 1;

    // 全て到着後→アニメ終了（0返却）
    return 0;
}






void DrawButtonAni(GameInfo *gGame, int state)
{
    static int aniX[2] = {0, 0};  // ボタンごとのアニメーション
    static int prevState = 0;

    const int step = 400;
    const int maxX = 2000;

    // 選択が変わったら
    if(prevState != state) {
        prevState = state;
    }

    SDL_RenderClear(gGame->render);
    SDL_RenderCopy(gGame->render, startBackTex, NULL, NULL);//背景

    SDL_Rect title = { 300, 100, 990, 240 };
    SDL_RenderCopy(gGame->render, titleTex, NULL, &title);//タイトル描画

    SDL_Rect startBtn = { 300, 400, 400, 176 };
    SDL_Rect quitBtn  = { 300, 550, 400, 176 };

    // 各ボタンアニメーションの状態に応じてsrc設定
    SDL_Rect srcStart = { aniX[0], 0, 400, 176 };
    SDL_Rect srcQuit  = { aniX[1], 0, 400, 176 };

    SDL_RenderCopy(gGame->render, startTex, &srcStart, &startBtn);
    SDL_RenderCopy(gGame->render, quitTex , &srcQuit , &quitBtn);

    SDL_RenderPresent(gGame->render);

    // =====================
    // アニメーションアップデート
    // =====================

    // 選択されたボタン → 前へ（大きくなる）
    if(aniX[state] < maxX)
        aniX[state] += step;
    else
        aniX[state] = maxX;

    // 選択されていないボタン → 後ろ(小さくなる)
    for(int i=0; i<2; i++){
        if(i == state) continue;

        if(aniX[i] > 0)
            aniX[i] -= step;
        else
            aniX[i] = 0;
    }
}






void StartMenu(GameInfo *gGame)
{
    LoadStartTextures(gGame);

    int come = 0;
    

    // 登場アニメ
    while (IntroAnimation(gGame, come)) {
        come += 80; // 速度
        SDL_Delay(16);
    }

    
    SDL_Event e;
    // 登場後の入力処理
    int state = 0; // 0: START, 1: QUIT
    while(1)
    {
        while(SDL_PollEvent(&e))
        {
            if(e.type == SDL_KEYDOWN)
            {
                switch(e.key.keysym.sym)
                {
                    case SDLK_w: state = 0; 
                        break;
                    case SDLK_s: state = 1; 
                        break;
                    case SDLK_SPACE:
                        FreeStartTextures();
                        if(state == 0) 
                            return; // ゲームスタート
                        else 
                            exit(0);          // ゲーム終了
                }
            }
        }

        DrawButtonAni(gGame, state);//ボタンアニメーション
        SDL_Delay(8);
    }
}
