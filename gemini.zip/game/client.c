// =============================================================
// improved_client.c (뚝뚝 끊김 완화 버전)
// =============================================================

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <math.h>
#include "game.h"

#define PORT 5000
#define MAX_CLIENT 4
#define CLIENT_TICK_MS 8 
#define SERVER_TICK_MS 7 // 서버의 틱 시간을 명시

// **[수정]** 서버에서 수신하는 전체 패킷 구조체
typedef struct { 
    float x, y; 
} NetPos;

typedef struct {
    NetPos positions[MAX_CLIENT];
    long long server_time_ms; 
} NetPacket;

// **[수정]** 각 플레이어의 보간을 위한 위치 정보를 담을 구조체
typedef struct { 
    float x, y;               // 목표 위치 (서버가 보낸 위치)
    float interp_x, interp_y; // 보간 시작 위치 (이전 목표 위치)
    Uint32 last_update_time;  // 마지막 서버 패킷 수신 시간 (ms)
} NetPosInterpolated;

int my_id, sock;
NetPosInterpolated latest[MAX_CLIENT]; 
pthread_mutex_t pm = PTHREAD_MUTEX_INITIALIZER;

Uint32 last_send_time = 0;
SDL_bool pending_correction = SDL_FALSE; 

extern CharaInfo *gCharaHead;

// 안전 read/write (기존과 동일)
ssize_t readn(int fd, void *buf, size_t n) {
    size_t left=n; char*p=buf;
    while(left>0){ 
        ssize_t r=read(fd,p,left);
        if(r<=0) return (r==0?n-left:-1);
        left-=r;
        p+=r;
    } 
    return n;
}
ssize_t writen(int fd,const void*buf,size_t n){
    size_t l=n;
    const char*p=buf;
    while(l>0){
        ssize_t w=write(fd,p,l);
        if(w<=0)return-1;
        l-=w;
        p+=w;
    }
    return n;
}

// 클라이언트 측 이동 처리 함수 (기존과 동일)
void MoveClient(CharaInfo *ch) {
    if (!ch || ch->stts == CS_Disable) return;

    float vx = 0, vy = 0;
    if (ch->input.right) vx += MOVE_SPEED;
    if (ch->input.left)  vx -= MOVE_SPEED;
    if (ch->input.down)  vy += MOVE_SPEED;
    if (ch->input.up)    vy -= MOVE_SPEED;

    if (vx && vy) { vx /= sqrtf(2); vy /= sqrtf(2); }

    ch->point.x += vx * (CLIENT_TICK_MS / 1000.0f); 
    ch->point.y += vy * (CLIENT_TICK_MS / 1000.0f);

    // 경계 처리
    if (ch->point.x < 0) ch->point.x = 0;
    if (ch->point.y < 0) ch->point.y = 0;
    if (ch->point.x + ch->rect.w > MAP_Width)
        ch->point.x = MAP_Width - ch->rect.w;
    if (ch->point.y + ch->rect.h > MAP_Height)
        ch->point.y = MAP_Height - ch->rect.h;

    ch->rect.x = (int)ch->point.x;
    ch->rect.y = (int)ch->point.y;
}

// 서버 수신 스레드 (수정: NetPacket 수신 및 보간 정보 업데이트)
void *RecvLoop(void *a){
    int flag=1;
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));

    int fl = fcntl(sock, F_GETFL, 0);
    fcntl(sock, F_SETFL, fl | O_NONBLOCK);

    NetPacket packet_buf;

    while(1){
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(sock, &rfds);
        struct timeval tv = {0, 1000}; 

        int ret = select(sock+1, &rfds, NULL, NULL, &tv);
        if(ret>0 && FD_ISSET(sock, &rfds)){
            ssize_t r = read(sock, &packet_buf, sizeof(packet_buf));
            Uint32 recv_time = SDL_GetTicks();
            if(r <= 0){
                printf("[RecvLoop] read error r=%zd\n", r);
                return NULL;
            }

            pthread_mutex_lock(&pm);
            for (int i = 0; i < MAX_CLIENT; i++) {
                // 이전 목표 위치를 보간 시작점으로 저장
                latest[i].interp_x = latest[i].x; 
                latest[i].interp_y = latest[i].y;
                
                // 새 수신 위치를 목표로 설정
                latest[i].x = packet_buf.positions[i].x; 
                latest[i].y = packet_buf.positions[i].y;
                
                // 수신 시간 기록
                latest[i].last_update_time = recv_time; 
            }
            pending_correction = SDL_TRUE; // 자신의 캐릭터 보정 필요 플래그
            pthread_mutex_unlock(&pm);

            // printf("[Client] Received packet size=%zd (Server Time: %lld) at %u ms\n", r, packet_buf.server_time_ms, recv_time);
        }

        SDL_Delay(1);
    }
}


void SendInput(Keystts *input)
{
    ssize_t w = writen(sock, input, sizeof(Keystts));
    last_send_time = SDL_GetTicks(); 

    if (w != sizeof(Keystts))
        printf("write failed: %zd\n", w);
}

// 애니메이션 타이머 (기존과 동일)
Uint32 AnimCB(Uint32 i, void *p){ UpdateAnimation((GameInfo*)p, i/1000.0f); return i; }

int main(int argc,char*argv[]){
    if(argc<3){ printf("usage: <id> <server-ip>\n"); return 0; }
    my_id=atoi(argv[1]);

    InitSystem("chara.data","position.data",my_id);
    InitWindow(&gGames[my_id], "Test", "bg.png", 1280,720);

    // 초기 위치 설정 시 interp_x/y에도 현재 위치 설정
    for(CharaInfo*ch=gCharaHead;ch;ch=ch->next)
        if (ch->type>=CT_PLAYER0 && ch->type<CT_PLAYER0+MAX_CLIENT) {
            int i=ch->type-CT_PLAYER0;
            latest[i].x=ch->point.x;
            latest[i].y=ch->point.y;
            latest[i].interp_x = ch->point.x; 
            latest[i].interp_y = ch->point.y; 
            latest[i].last_update_time = SDL_GetTicks(); 
        }

    sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in sv={0};
    sv.sin_family=AF_INET;
    sv.sin_port=htons(PORT);
    inet_pton(AF_INET, argv[2], &sv.sin_addr);

    if (connect(sock,(struct sockaddr*)&sv,sizeof(sv)) < 0) {
        perror("connect failed"); return 1;
    }

    pthread_t th;
    pthread_create(&th,NULL,RecvLoop,NULL);

    SDL_AddTimer(16,AnimCB,&gGames[my_id]);

    Uint32 last_tick = SDL_GetTicks(); 
    SDL_bool run=SDL_TRUE;
    while(run){
        Uint32 now=SDL_GetTicks();
        gGames[my_id].timeDelta=(now-last_tick)/1000.0f;
        
        run = InputEvent(&gGames[my_id]);

        // 입력 송신 주기 제한
        if (now - last_send_time >= CLIENT_TICK_MS) {
            SendInput(&gGames[my_id].input);
        }
        
        // 클라이언트 측 예측 이동 및 서버 보정 (자신)
        if (now - last_tick >= CLIENT_TICK_MS) {
            
            // 1. 자신의 캐릭터는 클라이언트 측에서 즉시 이동 (예측)
            CharaInfo *my_chara = gCharaHead;
            for(int i=0;i<my_id;i++) my_chara=my_chara->next; 
            MoveClient(my_chara);

            // 2. 서버 보정 (Correction) 적용
            pthread_mutex_lock(&pm);
            if (pending_correction) {
                float dx = latest[my_id].x - my_chara->point.x;
                float dy = latest[my_id].y - my_chara->point.y;
                float dist = sqrtf(dx*dx + dy*dy);
                
                if(dist > 5.0f){ 
                    printf("[CORRECTION] Player %d: dist=%.2f -> Correcting to (%.1f, %.1f)\n",
                        my_id, dist, latest[my_id].x, latest[my_id].y);
                    
                    // 자신의 캐릭터 위치를 서버 위치로 **즉시 조정**
                    my_chara->point.x = latest[my_id].x;
                    my_chara->point.y = latest[my_id].y;
                    my_chara->rect.x = (int)my_chara->point.x;
                    my_chara->rect.y = (int)my_chara->point.y;
                }
                pending_correction = SDL_FALSE; 
            }
            pthread_mutex_unlock(&pm);
            last_tick = now;
        }

        // 시간 기반 보간 적용 (다른 플레이어)
        pthread_mutex_lock(&pm);
        CharaInfo *ch=gCharaHead;
        for(int i=0;i<MAX_CLIENT && ch;i++,ch=ch->next){
            if (i == my_id) {
                // 클라이언트 예측 위치를 보간 시작점으로 복사 (다른 플레이어가 튀는 걸 막기 위함)
                latest[i].interp_x = ch->point.x;
                latest[i].interp_y = ch->point.y;
                continue; 
            }

            Uint32 elapsed = now - latest[i].last_update_time;
            
            // 보간 목표 시간은 서버 틱 주기 (7ms)를 사용
            float target_duration = (float)SERVER_TICK_MS; 

            // 보간 계수 t: 0.0 (시작 위치) ~ 1.0 (목표 위치)
            float t = (float)elapsed / target_duration;
            if (t > 1.0f) t = 1.0f; // 1.0을 초과하면 목표 위치에 고정

            // 시간 기반 선형 보간 (Lerp) 적용
            ch->point.x = latest[i].interp_x + (latest[i].x - latest[i].interp_x) * t;
            ch->point.y = latest[i].interp_y + (latest[i].y - latest[i].interp_y) * t;
            
            ch->rect.x=(int)ch->point.x;
            ch->rect.y=(int)ch->point.y;

            // **[선택적 경고]** 보간이 목표 시간을 크게 초과하면 네트워크 지연이 심하다는 의미
            if (elapsed > 30) {
                 // printf("[WARN] Excessive Interp Delay for player %d: %u ms\n", i, elapsed);
            }
        }
        pthread_mutex_unlock(&pm);

        DrawGame(&gGames[my_id]);
        SDL_Delay(8); // 메인 루프 주기 유지
    }

    CloseWindow(&gGames[my_id]);
    DestroySystem();
    close(sock);
    return 0;
}