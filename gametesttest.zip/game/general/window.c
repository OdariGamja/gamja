// general/window.c
#include "game.h"
#include <SDL2/SDL_image.h>
#include <stdlib.h>
#include "../network/constants.h"


extern CharaInfo* gCharaHead;


//========================
// ウインドウ初期化
//========================
int InitWindow(GameInfo* gGame, const char *title, const char *bg_file, int width, int height)
{
    if ((IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG) != IMG_INIT_PNG)
        return PrintError("failed to initialize SDL_image");

    gGame->window = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                     width, height, SDL_WINDOW_FULLSCREEN );//SDL_WINDOW_FULLSCREEN 
    if (!gGame->window) return PrintError(SDL_GetError());

    gGame->render = SDL_CreateRenderer(gGame->window, -1, SDL_RENDERER_ACCELERATED);
    if (!gGame->render) return PrintError(SDL_GetError());

    // 배경 로드
    SDL_Surface* surf = IMG_Load(bg_file);
    if (!surf) return PrintError("failed to load background image");

    gGame->bg = SDL_CreateTextureFromSurface(gGame->render, surf);
    SDL_FreeSurface(surf);
    if (!gGame->bg) return PrintError(SDL_GetError());

    // 캐릭터 텍스처 로드
    for (int i = 0; i < CHARATYPE_NUM; i++) {
    SDL_Surface* s = IMG_Load(gCharaType[i].path);
    if (!s) return PrintError("failed to load character image");

    gCharaType[i].img = SDL_CreateTextureFromSurface(gGame->render, s);
    SDL_FreeSurface(s);
    if (!gCharaType[i].img) return PrintError(SDL_GetError());

    // <<< 여기에 애니메이션 프레임 초기화
    if (gCharaType[i].aninum.x <= 0) gCharaType[i].aninum.x = 1;
    if (gCharaType[i].aninum.y <= 0) gCharaType[i].aninum.y = 1;

    gCharaType[i].w = s->w / gCharaType[i].aninum.x;  // 한 프레임 너비
    gCharaType[i].h = s->h / gCharaType[i].aninum.y;  // 한 프레임 높이
}

    gGame->dp.x = 0;
    gGame->dp.y = 0;

    return 0;
}


//========================
// ゲーム描画
//========================
void DrawGame(GameInfo* gGame)
{
    if (!gGame || !gGame->render) return;

    // 화면 초기화
    SDL_RenderClear(gGame->render);

    // 배경 그리기
    SDL_RenderCopy(gGame->render, gGame->bg, NULL, NULL);

    // 캐릭터들 렌더링
    CharaInfo* ch = gCharaHead;
    while (ch) {
        SDL_Rect dst = {
            (int)ch->point.x,
            (int)ch->point.y,
            ch->entity->w,
            ch->entity->h
        };
        SDL_RenderCopy(gGame->render, ch->entity->img, &ch->imgsrc, &dst);

        // <<< 디버그용 printf
        printf("[DEBUG Draw] type=%d dst=(%d,%d)\n",
            ch->type, dst.x, dst.y);


        ch = ch->next;
    }

    // 최종 렌더링 결과 표시
    SDL_RenderPresent(gGame->render);
}

//========================
// アニメーション更新
//========================
void UpdateAnimation(GameInfo* gGame, float deltaTime)
{
    if (!gGame) return;

    for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
        // deltaTime에 따라 프레임 증가 (int 단위)
        int frameStep = (int)(deltaTime * 10.0f); // deltaTime 비율대로 증가
        if (frameStep < 1) frameStep = 1;        // 최소 1 프레임 증가

        int maxFramesX = ch->entity->aninum.x;
        if (maxFramesX <= 0) maxFramesX = 1; // 안전 장치

        ch->ani.x += frameStep;
        if (ch->ani.x >= maxFramesX)
            ch->ani.x = 0;

        ch->imgsrc.x = ch->ani.x * ch->entity->w;

        // <<< 디버그용 printf
        printf("[DEBUG Animation] type=%d pos=(%.2f,%.2f) ani=(%d,%d)\n",
               ch->type, ch->point.x, ch->point.y, ch->ani.x, ch->ani.y);
    }
}

//========================
// ウインドウ終了処理
//========================
void CloseWindow(GameInfo* gGame)
{
    if (!gGame) return;

    if (gGame->bg) SDL_DestroyTexture(gGame->bg);

    for (int i = 0; i < CHARATYPE_NUM; i++) {
        if (gCharaType[i].img)
            SDL_DestroyTexture(gCharaType[i].img);
    }

    if (gGame->render) SDL_DestroyRenderer(gGame->render);
    if (gGame->window) SDL_DestroyWindow(gGame->window);

    IMG_Quit();
}
