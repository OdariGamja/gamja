// general/system.c

#include "game.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../network/constants.h"

#define MAX_LINEBUF 256

GameInfo gGames[CHARATYPE_NUM]; 

CharaInfo* gCharaHead = NULL;               // キャラクターリストヘッド
CharaTypeInfo gCharaType[CHARATYPE_NUM];   // キャラクタータイプ別情報
char gImgFilePath[CHARATYPE_NUM][MAX_PATH]; // 画像ファイルパス保存用


// 補正の方向   
typedef enum {
    AD_LR,  // 左右 
    AD_UD,  // 上下
    AD_NONE // 補正してないlast_dir
} AdjustDir;


int PrintError(const char* msg) {
    fprintf(stderr, "Error: %s\n", msg);
    return -1;
}


//システム初期化
int InitSystem(const char* chara_data_file, const char* position_data_file, int my_id)
{
    int ret = 0;

    // キャラクタタイプ別情報読み込む
    FILE* fp = fopen(chara_data_file, "r");
    if (!fp) return PrintError("failed to open chara data file.");

    int typeno = 0;
    char linebuf[MAX_LINEBUF];
    while (fgets(linebuf, MAX_LINEBUF, fp)) {
        if (linebuf[0] == '#') continue;
        if (typeno < CHARATYPE_NUM) {
            if (3 != sscanf(linebuf, "%d%d%s",
                            &(gCharaType[typeno].w),
                            &(gCharaType[typeno].h),
                            gImgFilePath[typeno])) {
                ret = PrintError("failed to read the chara image data.");
                goto CLOSEFILE_CHARA;
            }
            gCharaType[typeno].path = gImgFilePath[typeno];
            printf("Loaded chara type %d: w=%d, h=%d, path=%s\n",
                   typeno,
                   gCharaType[typeno].w,
                   gCharaType[typeno].h,
                   gCharaType[typeno].path);
            typeno++;
        }
    }
CLOSEFILE_CHARA:
    fclose(fp);
    if (ret < 0) return ret;

    // キャラクタ位置及び情報読み込み
    fp = fopen(position_data_file, "r");
    if (!fp) return PrintError("failed to open position data file.");

    gCharaHead = NULL;
    for (int i = 0; i < CHARATYPE_NUM; i++) {
        gGames[i].player = NULL;
        memset(&gGames[i].input, 0, sizeof(gGames[i].input));
    }

    while (fgets(linebuf, MAX_LINEBUF, fp)) {
        if (linebuf[0] == '#') continue;

        CharaInfo* ch = (CharaInfo*)malloc(sizeof(CharaInfo));
        if (!ch) { ret = PrintError("failed to allocate the chara data."); goto CLOSEFILE_POSITION; }

        ch->next = gCharaHead;
        gCharaHead = ch;

        if (7 != sscanf(linebuf, "%u%f%f%d%d%d%d",
                        (unsigned int*)&(ch->type),
                        &(ch->point.x),
                        &(ch->point.y),
                        &(ch->rect.x),
                        &(ch->rect.y),
                        &(ch->rect.w),
                        &(ch->rect.h))) {
            ret = PrintError("failed to load position data.");
            goto CLOSEFILE_POSITION;
        }

        if (ch->type >= CHARATYPE_NUM) {
            PrintError("Invalid character type.");
            free(ch);
            continue;
        }

        ch->entity = &gCharaType[ch->type];
        InitCharaInfo(ch);

        printf("Loaded character: type=%d, x=%.1f, y=%.1f, entity path=%s\n",
               ch->type, ch->point.x, ch->point.y, ch->entity->path);
    }

    // gGame와 player 설정 (루프 밖에서 한 번만)
    gGame = &gGames[my_id];
    gGame->player = NULL;
    for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
        if (ch->type == CT_PLAYER0 + my_id) {
            gGame->player = ch;
            break;
        }
    }

    if (!gGame->player) {
        PrintError("Player 初期化失敗 (gGame.player == NULL)");
        for (CharaInfo* iter = gCharaHead; iter; iter = iter->next) {
            printf("Chara in list: type=%d\n", iter->type);
        }
        ret = -1;
    }

CLOSEFILE_POSITION:
    fclose(fp);
    return ret;
}

//キャラクタ情報初期化
// 캐릭터 정보 초기화
void InitCharaInfo(CharaInfo* ch)
{
    if (!ch) {
        printf("InitCharaInfo: ch is NULL\n");
        return;
    }

    if (ch->type >= CHARATYPE_NUM) {
        printf("InitCharaInfo: invalid type %d\n", ch->type);   
        ch->entity = NULL;
        return;
    }

    ch->entity = &gCharaType[ch->type];
    if (!ch->entity) {
        printf("InitCharaInfo: ch->entity is NULL\n");
        return;
    }

    ch->stts = CS_Normal;
    ch->vel.x = 0;
    ch->vel.y = 0;
    ch->point.x = (int)ch->point.x;
    ch->point.y = (int)ch->point.y;
    ch->ani.x = 0;

    ch->rect.w = ch->entity->w;
    ch->rect.h = ch->entity->h;
    ch->rect.x = (int)ch->point.x;
    ch->rect.y = (int)ch->point.y;

    ch->imgsrc.x = 0;
    ch->imgsrc.y = 0;
    ch->imgsrc.w = ch->entity->w;
    ch->imgsrc.h = ch->entity->h;

    // 디버깅 출력
    printf("InitCharaInfo done: ch=%p, ch->entity=%p, path=%s\n",
           ch, ch->entity, ch->entity->path);
}



//当たり判定補正
AdjustDir AdjustPoint(CharaInfo* cadj, CharaInfo* cfix, SDL_Rect* rt)
{
    AdjustDir ret = AD_NONE;
    /* 判定が不要な組み合わせを除外 */
    if (cadj->stts == CS_Disable || cfix->stts == CS_Disable)
        return ret;

    // 補正する方向を決める
    // 側面を全て含むときはその方   
    if (rt->w == cadj->rect.w)
        ret = AD_UD;
    else if (rt->h == cadj->rect.h)
        ret = AD_LR;
    // 一部を含むときは短い方
    else if (rt->w > rt->h)
        ret = AD_UD;
    else if (rt->w < rt->h)
        ret = AD_LR;
    // 縦横同じときは速度の大きい方
    else if (fabsf(cadj->vel.x) > fabsf(cadj->vel.y))
        ret = AD_LR;
    else
        ret = AD_UD;

    /* 補正 */
    if (ret == AD_LR) { // x方向
        int dx = cadj->rect.x - (int)(cadj->point.x);
        cadj->point.x += (cadj->rect.x == rt->x) ? rt->w : -rt->w;
        cadj->rect.x = cadj->point.x + dx;

    } else { // y方向
        int dy = cadj->rect.y - (int)(cadj->point.y);
        cadj->point.y += (cadj->rect.y == rt->y) ? rt->h : -rt->h;
        cadj->rect.y = cadj->point.y + dy;
    }
    return ret;
}



//当たり判定
SDL_bool Collision(CharaInfo* ci, CharaInfo* cj)
{
    if (ci->stts == CS_Disable || cj->stts == CS_Disable)
        return SDL_FALSE;

    SDL_Rect ir;
    if (SDL_IntersectRect(&(ci->rect), &(cj->rect), &ir)){
    
    }
    return SDL_FALSE;
}

//システム破棄
void DestroySystem(void) {
    CharaInfo* ch = gCharaHead;
    while (ch) {
        CharaInfo* next = ch->next;
        free(ch);
        ch = next;
    }
    gCharaHead = NULL;
}


// 移動処理
void MoveChara(CharaInfo* ch, GameInfo* game) {
    if (!ch || ch->stts == CS_Disable || !game) return;
    if (game == NULL) {
        fprintf(stderr, "Error: gGame is NULL in MoveChara\n");
        return;  // game이 NULL이면 함수 종료
    }
    ch->vel.x = 0;
    ch->vel.y = 0;

    // 입력 처리
    if (game->input.up) {
        ch->vel.y = -MOVE_SPEED;
        ch->ani.y = ANI_RunUp;
    }
    else if (game->input.down) {
        ch->vel.y = MOVE_SPEED;
        ch->ani.y = ANI_RunDown;
    }

    if (game->input.left) {
        ch->vel.x = -MOVE_SPEED;
        ch->ani.y = ANI_RunLeft;
    }
    else if (game->input.right) {
        ch->vel.x = MOVE_SPEED;
        ch->ani.y = ANI_RunRight;
    }

    // 이동량 좌표 갱신
    ch->point.x += ch->vel.x * game->timeDelta;
    ch->point.y += ch->vel.y * game->timeDelta;

    // rect에도 반영
    ch->rect.x = (int)ch->point.x;
    ch->rect.y = (int)ch->point.y;

    // 디버그 출력
    printf("[DEBUG MoveChara] type=%d pos=(%.2f, %.2f) vel=(%.2f, %.2f) ani=%d\n",
       ch->type, ch->point.x, ch->point.y, ch->vel.x, ch->vel.y, ch->ani.y);

    // 입력 없으면 정지 상태
    if (!game->input.up && !game->input.down &&
        !game->input.left && !game->input.right) {
        ch->ani.y = ANI_Stop;
    }
}






//入力処理
// 입력 처리
SDL_bool InputEvent(GameInfo* gGame) {
    if (!gGame) return SDL_FALSE; // 안전 장치
    if (gGame == NULL) {
        fprintf(stderr, "Error: gGame is NULL in InputEvent\n");
        return SDL_FALSE;
    }

    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                return SDL_FALSE;

            case SDL_KEYDOWN:
                switch (event.key.keysym.sym) {
                    case SDLK_ESCAPE: 
                        return SDL_FALSE;
                    case SDLK_w: gGame->input.up = SDL_TRUE; break;
                    case SDLK_s: gGame->input.down = SDL_TRUE; break;
                    case SDLK_a: gGame->input.left = SDL_TRUE; break;
                    case SDLK_d: gGame->input.right = SDL_TRUE; break;
                    case SDLK_SPACE: gGame->input.space = SDL_TRUE; break;
                }
                break;

            case SDL_KEYUP:
                switch (event.key.keysym.sym) {
                    case SDLK_w: gGame->input.up = SDL_FALSE; break;
                    case SDLK_s: gGame->input.down = SDL_FALSE; break;
                    case SDLK_a: gGame->input.left = SDL_FALSE; break;
                    case SDLK_d: gGame->input.right = SDL_FALSE; break;
                    case SDLK_SPACE: gGame->input.space = SDL_FALSE; break;
                }
                break;
        }
    }
    return SDL_TRUE;
}



