//network/constant.h

#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <netinet/in.h>

/*============================
  共通定数
============================*/
#define DEF_PORT 50100
#define MAX_NUM_CLIENTS 5
#define MAX_LEN_BUFFER 256
#define MAX_LEN_ADDR 32
#define MAX_LEN_CMD 64
#define MAX_LEN_NAMES 32
#define BROADCAST -1

#define COMMAND_MOVE_UP    'W'
#define COMMAND_MOVE_LEFT  'A'
#define COMMAND_MOVE_DOWN  'S'
#define COMMAND_MOVE_RIGHT 'D'
#define COMMAND_INTERACT   'E'  

#define COMMAND_POSITION_UPDATE 'P' // 플레이어 좌표 전송 명령

/*============================
  クライアント情報構造体
============================*/
typedef struct {
    int cid;                        // 클라이언트 ID
    int sock;                       // 소켓 디스크립터
    struct sockaddr_in addr;        // 주소 정보
    char name[MAX_LEN_NAMES];       // 이름
} CLIENT; 


/*============================
  通信コンテナ
============================*/
typedef struct {
    int cid;                        // 송신자 ID
    char command;                   // 명령 (이동, 상호작용 등)
    float x, y;     // 플레이어 좌표
} CONTAINER;


/*============================
  ゲーム共有データ構造体
  (general/system.c → network/client.c で利用)
============================*/

/* 서버와 클라이언트 간에 전송될 최소한의 캐릭터 정보 */
typedef struct {
    float x;        // 좌표 X
    float y;        // 좌표 Y
    float velx;       // 속도 X
    float vely;       // 속도 Y
    int animState;  // 애니메이션 상태 (ex. ANI_RunRight 등)
    int type;       // 캐릭터 타입 (CT_Manhole 등)
    int status;     // 캐릭터 상태 (CS_Normal 등)
} PlayerState;


/* 서버로 전송되는 패킷 */
typedef struct {
    int cid;            // 클라이언트 ID
    PlayerState player; // 플레이어의 현재 상태
} Packet;

extern void setup_server(int, u_short);
extern int control_requests();
extern void terminate_server();

#endif
