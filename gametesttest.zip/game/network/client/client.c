//client/client.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <arpa/inet.h>

#include "../constants.h"
#include "../../general/game.h"

int my_id;
static int sock;  
static fd_set mask;

void setup_client(char *, u_short);
int control_requests();
void terminate_client();

static void send_data(void *, int);
static int receive_data(void *, int);
static void handle_error(char *msg);
static void handle_server_container(CONTAINER *c);
static void UpdateRemotePlayerPosition(int cid, float x, float y);

extern GameInfo gGames[CHARATYPE_NUM];
extern CharaInfo* gCharaHead;

//********** クライアント初期化**********//
void setup_client(char *server_name, u_short port) {
    struct hostent *server;
    struct sockaddr_in sv_addr;

    fprintf(stderr, "Connecting to server %s (port %d)\n", server_name, port);

    if ((server = gethostbyname(server_name)) == NULL)
        handle_error("gethostbyname()");

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0)
        handle_error("socket()");

    sv_addr.sin_family = AF_INET;
    sv_addr.sin_port = htons(port);
    sv_addr.sin_addr.s_addr = *(u_int *)server->h_addr_list[0];

    if (connect(sock, (struct sockaddr *)&sv_addr, sizeof(sv_addr)) != 0)
        handle_error("connect()");

    // 名前転送
    char user_name[MAX_LEN_NAMES];
    fprintf(stderr, "Input your name: ");
    if (fgets(user_name, sizeof(user_name), stdin) == NULL)
        handle_error("fgets()");
    user_name[strlen(user_name) - 1] = '\0';
    send_data(user_name, MAX_LEN_NAMES);

    // サーバからID受信
    receive_data(&my_id, sizeof(int));
    fprintf(stderr, "Connected. Your ID = %d\n", my_id);

    FD_ZERO(&mask);
    FD_SET(sock, &mask);
}
//********** クライアント初期化 **********//



int control_requests(void) {
    fd_set read_flag = mask;
    struct timeval timeout = {0, 10000}; // 10ms

    if (select(sock + 1, &read_flag, NULL, NULL, &timeout) == -1)
        handle_error("select()");

    if (FD_ISSET(sock, &read_flag)) {
        CONTAINER data;
        memset(&data, 0, sizeof(CONTAINER));
        int r = receive_data(&data, sizeof(data));

        if (r <= 0) {
            fprintf(stderr, "server closed or read error\n");
            return 0;
        }
        handle_server_container(&data);
    }

    // 自分のキャラクター入力処理
    GameInfo *myGame = &gGames[my_id];
    CONTAINER move_data = {0};
    move_data.cid = my_id;

    if (myGame->input.up) move_data.command = COMMAND_MOVE_UP;
    else if (myGame->input.down) move_data.command = COMMAND_MOVE_DOWN;
    else if (myGame->input.left) move_data.command = COMMAND_MOVE_LEFT;
    else if (myGame->input.right) move_data.command = COMMAND_MOVE_RIGHT;
    else move_data.command = 0;

    if (myGame->player) {
        move_data.x = myGame->player->point.x;
        move_data.y = myGame->player->point.y;
    }

    if (move_data.command != 0){
        send_data(&move_data, sizeof(CONTAINER));

        fprintf(stderr, "[DEBUG SEND] cid=%d cmd=%d pos=(%.2f,%.2f)\n",
            move_data.cid, move_data.command, move_data.x, move_data.y);
    }
        

    return 1;
}

static void handle_server_container(CONTAINER *c) {
    if (!c) return;

    // サーバーから何の命令も送っていない場合は無視
    if (c->command == 0) return;

    switch (c->command) {
        case COMMAND_MOVE_UP:
        case COMMAND_MOVE_DOWN:
        case COMMAND_MOVE_LEFT:
        case COMMAND_MOVE_RIGHT:
        case COMMAND_POSITION_UPDATE:
            UpdateRemotePlayerPosition(c->cid, c->x, c->y);

            fprintf(stderr, "[DEBUG RECV] cid=%d cmd=%d pos=(%.2f,%.2f)\n",
            c->cid, c->command, c->x, c->y);
            break;

        case COMMAND_INTERACT:
            fprintf(stderr, "Server: player %d interact\n", c->cid);
            break;

        default:
            fprintf(stderr, "handle_server_container(): unknown command %d\n", c->command);
            break;
    }   
}

static void UpdateRemotePlayerPosition(int cid, float x, float y) {
    if (cid < 0 || cid >= CHARATYPE_NUM) return;

    // まずgGames[cid].playerがあればすぐに使用
    GameInfo *g = &gGames[cid];
    CharaInfo *ch = g->player;

    // なければgCharaHeadで探す (type基準)
    if (!ch) {
        for (CharaInfo *iter = gCharaHead; iter; iter = iter->next) {
            if (iter->type == (CT_PLAYER0 + cid)) {
                ch = iter;
                // 캐시해두면 다음번에 빠름 
                g->player = ch;
                break;
            }
        }
    }

    if (ch) {
        ch->point.x = x;
        ch->point.y = y;
        ch->rect.x = (int)x;
        ch->rect.y = (int)y;


        fprintf(stderr, "[DEBUG UPDATE] cid=%d new_pos=(%.2f,%.2f)\n",
            cid, x, y);

            
    } else {
        // 디버그 로그 (선택)
        fprintf(stderr, "UpdateRemotePlayerPosition: couldn't find player cid=%d\n", cid);
    }
}


//自分のキャラクタの位置情報を送る
void send_player_position() {
    GameInfo *myGame = &gGames[my_id];
    if (!myGame->player) return;

    CONTAINER data = {0};
    data.command = COMMAND_POSITION_UPDATE;
    data.cid = my_id;
    data.x = myGame->player->point.x;
    data.y = myGame->player->point.y;

    send_data(&data, sizeof(CONTAINER));
}

static void send_data(void *data, int size) {
    if (!data || size <= 0)
        handle_error("send_data(): invalid data");
    if (write(sock, data, size) == -1)
        handle_error("write()");
}

static int receive_data(void *data, int size) {
    if (!data || size <= 0)
        handle_error("receive_data(): invalid data");
    return read(sock, data, size);
}

static void handle_error(char *msg) {
    perror(msg);
    exit(1);
}

void terminate_client() {
    fprintf(stderr, "Connection closed.\n");
    close(sock);
    exit(0);
}
