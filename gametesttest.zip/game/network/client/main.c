// client/main.c
#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include "../constants.h"
#include "../../general/game.h"

extern void setup_client(char *, u_short);
extern int control_requests(void);
extern void terminate_client(void);
extern GameInfo gGames[CHARATYPE_NUM]; 
extern int my_id;
extern CharaInfo* gCharaHead;

GameInfo *gGame = NULL;
SDL_mutex* animMutex = NULL; // 애니메이션 보호용
SDL_mutex* posMutex  = NULL; // 서버 좌표 보호용
SDL_bool gRunning = SDL_TRUE;

// 서버에서 받은 최신 좌표
typedef struct { float x, y; SDL_bool valid; } NetPos;
NetPos gServerPos[CHARATYPE_NUM];

//====================
// 좌표 보간 함수
//====================
void LerpPosition(CharaInfo* ch, float targetX, float targetY, float alpha) {
    ch->point.x += (targetX - ch->point.x) * alpha;
    ch->point.y += (targetY - ch->point.y) * alpha;
    ch->rect.x = (int)ch->point.x;
    ch->rect.y = (int)ch->point.y;
}

//====================
// 애니메이션 전용 스레드
//====================
int AnimateThread(void* data) {
    while (gRunning) {
        SDL_LockMutex(animMutex);
        for (int i = 0; i < CHARATYPE_NUM; i++)
            UpdateAnimation(&gGames[i], gGames[i].timeDelta);
        SDL_UnlockMutex(animMutex);
        SDL_Delay(16); // 60fps
    }
    return 0;
}

//====================
// 서버 좌표 수신 스레드
//====================
int NetworkThread(void* arg) {
    int sockfd = *(int*)arg;
    char buf[128];
    while (gRunning) {
        int n = recv(sockfd, buf, sizeof(buf), 0);
        if (n <= 0) break;

        int cid; float x, y;
        if (sscanf(buf, "%d %f %f", &cid, &x, &y) == 3) {
            if (cid < 0 || cid >= CHARATYPE_NUM) continue;
            SDL_LockMutex(posMutex);
            gServerPos[cid].x = x;
            gServerPos[cid].y = y;
            gServerPos[cid].valid = SDL_TRUE;
            SDL_UnlockMutex(posMutex);
        }
    }
    return 0;
}

//====================
// 메인
//====================
int main(int argc, char *argv[]) {  
    char server_name[MAX_LEN_NAMES] = "localhost";
    u_short port = DEF_PORT;

    if (argc >= 2) sprintf(server_name, "%s", argv[1]);
    if (argc >= 3) port = (u_short)atoi(argv[2]);

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) < 0) {
        fprintf(stderr, "SDL_Init Error: %s\n", SDL_GetError());
        return 1;
    }

    setup_client(server_name, port);

    if (InitSystem("../../general/chara.data", "../../general/position.data", my_id) < 0) {
        PrintError("failed to initialize System");
        EndGame();
    }

    gGame = &gGames[my_id];
    if (!gGame) { fprintf(stderr, "Error: gGame is NULL\n"); SDL_Quit(); return 1; }

    if (InitWindow(gGame, "Game Window", "../../general/img/bg.png", WD_Width, WD_Height) < 0) {
        SDL_Quit();
        return 1;
    }

    animMutex = SDL_CreateMutex();
    posMutex  = SDL_CreateMutex();

    // 서버 좌표 초기화
    for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
        int cid = ch->type;
        gServerPos[cid].x = ch->point.x;
        gServerPos[cid].y = ch->point.y;
        gServerPos[cid].valid = SDL_FALSE;
    }

    SDL_Thread* animThread = SDL_CreateThread(AnimateThread, "AnimateThread", NULL);
    // SDL_Thread* netThread = SDL_CreateThread(NetworkThread, "NetworkThread", &sockfd); // sockfd 필요

    Uint64 lastTick = SDL_GetPerformanceCounter();
    double freq = (double)SDL_GetPerformanceFrequency();

    while (gRunning) {
        Uint64 now = SDL_GetPerformanceCounter();
        float delta = (float)((now - lastTick) / freq);
        lastTick = now;

        gRunning = InputEvent(gGame);
        control_requests();
        gGame->timeDelta = delta;

        // 서버 좌표 보간
        SDL_LockMutex(posMutex);
        for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
            int cid = ch->type;
            if (gServerPos[cid].valid)
                LerpPosition(ch, gServerPos[cid].x, gServerPos[cid].y, 0.2f);
        }
        SDL_UnlockMutex(posMutex);

        // 플레이어 이동
        MoveChara(gGame->player, gGame);

        // 렌더링
        SDL_LockMutex(animMutex);
        DrawGame(gGame);
        SDL_UnlockMutex(animMutex);

        // 60fps 제한
        Uint64 frameTime = (SDL_GetPerformanceCounter() - now) * 1000.0 / freq;
        if (frameTime < 16) SDL_Delay(16 - (Uint32)frameTime);
    }

    gRunning = SDL_FALSE;
    SDL_WaitThread(animThread, NULL);
    // SDL_WaitThread(netThread, NULL);

    SDL_DestroyMutex(animMutex);
    SDL_DestroyMutex(posMutex);
    CloseWindow(gGame);
    terminate_client();
    SDL_Quit();
    return 0;
}

// 종료
void EndGame(void) {
    gRunning = SDL_FALSE;
    SDL_Quit();
    exit(0);
}
