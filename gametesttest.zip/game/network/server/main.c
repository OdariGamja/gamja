  // server/main.c
  #include <stdio.h>
  #include <stdlib.h>

  #include "../constants.h"

void setup_server(int, u_short);// サーバーを構築する関数
int control_requests();// クライアントからの要求処理関数
void terminate_server();// サーバー終了処理関数

  //*******メイン関数********//
  int main(int argc, char *argv[]) {
    int num_cl = 1;//クライアント数を格納する変数宣言
    u_short port = DEF_PORT;//ポート番号を格納する

    switch (argc) {
    case 1:
      break;
    case 2:
      num_cl = atoi(argv[1]);//第2引数はクライアント数
      break;
    case 3://第3引数はポート番号指定
      num_cl = atoi(argv[1]);
      port = atoi(argv[2]);
      break;
    default:
      fprintf(stderr, "Usage: %s [number of clients] [port number]\n", argv[0]);
      return 1;
    }

    // クライアント数の範囲チェック
    if (num_cl < 0 || num_cl > MAX_NUM_CLIENTS) {
      fprintf(stderr, "Max number of clients is %d\n", MAX_NUM_CLIENTS);
      return 1;
    }

    fprintf(stderr, "Number of clients = %d\n", num_cl);
    fprintf(stderr, "Port number = %d\n", port);

    //setup_server起動
    setup_server(num_cl, port);

    int cond = 1;
    while (cond) {
        cond = control_requests();//クライアントからの要求を処理を繰り返す
    }

    terminate_server();// サーバー終了

    return 0;
  }
