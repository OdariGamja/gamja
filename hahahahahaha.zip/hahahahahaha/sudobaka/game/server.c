// server.c
// Linux, CLOCK_MONOTONIC fixed-step server (60Hz), TCP_NODELAY, larger buffers

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <time.h>
#include <math.h>
#include "game.h"

#define PORT 5001
#define MAX_CLIENT 4
#define TICK_MS 16  // 60Hz

typedef struct { float x, y; } NetPos;

static int csock[MAX_CLIENT];
static int alive[MAX_CLIENT];
static pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
static CharaInfo players[MAX_CLIENT];

static inline long long now_ms_monotonic(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

/* reliable write helper */
ssize_t writen(int fd, const void *buf, size_t n) {
    size_t left = n;
    const char *p = buf;
    while (left > 0) {
        ssize_t w = send(fd, p, left, 0);
        if (w <= 0) return -1;
        left -= w; p += w;
    }
    return n;
}

/* move logic (server authoritative) */
void MoveServer(CharaInfo *ch) {
    if (!ch || ch->stts == CS_Disable) return;

    float vx = 0, vy = 0;
    if (ch->input.right) vx += MOVE_SPEED;
    if (ch->input.left)  vx -= MOVE_SPEED;
    if (ch->input.down)  vy += MOVE_SPEED;
    if (ch->input.up)    vy -= MOVE_SPEED;

    if (vx != 0.0f && vy != 0.0f) {
        vx /= sqrtf(2.0f);
        vy /= sqrtf(2.0f);
    }

    ch->point.x += vx;
    ch->point.y += vy;

    if (ch->point.x < 0) ch->point.x = 0;
    if (ch->point.y < 0) ch->point.y = 0;
    if (ch->point.x + ch->rect.w > MAP_Width) ch->point.x = MAP_Width - ch->rect.w;
    if (ch->point.y + ch->rect.h > MAP_Height) ch->point.y = MAP_Height - ch->rect.h;

    ch->rect.x = (int)ch->point.x;
    ch->rect.y = (int)ch->point.y;
}

/* per-client recv thread: blocking read of Keystts (safe; does not block main loop) */
ssize_t readn_block(int fd, void *buf, size_t n) {
    size_t left = n; char *p = buf;
    while (left > 0) {
        ssize_t r = recv(fd, p, left, 0);
        if (r <= 0) return (r == 0 ? n - left : -1);
        left -= r; p += r;
    }
    return n;
}

void *RecvThread(void *arg) {
    int id = *(int*)arg; free(arg);
    int s = csock[id];

    while (1) {
        Keystts in;
        if (readn_block(s, &in, sizeof(in)) != sizeof(in)) break;
        /* copy input (no heavy locking; main loop reads but it's ok) */
        players[id].input = in;
    }

    pthread_mutex_lock(&mtx);
    close(csock[id]);
    csock[id] = -1;
    alive[id] = 0;
    pthread_mutex_unlock(&mtx);
    printf("Client %d disconnected\n", id);
    return NULL;
}

/* fixed-step game loop using monotonic clock and next_tick to avoid drift */
void *GameLoop(void *arg) {
    (void)arg;
    long long next_tick = now_ms_monotonic() + TICK_MS;

    while (1) {
        long long now = now_ms_monotonic();
        long long wait = next_tick - now;
        if (wait > 1) {
            /* sleep coarsely; we use 1ms resolution to avoid busyspin */
            struct timespec ts;
            ts.tv_sec = 0;
            ts.tv_nsec = (wait - 1) * 1000000; // leave ~1ms to busy loop
            nanosleep(&ts, NULL);
            continue;
        }

        /* do updates for this tick */
        for (int i = 0; i < MAX_CLIENT; ++i) {
            if (alive[i]) MoveServer(&players[i]);
        }

        /* broadcast positions */
        NetPos pack[MAX_CLIENT];
        for (int i = 0; i < MAX_CLIENT; ++i) {
            pack[i].x = players[i].point.x;
            pack[i].y = players[i].point.y;
        }

        pthread_mutex_lock(&mtx);
        for (int i = 0; i < MAX_CLIENT; ++i) {
            if (alive[i] && csock[i] != -1) {
                if (writen(csock[i], pack, sizeof(pack)) != sizeof(pack)) {
                    close(csock[i]);
                    csock[i] = -1;
                    alive[i] = 0;
                }
            }
        }
        pthread_mutex_unlock(&mtx);

        next_tick += TICK_MS;

        /* if very late, resync to now + TICK_MS */
        long long now2 = now_ms_monotonic();
        if (now2 > next_tick + TICK_MS) next_tick = now2 + TICK_MS;
    }
    return NULL;
}

int main(void) {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) { perror("socket"); return 1; }

    int opt = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(s, (struct sockaddr*)&addr, sizeof(addr)) < 0) { perror("bind"); close(s); return 1; }
    if (listen(s, MAX_CLIENT) < 0) { perror("listen"); close(s); return 1; }
    printf("Server ready (port %d)\n", PORT);

    /* init players */
    for (int i = 0; i < MAX_CLIENT; ++i) {
        csock[i] = -1;
        alive[i] = 0;
        players[i].point.x = 100 + i * 50;
        players[i].point.y = 200;
        players[i].rect.w = 32;
        players[i].rect.h = 48;
        players[i].stts = CS_Normal;
        memset(&players[i].input, 0, sizeof(players[i].input));
    }

    /* start game loop thread */
    pthread_t gl;
    pthread_create(&gl, NULL, GameLoop, NULL);
    pthread_detach(gl);

    /* accept loop */
    while (1) {
        int cs = accept(s, NULL, NULL);
        if (cs < 0) { perror("accept"); continue; }

        pthread_mutex_lock(&mtx);
        int id = -1;
        for (int i = 0; i < MAX_CLIENT; ++i) if (!alive[i]) { id = i; break; }
        if (id < 0) { close(cs); pthread_mutex_unlock(&mtx); continue; }
        csock[id] = cs;
        alive[id] = 1;
        pthread_mutex_unlock(&mtx);

        /* disable Nagle + enlarge buffers */
        int flag = 1;
        setsockopt(csock[id], IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));
        int bufsize = 256 * 1024;
        setsockopt(csock[id], SOL_SOCKET, SO_RCVBUF, &bufsize, sizeof(bufsize));
        setsockopt(csock[id], SOL_SOCKET, SO_SNDBUF, &bufsize, sizeof(bufsize));

        printf("Client %d connected (fd=%d)\n", id, csock[id]);

        int *pid = malloc(sizeof(int));
        *pid = id;
        pthread_t th;
        pthread_create(&th, NULL, RecvThread, pid);
        pthread_detach(th);
    }

    close(s);
    return 0;
}
