// client.c
// Linux client (60FPS) with non-blocking recv thread, damped interpolation

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <netinet/tcp.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "game.h"

#define PORT 5001
#define MAX_CLIENT 4

typedef struct { float x,y; } NetPos;

extern CharaInfo *gCharaHead;
int my_id = 0;
int sockfd = -1;
NetPos latest[MAX_CLIENT];
pthread_mutex_t pm = PTHREAD_MUTEX_INITIALIZER;

/* safe writen */
ssize_t writen(int fd, const void *buf, size_t n) {
    size_t left = n; const char *p = buf;
    while (left > 0) {
        ssize_t w = send(fd, p, left, 0);
        if (w <= 0) return -1;
        left -= w; p += w;
    }
    return n;
}

/* damp alpha helper */
static inline float damp_alpha(float responsiveness, float dt) {
    return 1.0f - expf(-responsiveness * dt);
}

/* recv thread: non-blocking recv; we only keep latest snapshot */
void *RecvLoop(void *arg) {
    (void)arg;
    while (1) {
        NetPos buf[MAX_CLIENT];
        ssize_t r = recv(sockfd, buf, sizeof(buf), MSG_DONTWAIT);
        if (r == (ssize_t)sizeof(buf)) {
            pthread_mutex_lock(&pm);
            memcpy(latest, buf, sizeof(buf));
            pthread_mutex_unlock(&pm);
            continue;
        } else if (r == 0) {
            // server closed
            break;
        } else if (r < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                // no data - short sleep
                usleep(1000);
                continue;
            } else {
                perror("recv");
                break;
            }
        } else {
            // partial read - drop (server sends fixed-size snapshots)
            usleep(1000);
            continue;
        }
    }
    return NULL;
}

void SendInput(Keystts *input) {
    if (!input) return;
    if (writen(sockfd, input, sizeof(Keystts)) != sizeof(Keystts)) {
        // print once
        static int warned = 0;
        if (!warned) { perror("SendInput failed"); warned = 1; }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("usage: %s <id> <server-ip>\n", argv[0]);
        return 1;
    }
    my_id = atoi(argv[1]);

    /* init system/window (your existing code) */
    if (InitSystem("chara.data", "position.data", my_id) < 0) return 1;
    if (InitWindow(&gGames[my_id], "Test", "bg.png", 1280, 720) < 0) return 1;

    /* initial latest from file positions */
    for (CharaInfo *ch = gCharaHead; ch; ch = ch->next) {
        if (ch->type >= CT_PLAYER0 && ch->type < CT_PLAYER0 + MAX_CLIENT) {
            int i = ch->type - CT_PLAYER0;
            latest[i].x = ch->point.x;
            latest[i].y = ch->point.y;
        }
    }

    /* connect */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) { perror("socket"); return 1; }

    struct sockaddr_in sv = {0};
    sv.sin_family = AF_INET;
    sv.sin_port = htons(PORT);
    inet_pton(AF_INET, argv[2], &sv.sin_addr);

    if (connect(sockfd, (struct sockaddr*)&sv, sizeof(sv)) < 0) {
        perror("connect");
        close(sockfd);
        return 1;
    }

    /* disable Nagle + enlarge buffers */
    int flag = 1;
    setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));
    int buf = 256 * 1024;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, &buf, sizeof(buf));
    setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, &buf, sizeof(buf));

    /* make non-blocking (recv thread uses MSG_DONTWAIT but keep nonblocking anyway) */
    int fl = fcntl(sockfd, F_GETFL, 0);
    fcntl(sockfd, F_SETFL, fl | O_NONBLOCK);

    /* start recv thread */
    pthread_t rth;
    pthread_create(&rth, NULL, RecvLoop, NULL);
    pthread_detach(rth);

    /* high-precision 60FPS loop using SDL performance counter */
    const double FPS = 60.0;
    const double frameTime = 1.0 / FPS;
    const Uint64 perfFreq = SDL_GetPerformanceFrequency();
    Uint64 lastCounter = SDL_GetPerformanceCounter();

    /* input send rate limit (30Hz) */
    Uint32 lastSend = 0;
    const Uint32 SEND_INTERVAL_MS = 33;

    SDL_bool running = SDL_TRUE;
    while (running) {
        Uint64 nowCounter = SDL_GetPerformanceCounter();
        double dt = (double)(nowCounter - lastCounter) / (double)perfFreq;
        lastCounter = nowCounter;

        /* process events and input (updates gGames[my_id].input) */
        running = InputEvent(&gGames[my_id]);
        if (!running) break;

        /* send input rate-limited */
        Uint32 nowMs = SDL_GetTicks();
        if (nowMs - lastSend >= SEND_INTERVAL_MS) {
            SendInput(&gGames[my_id].input);
            lastSend = nowMs;
        }

        /* apply interpolation (short mutex) */
        float responsiveness = 12.0f; /* tuneable */
        float a = damp_alpha(responsiveness, (float)dt);

        pthread_mutex_lock(&pm);
        CharaInfo *ch = gCharaHead;
        int i = 0;
        for (i = 0; i < MAX_CLIENT && ch; i++, ch = ch->next) {
            ch->point.x += (latest[i].x - ch->point.x) * a;
            ch->point.y += (latest[i].y - ch->point.y) * a;
            ch->rect.x = (int)ch->point.x;
            ch->rect.y = (int)ch->point.y;
        }
        pthread_mutex_unlock(&pm);

        /* animation & draw */
        UpdateAnimation(&gGames[my_id], (float)dt);
        DrawGame(&gGames[my_id]);

        /* sleep to avoid busyspin while keeping low jitter
           we compute actual loop time and sleep the remainder if >1ms */
        Uint64 after = SDL_GetPerformanceCounter();
        double loopSec = (double)(after - nowCounter) / (double)perfFreq;
        double sleepSec = frameTime - loopSec;
        if (sleepSec > 0.001) {
            SDL_Delay((Uint32)(sleepSec * 1000.0));
        }
    }

    /* cleanup */
    CloseWindow(&gGames[my_id]);
    DestroySystem();
    close(sockfd);
    return 0;
}
