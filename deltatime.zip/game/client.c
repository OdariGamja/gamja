#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <SDL2/SDL.h>
#include <math.h>
#include "game.h"

#define PORT 5000
#define MAX_CLIENT 4

typedef struct { float x,y; } NetPos;

int my_id;
int sock;
struct sockaddr_in server_addr;
NetPos latest[MAX_CLIENT];
pthread_mutex_t pm = PTHREAD_MUTEX_INITIALIZER;

extern CharaInfo *gCharaHead;

ssize_t writen_udp(int fd, void *buf, size_t n, struct sockaddr_in *addr){
    return sendto(fd, buf, n, 0, (struct sockaddr*)addr, sizeof(*addr));
}

// 수신 스레드
void* RecvLoop(void* a){
    NetPos buf[MAX_CLIENT];
    while(1){
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(sock, &rfds);
        struct timeval tv = {0, 1000}; // 1ms

        int ret = select(sock+1, &rfds, NULL, NULL, &tv);
        if(ret>0 && FD_ISSET(sock, &rfds)){
            ssize_t r = recvfrom(sock, buf, sizeof(buf), 0, NULL, NULL);
            if(r <= 0) continue;

            pthread_mutex_lock(&pm);
            memcpy(latest, buf, sizeof(buf));
            pthread_mutex_unlock(&pm);
        }
        SDL_Delay(1);
    }
    return NULL;
}

void SendInput(Keystts *input){
    writen_udp(sock, input, sizeof(Keystts), &server_addr);
}

Uint32 AnimCB(Uint32 i, void *p){ UpdateAnimation((GameInfo*)p, i/1000.0f); return i; }

int main(int argc,char*argv[]){
    if(argc<3){ printf("usage: <id> <server-ip>\n"); return 0; }
    my_id=atoi(argv[1]);

    InitSystem("chara.data","position.data",my_id);
    InitWindow(&gGames[my_id], "Test", "bg.png", 1280,720);

    sock = socket(AF_INET, SOCK_DGRAM, 0);
    memset(&server_addr,0,sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, argv[2], &server_addr.sin_addr);

    pthread_t th;
    pthread_create(&th,NULL,RecvLoop,NULL);

    SDL_AddTimer(16,AnimCB,&gGames[my_id]);

    Uint32 last = SDL_GetTicks();
    SDL_bool run=SDL_TRUE;
    while(run){
        Uint32 now=SDL_GetTicks();
        gGames[my_id].timeDelta=(now-last)/1000.0f;
        last=now;

        run = InputEvent(&gGames[my_id]);
        SendInput(&gGames[my_id].input);

        pthread_mutex_lock(&pm);
        CharaInfo *ch=gCharaHead;
        for(int i = 0; i < MAX_CLIENT && ch; i++, ch = ch->next){
            float dx = latest[i].x - ch->point.x;
            float dy = latest[i].y - ch->point.y;
            float dist = sqrtf(dx*dx + dy*dy);
            if(dist > 50.0f){
                printf("[WARN] teleport-like jump for player %d: dist = %.2f (latest=%.1f,%.1f cur=%.1f,%.1f)\n",
                    i, dist, latest[i].x, latest[i].y, ch->point.x, ch->point.y);
            }

            // =========================
            // 기존: float t = 0.3f;
            float t = gGames[my_id].timeDelta / 0.033f; // 서버 tick 기준 보간
            if (t > 1.0f) t = 1.0f;

            ch->point.x += dx * t;
            ch->point.y += dy * t;
            ch->rect.x = (int)ch->point.x;
            ch->rect.y = (int)ch->point.y;
            // =========================
        }
        pthread_mutex_unlock(&pm);

        DrawGame(&gGames[my_id]);
        SDL_Delay(8);
    }

    CloseWindow(&gGames[my_id]);
    DestroySystem();
    close(sock);
    return 0;
}
