// simplified_server_debug.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/time.h>
#include <math.h>
#include <netinet/tcp.h>
#include <stdint.h>
#include <errno.h>
#include "game.h"

#define PORT 5000
#define MAX_CLIENT 4
#define TICK_MS 33

// 네트워크용 최소 데이터 (시퀀스 포함)
typedef struct { uint32_t seq; float x, y; Keystts lastInput; } NetPos;

// 클라이언트 소켓 & 연결 여부
int csock[MAX_CLIENT];
int alive[MAX_CLIENT];
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;

// 서버 내부 플레이어
CharaInfo players[MAX_CLIENT];

// 안전 read/write
ssize_t readn(int fd, void *buf, size_t n) {
    size_t left = n; char *p = buf;
    while (left > 0) {
        ssize_t r = read(fd, p, left);
        if (r < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (r == 0) return (n - left); // EOF
        left -= r; p += r;
    }
    return n;
}
ssize_t writen(int fd, const void *buf, size_t n) {
    size_t left = n; const char *p = buf;
    while (left > 0) {
        ssize_t w = write(fd, p, left);
        if (w <= 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        left -= w; p += w;
    }
    return n;
}

// now_ms 유틸
long long now_ms() {
    struct timeval tv; gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000 + tv.tv_usec/1000;
}

// 이동 처리 (단순화)
void MoveServer(CharaInfo *ch) {
    if (!ch || ch->stts == CS_Disable) return;

    float vx = 0, vy = 0;
    if (ch->input.right) vx += MOVE_SPEED;
    if (ch->input.left)  vx -= MOVE_SPEED;
    if (ch->input.down)  vy += MOVE_SPEED;
    if (ch->input.up)    vy -= MOVE_SPEED;

    if (vx && vy) { vx /= sqrtf(2); vy /= sqrtf(2); }

    ch->point.x += vx;
    ch->point.y += vy;

    // 경계 처리
    if (ch->point.x < 0) ch->point.x = 0;
    if (ch->point.y < 0) ch->point.y = 0;
    if (ch->point.x + ch->rect.w > MAP_Width)
        ch->point.x = MAP_Width - ch->rect.w;
    if (ch->point.y + ch->rect.h > MAP_Height)
        ch->point.y = MAP_Height - ch->rect.h;

    ch->rect.x = (int)ch->point.x;
    ch->rect.y = (int)ch->point.y;
}

// 클라이언트 입력 받는 스레드 (디버그: read 지연 측정)
void *RecvThread(void *arg) {
    int id = *(int*)arg; free(arg);
    int s = csock[id];

    while (1) {
        Keystts inp;
        long long t0 = now_ms();
        ssize_t r = readn(s, &inp, sizeof(inp));
        long long t1 = now_ms();

        if (r != sizeof(inp)) {
            if (r < 0) {
                fprintf(stderr, "[RECV THREAD] id=%d readn error r=%zd errno=%d\n", id, r, errno);
            }
            break;
        }

        // read 지연 체크 (임계값: 30ms)
        if (t1 - t0 > 30) {
            printf("[RECV SLOW] id=%d read took %lld ms\n", id, t1 - t0);
        }

        // 입력 반영
        players[id].input = inp;
    }

    pthread_mutex_lock(&mtx);
    if (csock[id] != -1) close(csock[id]);
    csock[id] = -1;
    alive[id] = 0;
    pthread_mutex_unlock(&mtx);

    printf("Client %d disconnected\n", id);
    return NULL;
}

// 서버 게임루프 스레드 (디버그: tick 지연, writen 지연, 주기적 로드 리포트)
void *GameLoop(void *arg) {
    long long last = now_ms();
    uint32_t seq = 1;
    long long last_debug_report = last;

    while (1) {
        long long cur = now_ms();
        long long dt = cur - last;
        if (dt < TICK_MS) {
            usleep((TICK_MS - dt) * 1000);
            continue;
        }
        if (dt > 200) {
            printf("[WARN] Server tick delay = %lld ms\n", dt);
        } else if (dt > 50) {
            // 좀 덜 심한 지터도 표기
            printf("[TICK JITTER] dt = %lld ms\n", dt);
        }
        last = cur;

        // 1) 서버 이동
        for (int i = 0; i < MAX_CLIENT; i++)
            if (alive[i]) MoveServer(&players[i]);

        // 2) 위치 브로드캐스트 (seq 포함)
        NetPos pack[MAX_CLIENT];
        for (int i = 0; i < MAX_CLIENT; i++) {
            pack[i].seq = seq;
            pack[i].x = players[i].point.x;
            pack[i].y = players[i].point.y;
        }
        seq++; if (seq == 0) seq = 1; // seq 0 예약

        pthread_mutex_lock(&mtx);
        for (int i = 0; i < MAX_CLIENT; i++) {
            if (alive[i] && csock[i] != -1) {
                long long w0 = now_ms();
                ssize_t wr = writen(csock[i], pack, sizeof(pack));
                long long w1 = now_ms();

                if (wr < 0) {
                    fprintf(stderr, "[SEND ERROR] id=%d writen failed wr=%zd errno=%d\n", i, wr, errno);
                    close(csock[i]); csock[i] = -1; alive[i] = 0;
                    continue;
                }

                // 쓰기 지연 체크 (임계값: 20ms)
                if (w1 - w0 > 20) {
                    printf("[SEND SLOW] id=%d write delay=%lld ms\n", i, w1 - w0);
                }
            }
        }
        pthread_mutex_unlock(&mtx);

        // 주기적 서버 상태 리포트 (1초 단위)
        if (cur - last_debug_report >= 1000) {
            int connected = 0;
            pthread_mutex_lock(&mtx);
            for (int i = 0; i < MAX_CLIENT; ++i) if (alive[i]) connected++;
            pthread_mutex_unlock(&mtx);
            printf("[SERVER STATUS] time=%lld ms connected=%d seq=%u\n", cur, connected, seq);
            last_debug_report = cur;
        }
    }
    return NULL;
}

int main() {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    int opt = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    if (bind(s, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind");
        return 1;
    }
    if (listen(s, MAX_CLIENT) < 0) {
        perror("listen");
        return 1;
    }
    printf("Server ready.\n");

    // 기본 플레이어 초기화
    for (int i=0;i<MAX_CLIENT;i++){
        csock[i] = -1; alive[i]=0;
        players[i].point.x = 100 + i*50;
        players[i].point.y = 200;
        players[i].rect.w = 32;
        players[i].rect.h = 48;
        players[i].stts = CS_Normal;
        memset(&players[i].input,0,sizeof(players[i].input));
    }

    // 게임루프 스레드 시작
    pthread_t gl;
    if (pthread_create(&gl, NULL, GameLoop, NULL) != 0) {
        perror("pthread_create game loop");
        return 1;
    }
    pthread_detach(gl);

    // 클라이언트 accept
    while (1) {
        int cs = accept(s, NULL, NULL);
        if (cs < 0) { perror("accept"); continue; }

        pthread_mutex_lock(&mtx);
        int id=-1;
        for (int i=0;i<MAX_CLIENT;i++) if (!alive[i]) { id=i; break; }
        if (id<0) { close(cs); pthread_mutex_unlock(&mtx); continue; }
        csock[id]=cs;
        alive[id]=1;
        pthread_mutex_unlock(&mtx);

        int flag = 1;
        setsockopt(csock[id], IPPROTO_TCP, TCP_NODELAY, &flag , sizeof(flag));

        printf("Client %d connected (fd=%d)\n", id, csock[id]);

        int *pid = malloc(sizeof(int)); *pid=id;
        pthread_t th;
        if (pthread_create(&th,NULL,RecvThread,pid) != 0) {
            perror("pthread_create recv");
            close(cs);
            pthread_mutex_lock(&mtx);
            csock[id] = -1; alive[id] = 0;
            pthread_mutex_unlock(&mtx);
            free(pid);
            continue;
        }
        pthread_detach(th);
    }
    return 0;
}
