// UI.c
#include "game.h"
#include <SDL2/SDL_image.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <math.h>   
#define TICK_MS 33

SDL_Texture *startBackTex = NULL;
SDL_Texture *titleTex     = NULL;
SDL_Texture *startTex     = NULL;
SDL_Texture *quitTex      = NULL;
SDL_Texture *spinpenTex      = NULL;
SDL_Texture *traineffectTex      = NULL;
SDL_Texture *playerwait1      = NULL;
SDL_Texture *playerwait2      = NULL;
SDL_Texture *playerwait3      = NULL;
SDL_Texture *playerwait4      = NULL;
SDL_Texture *networkstatusTex      = NULL;
SDL_Texture *youtex      = NULL;
SDL_Texture *startTexttex      = NULL;



extern CharaInfo *gCharaHead; 
SDL_Texture* getPlayerWaitTexture(int playerID)
{
    switch(playerID)
    {
        case 0: return playerwait1;
        case 1: return playerwait2;
        case 2: return playerwait3;
        case 3: return playerwait4;
        default: return playerwait1; // 혹시 4명 초과
    }
}
#define SCREEN_W 1980
#define SCREEN_H 1080
#define READY_W 300     // 애니메이션 한 프레임 가로 크기
#define READY_H 300     // 애니메이션 한 프레임 세로 크기
#define READY_FRAME 8   // 한 행당 프레임 수

static float readyY[MAX_CLIENT] = { -400, -400, -400, -400 };
static int readyFrame[MAX_CLIENT] = {0,0,0,0};
static int readyDir[MAX_CLIENT] = {1,1,1,1}; // 1: 오른쪽, -1: 왼쪽



static float spinOffsetX = 0.0f;
static float spinOffsetY = 0.0f;
extern NetPack latest[MAX_CLIENT];
extern pthread_mutex_t pm;

typedef enum {
    UI_INTRO,
    UI_MENU,
    UI_WAITING,
    UI_TRANSITION
} UIPhase;
static Uint32 lastNormal[MAX_CLIENT];   // 1행 타이머
static Uint32 lastActive[MAX_CLIENT];   // 2행 타이머


typedef struct {
    float x, y;
    float vy;
    float life;   // ms
} Steam;
#define MAX_STEAM 48
Steam steam[MAX_STEAM];


static Uint32 transStartTime = 0;
static float  transAlpha = 0.0f;
static int    transStarted = 0;
void ResetUITransition(void)
{
    transStarted = 0;
    transAlpha = 0.0f;
}
// YOU 텍스트 페이드용
float youAlpha = 0.0f;


int UI_Transition(SDL_Renderer* r, int fade)
// fade =  1 : fade in
// fade = -1 : fade out
{
    if(!transStarted)
    {
        transStartTime = SDL_GetTicks();
        transStarted = 1;

        if(fade > 0)
            transAlpha = 0.0f;
        else
            transAlpha = 1.0f;
    }

    Uint32 now = SDL_GetTicks();

    // fade in일 때만 3초 대기
    if(fade > 0 && now - transStartTime < 3000)
        return 0;

    transAlpha += 0.025f * fade;

    if(transAlpha < 0.0f) transAlpha = 0.0f;
    if(transAlpha > 1.0f) transAlpha = 1.0f;

    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(
        r,
        0, 0, 0,
        (Uint8)(255 * transAlpha)
    );

    SDL_Rect full = { 0, 0, SCREEN_W, SCREEN_H };
    SDL_RenderFillRect(r, &full);

    // 종료 조건
    if((fade > 0 && transAlpha >= 1.0f) ||
       (fade < 0 && transAlpha <= 0.0f))
    {
        transStarted = 0; // 다음에 또 쓸 수 있게
        return 1;
    }

    return 0;
}






void LoadStartTextures(GameInfo *gGame)
{
    startBackTex = IMG_LoadTexture(gGame->render, "img/startback.png");
    titleTex     = IMG_LoadTexture(gGame->render, "img/TITLE.png");
    startTex     = IMG_LoadTexture(gGame->render, "img/start.png");
    quitTex      = IMG_LoadTexture(gGame->render, "img/quit.png");
    spinpenTex   = IMG_LoadTexture(gGame->render, "img/spin.png");
    traineffectTex     = IMG_LoadTexture(gGame->render, "img/traineffect.png");
    playerwait1   = IMG_LoadTexture(gGame->render, "img/ready1.png");
    playerwait2   = IMG_LoadTexture(gGame->render, "img/ready2.png");
    playerwait3   = IMG_LoadTexture(gGame->render, "img/ready3.png");
    playerwait4   = IMG_LoadTexture(gGame->render, "img/ready4.png");
    networkstatusTex   = IMG_LoadTexture(gGame->render, "img/waiting.png");
    youtex   = IMG_LoadTexture(gGame->render, "img/you.png");
    startTexttex   = IMG_LoadTexture(gGame->render, "img/starttext.png");

    if(!startBackTex || !titleTex || !startTex || !quitTex || !spinpenTex || !spinpenTex
    || !playerwait1 || !playerwait2|| !playerwait3|| !playerwait4 || !networkstatusTex
    || !youtex || !startTexttex ) {
        printf("Failed to load textures: %s\n", IMG_GetError());
        exit(1);
    }
}

void FreeStartTextures()
{
    if(startBackTex) SDL_DestroyTexture(startBackTex);
    if(titleTex)     SDL_DestroyTexture(titleTex);
    if(startTex)     SDL_DestroyTexture(startTex);
    if(quitTex)      SDL_DestroyTexture(quitTex);
    if(spinpenTex)      SDL_DestroyTexture(spinpenTex);
    if(playerwait1)      SDL_DestroyTexture(playerwait1);
    if(playerwait2)      SDL_DestroyTexture(playerwait2);
    if(playerwait3)      SDL_DestroyTexture(playerwait3);
    if(playerwait4)      SDL_DestroyTexture(playerwait4);
    if(networkstatusTex)      SDL_DestroyTexture(networkstatusTex);
    if(youtex)      SDL_DestroyTexture(youtex);
    if(startTexttex)      SDL_DestroyTexture(startTexttex);
}

void TrainEffect(GameInfo *gGame)
{
    SDL_Rect src = {0, 0, 13730, 504};
    SDL_Rect dst;

    static float trainX = 0.0f;

    const float speed = 8.0f;
    const int resetPoint = 6865;

    const float scale = 0.35f;   // ⭐ 여기서 크기 조절

    // 이동 (왼쪽)
    trainX -= speed;

    // 절반 지나면 리셋
    if(trainX <= -resetPoint * scale) {
        trainX = 0.0f;
    }

    dst.w = (int)(13730 * scale);
    dst.h = (int)(504 * scale);

    dst.x = (int)trainX;
    dst.y = 950;

    SDL_RenderCopy(
        gGame->render,
        traineffectTex,
        &src,
        &dst
    );
    
}


void DrawSpinPens(GameInfo *gGame)
{
    SDL_Rect src = {0, 0, 204, 204};
    SDL_Rect dst;

    const int spacing = 200;
    const float moveSpeed = 0.6f;
    const float rotSpeed  = 0.8f;

    const float minScale = 0.4f;
    const float maxScale = 0.6f;

    static float angle = 0.0f;

    // 스크롤
    spinOffsetX -= moveSpeed;
    spinOffsetY -= moveSpeed;

    if(spinOffsetX <= -spacing) spinOffsetX += spacing;
    if(spinOffsetY <= -spacing) spinOffsetY += spacing;

    angle += rotSpeed;
    if(angle >= 360) angle -= 360;

    for(int y = -spacing; y < SCREEN_H + spacing; y += spacing)
    {
        for(int x = -spacing; x < SCREEN_W + spacing; x += spacing)
        {
            // ==========================
            // 체커보드 패턴 (핵심)
            // ==========================
            int ix = x / spacing;
            int iy = y / spacing;

            if ( (ix + iy) & 1 )
                continue;

            float t = (float)(y + spinOffsetY) / SCREEN_H;
            if(t < 0.0f) t = 0.0f;
            if(t > 1.0f) t = 1.0f;

            float scale = minScale + t * (maxScale - minScale);

            dst.w = (int)(204 * scale);
            dst.h = (int)(204 * scale);

            dst.x = (int)(x + spinOffsetX + (204 - dst.w) * 0.5f);
            dst.y = (int)(y + spinOffsetY + (204 - dst.h) * 0.5f);

            SDL_RenderCopyEx(
                gGame->render,
                spinpenTex,
                &src,
                &dst,
                angle,
                NULL,
                SDL_FLIP_NONE
            );
        }
    }
}

void DrawBg(GameInfo *gGame){
    SDL_RenderClear(gGame->render);
    SDL_RenderCopy(gGame->render, startBackTex, NULL, NULL);
    DrawSpinPens(gGame);
    TrainEffect(gGame); 
}


int IntroAnimation(GameInfo *gGame, int come)
{
    SDL_Rect titleSrc = {0,0,850,170};
    SDL_Rect startSrc = {0,0,250,100};
    SDL_Rect quitSrc  = {0,0,250,100};

    SDL_Rect title    = { -1500 + come, 100, 850, 170 };
    SDL_Rect startBtn = { 2400 - come, 400, 250, 100 };
    SDL_Rect quitBtn  = { 2400 - come, 550, 250, 100 };

    if (title.x >= 150) title.x = 150;
    if (startBtn.x <= 150) startBtn.x = 150;
    if (quitBtn.x <= 150) quitBtn.x = 150;

    SDL_RenderCopy(gGame->render, titleTex, &titleSrc, &title);
    SDL_RenderCopy(gGame->render, startTex, &startSrc, &startBtn);
    SDL_RenderCopy(gGame->render, quitTex , &quitSrc , &quitBtn);

    if (title.x != 150 || startBtn.x != 150 || quitBtn.x != 150)
        return 1;

    return 0;
}





void DrawButtonAni(GameInfo *gGame, int state)
{
    static float scale[2] = {1.0f, 1.0f};
    static float angle[2] = {0.0f, 0.0f};
    static float hue = 0.0f;  // 색 변화 타이머

    const float SCALE_STEP = 0.05f;
    const float MAX_SCALE  = 1.5f;
    const float MIN_SCALE  = 1.0f;

    const float ANGLE_STEP = 1.9f;
    const float MAX_ANGLE  = 8.0f;

    // 색 변화 속도
    const float COLOR_SPEED = 1.0f;

    SDL_Rect title = { 150, 100, 850, 170 };
    SDL_RenderCopy(gGame->render, titleTex, NULL, &title);

    SDL_Rect startBtn = { 150, 400, 250, 100 };
    SDL_Rect quitBtn  = { 150, 550, 250, 100 };

    // 색 변화 타이머 증가
    hue += COLOR_SPEED * (TICK_MS / 1000.0f);

    // state에 따라 scale & angle 변화
    for(int i=0; i<2; i++){
        if(i == state){
            scale[i] += SCALE_STEP;
            if(scale[i] > MAX_SCALE) scale[i] = MAX_SCALE;

            angle[i] += ANGLE_STEP;
            if(angle[i] > MAX_ANGLE) angle[i] = MAX_ANGLE;
        }
        else{
            scale[i] -= SCALE_STEP;
            if(scale[i] < MIN_SCALE) scale[i] = MIN_SCALE;

            angle[i] -= ANGLE_STEP;
            if(angle[i] < 0) angle[i] = 0;
        }
    }

    // 확대 적용된 dst 계산
    SDL_Rect startDst = {
        startBtn.x - (int)((scale[0] - 1.0f) * startBtn.w / 2),
        startBtn.y - (int)((scale[0] - 1.0f) * startBtn.h / 2),
        (int)(startBtn.w * scale[0]),
        (int)(startBtn.h * scale[0])
    };

    SDL_Rect quitDst = {
        quitBtn.x - (int)((scale[1] - 1.0f) * quitBtn.w / 2),
        quitBtn.y - (int)((scale[1] - 1.0f) * quitBtn.h / 2),
        (int)(quitBtn.w * scale[1]),
        (int)(quitBtn.h * scale[1])
    };

    SDL_Rect src = { 0, 0, 400, 176 };

    // -----------------------------
    // 색 변화 계산 (sin으로 자연스럽게)
    // -----------------------------
    Uint8 r = 255, g = 255, b = 255;

    // 선택된 버튼만 색 변화
    if(state == 0){
        float t = (sinf(hue) + 1.0f) / 2.0f; // 0~1
        r = 255;
        g = (Uint8)(120 + 135 * t); // 200~255
        b = (Uint8)(120 + 135 * t);
    }
    else if(state == 1){
        float t = (sinf(hue + 1.57f) + 1.0f) / 2.0f; // 0~1
        r = (Uint8)(120 + 135 * t);
        g = (Uint8)(120 + 135 * t);
        b = 255;
    }

    // 선택된 버튼만 컬러 모드 적용
    SDL_SetTextureColorMod(startTex, (state == 0) ? r : 255, (state == 0) ? g : 255, (state == 0) ? b : 255);
    SDL_SetTextureColorMod(quitTex,  (state == 1) ? r : 255, (state == 1) ? g : 255, (state == 1) ? b : 255);

    // 회전 렌더링
    SDL_RenderCopyEx(gGame->render, startTex, &src, &startDst, angle[0], NULL, SDL_FLIP_NONE);
    SDL_RenderCopyEx(gGame->render, quitTex , &src, &quitDst , angle[1], NULL, SDL_FLIP_NONE);

    // 색 변조는 렌더링 끝난 후 원상복구
    SDL_SetTextureColorMod(startTex, 255, 255, 255);
    SDL_SetTextureColorMod(quitTex, 255, 255, 255);
}



// ================================
// Ready Lobby 관련
// ================================

// yPos / frame은 전역(static)으로 유지해야 함
static float readyY[MAX_CLIENT];
static int   readyFrame[MAX_CLIENT];

// 초기화
void InitReadySlots(void)
{
    for(int i=0;i<MAX_CLIENT;i++){
        readyY[i] = -400;
        readyFrame[i] = 0;
        readyDir[i] = 1;
        lastNormal[i] = 0;
        lastActive[i] = 0;
    }
}





// waiting UI 상태
static float waitAlpha  = 0.0f;   // 페이드인 (0~1)
static float waitSrcY  = 0.0f; 
static int   waitPhase  = 0;
/*
0 = 대기    
1 = 페이드인 (50px)
2 = 표시 유지
3 = 확장 (50 → 150)
4 = 완료
*/
void UpdateWaitingUIState(void)
{
    // 1. 캐릭터 전부 내려왔는지
    int allDown = 1;
    for(int i = 0; i < 4; i++)
    {
        if(fabsf(readyY[i] - 500.0f) > 1.0f)
            allDown = 0;
    }

    //4人でプレイとき ↓をコメントから出す。　 complie するとき、エラが出るけど、無視して。
    if(allDown && waitPhase == 0)  //debug  
        waitPhase = 1;  //これはさわるな

    // 2. 페이드인
    if(waitPhase == 1)
    {
        youAlpha += 0.03f;
        if(youAlpha > 1.0f){
            youAlpha = 1.0f;
        }
            
        waitAlpha += 0.03f;
        if(waitAlpha >= 1.0f)
        {
            waitAlpha = 1.0f;
            waitPhase = 2;
        }
    }

    // 3. 전원 READY 확인
    int allReady = 1;
    CharaInfo* ch = gCharaHead;
    while(ch)
    {
        if(ch->type >= CT_PLAYER0 && ch->type <= CT_PLAYER3)//debug  ひとり CT_PLAYER0  ->  4人　CT_PLAYER3
        {
            if(ch->input.nowstts != NOW_START)
            {
                allReady = 0;
                break;
            }
        }
        ch = ch->next;
    }

    if(allReady && waitPhase == 2)
        waitPhase = 3;

    // 4. src.y 이동 (0 → 100)
    if(waitPhase == 3)
    {
        waitSrcY += (100.0f - waitSrcY) * 0.12f;

        if(fabsf(waitSrcY - 100.0f) < 1.0f)
        {
            waitSrcY = 100.0f;
            waitPhase = 4;
        }
    }
}

void RenderWaitingUI(SDL_Renderer* render)
{
    if(waitPhase < 1)
        return;

    SDL_SetTextureBlendMode(networkstatusTex, SDL_BLENDMODE_BLEND);
    SDL_SetTextureAlphaMod(
        networkstatusTex,
        (Uint8)(255 * waitAlpha)
    );

    // ★ 50px 고정, y만 이동
    SDL_Rect src = {
        0,
        (int)waitSrcY,   // ★ 여기!
        782,
        50
    };

    SDL_Rect dst = {
        (SCREEN_W - 782) / 2,
        200,
        782,
        50
    };

    SDL_RenderCopy(render, networkstatusTex, &src, &dst);
}





// Ready Lobby 업데이트 + 렌더링
void UpdateReadyLobby(GameInfo *gGame)
{
    static Uint32 last = 0;
    Uint32 now = SDL_GetTicks();

    pthread_mutex_lock(&pm);

    UpdateWaitingUIState();

    CharaInfo* ch = gCharaHead;

    // ===== 시네마틱 레터박스 (READY 내려오는 동안) =====
    {
        float startY = -300.0f;
        float targetY = 500.0f;

        // 대표로 내 캐릭터 기준 (my_id)
        float t = (readyY[my_id] - startY) / (targetY - startY);
        if (t < 0.0f) t = 0.0f;
        if (t > 1.0f) t = 1.0f;

        // easing (슥~)
        t = t * t;

        int barMaxH = 180;
        int barH = (int)(barMaxH * t);

        SDL_SetRenderDrawBlendMode(gGame->render, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(gGame->render, 0, 0, 0, 180);

        SDL_Rect topBar = {
            0, 0,
            SCREEN_W, barH
        };

        SDL_Rect bottomBar = {
            0, SCREEN_H - barH,
            SCREEN_W, barH
        };

        SDL_RenderFillRect(gGame->render, &topBar);
        SDL_RenderFillRect(gGame->render, &bottomBar);
    }
    
            

    while(ch)
    {
        if(ch->type >= CT_PLAYER0 && ch->type <= CT_PLAYER3)//debug　ひとり CT_PLAYER0  ->  4人　CT_PLAYER3
        {
            int playerID = ch->type - CT_PLAYER0;   // ★ 실제 플레이어 ID (0~3)
            int active = (ch->input.nowstts == NOW_START);

            float targetY = 500.0f;
            float speed = 0.085f;   // 0.1~0.2 사이 추천
            readyY[playerID] += (targetY - readyY[playerID]) * speed;


            // 프레임 속도: 80ms로 더 빠르게
            if(active)
            {
                
                // 2행 느리게 (예: 150ms)
                if(now - lastActive[playerID] > 150)
                {
                    if(readyFrame[playerID] < READY_FRAME - 1)
                        readyFrame[playerID]++;

                    lastActive[playerID] = now;
                }
            }
            else
            {
                // 1행 빠르게 (예: 80ms)
                if(now - lastNormal[playerID] > 80)
                {
                    if(readyDir[playerID] == 1) {
                        readyFrame[playerID]++;
                        if(readyFrame[playerID] >= READY_FRAME - 1)
                            readyDir[playerID] = -1;
                    }
                    else {
                        readyFrame[playerID]--;
                        if(readyFrame[playerID] <= 0)
                            readyDir[playerID] = 1;
                    }

                    lastNormal[playerID] = now;
                }
            }


            // 렌더링
            SDL_Rect src, dst;
            SDL_Texture* tex = getPlayerWaitTexture(playerID);

            src.x = readyFrame[playerID] * READY_W;
            src.y = active ? READY_H : 0;
            src.w = READY_W;
            src.h = READY_H;

            // 내 캐릭터면 확대
            float scale = (playerID == my_id) ? 1.5f : 1.0f;

            dst.w = (int)(READY_W * scale);
            dst.h = (int)(READY_H * scale);
            dst.x = (int)(300 + playerID * 350 - (dst.w - READY_W) / 2);
            dst.y = (int)(readyY[playerID] - (dst.h - READY_H) / 2);

            /* =========================
            READY 상태(2행) 기운 효과 (뒤)
            ========================= */
            if(active && readyFrame[playerID] >= READY_FRAME - 1)
            {
                SDL_SetRenderDrawBlendMode(gGame->render, SDL_BLENDMODE_ADD);

                for(int i = 0; i < 70; i++)
                {
                    // 위로 갈수록 퍼짐
                    int spread = 150 + i * 2;
                    int rx = (rand() % (spread * 2)) - spread;
                    int ry = rand() % 15;

                    int x = dst.x + dst.w / 2 + rx;
                    int y = dst.y + dst.h * 0.80f - i * 7 - ry;

                    int alpha = 140 - i * 2;
                    if(alpha < 20) alpha = 20;

                    int w = 14 - i / 6;
                    if(w < 2) w = 2;

                    SDL_SetRenderDrawColor(
                        gGame->render,
                        255, 230, 80,
                        alpha
                    );

                    SDL_Rect r = { x, y, w, 8 };
                    SDL_RenderFillRect(gGame->render, &r);
                }
            }


            /* 캐릭터 */
            SDL_RenderCopy(gGame->render, tex, &src, &dst);

            // =========================
            // YOU 텍스트 (내 캐릭터 위)
            // =========================
            if(playerID == my_id && youAlpha > 0.0f)
            {
                SDL_SetTextureBlendMode(youtex, SDL_BLENDMODE_BLEND);
                SDL_SetTextureAlphaMod(youtex, (Uint8)(youAlpha * 255));

                SDL_Rect youDst;
                youDst.w = 75;
                youDst.h = 35;
                youDst.x = dst.x + dst.w / 2 - youDst.w / 2;
                youDst.y = dst.y - youDst.h - 10; // 머리 위 살짝

                SDL_RenderCopy(gGame->render, youtex, NULL, &youDst);
            }

        }

        ch = ch->next;
    }
    RenderWaitingUI(gGame->render);

    pthread_mutex_unlock(&pm);

    if(now - last > 80) last = now;
}




// WaitingRoom은 이제 UpdateReadyLobby를 호출만 한다
void WaitingRoom(GameInfo *gGame)
{
    DrawBg(gGame);
    UpdateReadyLobby(gGame);
    
}


void StartMenu(GameInfo *gGame)
{
    LoadStartTextures(gGame);
    InitReadySlots();

    UIPhase phase = UI_INTRO;
    int come = 0;
    int state = 0;
    int introDone = 0;


    SDL_Event e;

    while(1)
    {
        SDL_RenderClear(gGame->render);
        DrawBg(gGame);

        // =========================
        // PHASE 처리
        // =========================
        switch(phase)
        {
        case UI_INTRO:
            if(!IntroAnimation(gGame, come))
            {
                phase = UI_MENU;
                introDone = 1;
            }
            else
            {
                come += 80;
            }
            break;

        case UI_MENU:
            DrawButtonAni(gGame, state);
            break;

        case UI_WAITING:
            if(come > 0)
            {
                IntroAnimation(gGame, come);
                come -= 80;
            }
            else
            {
                WaitingRoom(gGame);

                // allReady 체크
                int allReady = 1;
                for(int i = 0; i < MAX_CLIENT; i++)//debug 4人でプレイするとき　MAX_CLIENT - 3 => MAX_CLIENT 
                {
                    if(latest[i].nowstts != NOW_START)
                    {
                        allReady = 0;
                        break;
                    }
                }

                if(allReady)
                {
                    phase = UI_TRANSITION;
                    ResetUITransition(); 
                }
            }
            break;

        case UI_TRANSITION:
            // 기존 화면 유지
            WaitingRoom(gGame);

            
            if(UI_Transition(gGame->render , 1))  // ← 여기서 내부적으로 3초 체크
            {
                return;
            }
            break;
        }

        // =========================
        // 입력 처리
        // =========================
        while(SDL_PollEvent(&e))
        {
            if(e.type != SDL_KEYDOWN) continue;

            if(phase == UI_MENU && introDone)
            {
                if(e.key.keysym.sym == SDLK_w) state = 0;
                if(e.key.keysym.sym == SDLK_s) state = 1;

                if(e.key.keysym.sym == SDLK_SPACE)
                {
                    if(state == 0)
                    {
                        gGames[my_id].input.nowstts = NOW_START;
                        SendInput(&gGames[my_id].input);
                        phase = UI_WAITING;
                    }
                    else
                    {
                        exit(0);
                    }
                }
            }
        }

        SDL_RenderPresent(gGame->render);
        SDL_Delay(16);
    }
}




void DrawStartTEXTUI(GameInfo* g)
{
    SDL_Texture* tex = startTexttex;
    if (!tex) return;

    static float y;
    static int   phase = 0;
    static Uint32 tick = 0;

    Uint32 now = SDL_GetTicks();

    const int texW = 440;
    const int texH = 120;

    const float startY  = SCREEN_H + texH;
    const float targetY = 400.0f;
    const float endY    = -texH;

    if (phase == 0)
    {
        y = startY;
        phase = 1;
    }

    if (phase == 1)
    {
        y += (targetY - y) * 0.12f;
        if (fabsf(y - targetY) < 1.0f)
        {
            y = targetY;
            phase = 2;
            tick = now;
        }
    }
    else if (phase == 2)
    {
        if (now - tick >= 1000)
            phase = 3;
    }
    else if (phase == 3)
    {
        y += (endY - y) * 0.12f;
        if (y < endY + 1.0f)
            phase = 4;
    }

    if (phase >= 4)
        return;

    SDL_Rect src = { 0, 0, texW, texH };
    SDL_Rect dst = {
        (g->cam.w - texW) / 2,
        (int)y,
        texW, texH
    };

    SDL_RenderCopy(g->render, tex, &src, &dst);
}