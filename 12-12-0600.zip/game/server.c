//server.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/time.h>
#include <math.h>
#include "game.h"
#include "server_system.h"

#define PORT 5000        // サーバーポート
#define MAX_CLIENT 4     // 最大クライアント数


int DoorX;
int InTheTrain;
int csock[MAX_CLIENT];           // 各クライアントのソケット
int alive[MAX_CLIENT];           // クライアント接続状態
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;  // csock/alive の排他用

CharaInfo players[MAX_CLIENT];   // プレイヤー情報
SDL_Rect TrainPoint = {0,0,0,0};
int Traped;

//========================
// 指定バイト数の読み込み
//========================
ssize_t readn(int fd, void *buf, size_t n)
{
    size_t left = n; 
    char *p = buf;
    while (left > 0) {
        ssize_t r = read(fd, p, left);
        if (r <= 0) return (r == 0 ? n-left : -1);  // EOF またはエラー
        left -= r; 
        p += r;
    }
    return n;
}

//========================
// 指定バイト数の書き込み
//========================
ssize_t writen(int fd, const void *buf, size_t n)
{
    size_t left = n; 
    const char *p = buf;
    while (left > 0) {
        ssize_t w = write(fd, p, left);
        if (w <= 0) return -1;  // エラー
        left -= w; 
        p += w;
    }
    return n;
}

Uint32 PhysicsTimerCallback(Uint32 interval, void *param)
{
    // 충돌 판정만 독립 실행
    for (CharaInfo* p = SevergCharaHead; p; p = p->next) {
        
        for (CharaInfo* q = p->next; q; q = q->next) {
            Collision(p, q);
        }
    }

    // 다음 타이머를 계속 실행하려면 interval 그대로 리턴
    return interval;
}





//========================
// サーバー側のプレイヤー移動
//========================
void MoveServer(CharaInfo *ch)
{   


     if (ch->stts == CS_Holded) return;

    if (!ch || ch->stts == CS_Disable) return;
    float vx=0, vy=0;


    // =====================
    // 先に「飛んでいる物」の物理更新（放物線）
    // =====================
    if (ch->stts == CS_Fly) {
        float dt = TICK_MS / 1000.0f;

        // 重力
        ch->vel.y += THROW_GRAVITY * dt;

        // 位置更新
        ch->point.x += ch->vel.x * dt;
        ch->point.y += ch->vel.y * dt;

        // rect 追従
        ch->rect.x = (int)ch->point.x;
        ch->rect.y = (int)ch->point.y;

        // ----- ✨ 着地判定（あなた仕様） -----
        // 投げた瞬間に計算された "この投げの着地点"
        float targetY = ch->throwLandY;

        // 下向きに到達するか、上向きに上限を超えたら着地
        // （Up でも Down でも Left/Right でも、targetY を跨いだら着地）
        if ((ch->vel.y > 0 && ch->point.y >= targetY) ||
            (ch->vel.y < 0 && ch->point.y <= targetY)) {

            // 位置を着地点に固定
            ch->point.y = targetY;
            ch->rect.y = (int)targetY;

            // 停止
            ch->vel.x = 0;
            ch->vel.y = 0;
            ch->stts = CS_Normal;
        }
        // ----- ここまで -----

        UpdateAttackRects(ch);
        return;
    }


    if (ch->type == CT_MOUSE) {
        float speed = 1.2f;
      
        ch->point.x += speed;
  
    }//敵１のMOUSEを動かす処理　今は右に進むだけ

    
    if(ch->input.spacePressed){
        printf("ch->input.spacePressed\n");
    }
       
     if (ch->input.right) {//移動モーション
       vx += MOVE_SPEED; 
       ch -> movestts = ANI_RunRight;
       ch->playerdir = Right;
      
    }
    if (ch->input.left)  {
        vx -= MOVE_SPEED;
        ch -> movestts = ANI_RunLeft;    
        ch->playerdir = Left;
        
    }
    if (ch->input.down)  {
        vy += MOVE_SPEED;   
        ch -> movestts = ANI_RunDown;
        ch->playerdir = Down; 
    }
    if (ch->input.up)  {
        vy -= MOVE_SPEED;
        ch -> movestts = ANI_RunUp;
        ch->playerdir = Up; 
    }
    else {
        ch -> movestts = ANI_Stop; 
    }


    if (ch->input.spacePressed) {
        ch->input.spacePressed = 0;

        if (ch->hold == 0) {
            Attack(ch);
        } else if (ch->hold == 1) {
            ThrowObject(ch);
        }
    }




    // ===============================
    // y軸ベースの速度調整
    // yが小さいほど遅くなる
    // ===============================
    float minY = 400.0f;  
    float maxY = 1100.0f;  
    float speedScale;

    if (ch->point.y <= minY)
        speedScale = 0.5f;   
    else if (ch->point.y >= maxY)
        speedScale = 5.0f;   
    else {
        float t = (ch->point.y - minY) / (maxY - minY);
        speedScale = 0.05f + 1.5f*t*t * (5.f - 0.05f);       
    }


    vy *= 0.35*speedScale;
    

    // 斜め移動補正
    if (vx && vy) { vx /= sqrtf(2); vy /= sqrtf(2); }

    ch->point.x += vx;
    ch->point.y += vy;

 

    // --- 持っている物を追従させる（heldTarget を使う） ---
    if (ch->hold == 1 && ch->holdTarget) {
        CharaInfo* o = ch->holdTarget;

    
        if (o->stts == CS_Holded && o->holder == ch) {

    
                int pw = ch->rect.w;
                int ow = o->rect.w;
                int oh = o->rect.h;

                float ox = ch->point.x + (pw - ow) / 2.0f;
                float oy = ch->point.y - oh - 60.0f;

                // 追従（瞬間スナップ）
                o->point.x = ox;
                o->point.y = oy;

                // rect はプレイヤー描画基準に合わせる
                o->rect.x = (int)ox;
                o->rect.y =  (int)oy;

                UpdateAttackRects(o);
    
        } 
    }

    

    

    // マップ外に出ないように制限
    if (ch->point.x < 0) ch->point.x = 0;
    
    DoorX =
    (ch->point.x >= 1750 && ch->point.x <= 1985) ||
    (ch->point.x >= 2545 && ch->point.x <= 2775) ||
    (ch->point.x >= 3820 && ch->point.x <= 4060) ||
    (ch->point.x >= 5000 && ch->point.x <= 5200) ||
    (ch->point.x >= 6290 && ch->point.x <= 6490) ||
    (ch->point.x >= 7075 && ch->point.x <= 7290);

    InTheTrain = 
    (ch->point.x >= 1100 && ch->point.x <= 7960) &&
    (ch->point.y >= 480 && ch->point.y <= 540);



    if(InTheTrain){
        ch->InSubway = SDL_TRUE;
    }else {
        ch->InSubway = SDL_FALSE;
    }
        
    
    if (traindoor) { // open

        Traped = 0;
        if (DoorX && !InTheTrain) {
            if (ch->point.y < 480) ch->point.y = 480; 
        } if(DoorX && InTheTrain){
            if (ch->point.y < 500) ch->point.y = 500;
        } if(!DoorX && InTheTrain){
            if (ch->point.y < 500) ch->point.y = 500; 
            if(ch->point.y > 530) ch->point.y = 530;
        } if(!DoorX && !InTheTrain){
            if (ch->point.y < 560) ch->point.y = 560; 
        }
        

    }else { // close
        
        if(ch->type == CT_TRAININSIDE){
            TrainPoint.x = ch->point.x;
        }

        if(ch->InSubway) {
            
            if(ch->type >= CT_PLAYER0 && ch->type <= CT_PLAYER3){
                ch->point.x += TrapHumanSpeed;  
                Traped = 1;
            }
            printf("YOu ARE TRaped !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            
            if(ch->point.y < 500) ch->point.y = 500; 
            if(ch->point.y > 530) ch->point.y = 530;
        }else {
            if (ch->point.y < 560) {
                ch->point.y = 560; 
            }
            Traped = 0;
        } 

    }
    

    if(!Traped){
      if (ch->point.x + ch->rect.w > MAP_Width) 
        ch->point.x = MAP_Width - ch->rect.w;   
    }
    if (ch->point.y + ch->rect.h > MAP_Height) 
        ch->point.y = MAP_Height - ch->rect.h;

    
    // rect の位置を更新
    ch->rect.x = (int)ch->point.x;
    if(ch->type >= CT_PLAYER0 && ch->type <= CT_PLAYER3){
       ch->rect.y = 150 + (int)ch->point.y; //player だけ+150
    }else{
        ch->rect.y = (int)ch->point.y;   
    }
   

 UpdateAttackRects(ch);
}

//========================
// 現在時刻（ミリ秒）取得
//========================
long long now_ms()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec*1000 + tv.tv_usec/1000;
}

//========================
// クライアント受信スレッド
//========================
void *RecvThread(void *arg)
{
    int id = *(int*)arg; 
    free(arg);  
    int s = csock[id];

    while (1) {
        Keystts inp;

        if (readn(s, &inp, sizeof(inp)) <= 0) break;

        CharaInfo* ch = &players[id];

        // ▶ 1. 실제 키 상태 저장
        ch->input.up    = inp.up;
        ch->input.down  = inp.down;
        ch->input.left  = inp.left;
        ch->input.right = inp.right;

        if (inp.space && ch->input.spacePressed == 0) {
            ch->input.spacePressed = 1; 
            printf("recv space\n"); 
        }
    }

    // disconnect
    pthread_mutex_lock(&mtx);
    close(csock[id]);
    csock[id] = -1;
    alive[id] = 0;
    pthread_mutex_unlock(&mtx);

    printf("Client %d disconnected\n", id);
    return NULL;
}

//========================
// ゲームループスレッド
//========================
void *GameLoop(void *arg)
{
    long long last = now_ms();

    while (1) {
        long long cur = now_ms();
        if (cur - last < TICK_MS) { 
            usleep((TICK_MS-(cur-last))*1000); 
            continue; 
        }
        last = cur;
        
        // プレイヤー移動更新
        for (CharaInfo* ch = SevergCharaHead; ch; ch = ch->next){
           
            if ((ch->type >= CT_PLAYER0 && ch->type < CT_PLAYER0 + MAX_CLIENT && alive[ch->type - CT_PLAYER0]) ||
             ch -> type == CT_MOUSE ||ch -> type == CT_TRAININSIDE||ch -> type == CT_COIN ) {
                MoveServer(ch);
            }
            UpdateScaleServer(ch);  
            
        }
        /*printf("inthetrain %d\n " ,InTheTrain );
        printf("doorX %d\n " ,DoorX );
        printf("why %d\n" , why);   */
        int train_x = 0, train_y = 0; CharaStts trainstts = ANI_TrainDoorCLOSE;//アニメーション
        
        for (CharaInfo* ch = SevergCharaHead; ch; ch = ch->next){
            if (ch->type == CT_TRAIN ) {
                long long cur = now_ms() + 1000;
                TrainMovement(ch, cur);
                train_x = ch->point.x;
                train_y = ch->point.y;
                trainstts = ch->movestts;//アニメーション
                break; 
            }
        }

        // 2) 내부 오브젝트를 모두 기차 위치에 동기화
        for (CharaInfo* ch = SevergCharaHead; ch; ch = ch->next){
            if(ch->type == CT_TRAININSIDEDOOR ||ch -> type == CT_TRAININSIDE){
                ch->point.x = train_x;
                ch->point.y = train_y;
                ch->movestts = trainstts;//アニメーション
            }
        }
        

        // ==========================================
        // ★★ デバッグ：Hold 状態を一覧表示 ★★
        // ==========================================
        for (CharaInfo* ch = SevergCharaHead; ch; ch = ch->next) {
            if (ch->hold == 1 && ch->holdTarget) {
                CharaInfo* o = ch->holdTarget;

                printf("[HOLD DEBUG] Holder(type=%d) pos=(%.1f, %.1f) rect=(%d,%d)\n",
                    ch->type,
                    ch->point.x, ch->point.y,
                    ch->rect.x, ch->rect.y);

                printf("[HOLD DEBUG] Object(type=%d) pos=(%.1f, %.1f) rect=(%d,%d)\n",
                    o->type,
                    o->point.x, o->point.y,
                    o->rect.x, o->rect.y);

                printf("--------------------------------------------------------\n");
            }
        }

            


        // クライアントに送る座標パケット作成
        NetPack pack[MAX_CLIENT];
        for (int i=0; i<MAX_CLIENT; i++) {
            pack[i].x = players[i].point.x;
            pack[i].y = players[i].point.y;
            pack[i].score = players[i].score;
            pack[i].Movestts = players[i].movestts;
            pack[i].InSubway = players[i].InSubway;
        }
        
        // player 以外オブゼット情報パケット
        NetPack objectPack[MAX_OBJECTS];
        int objectIndex = 0;
        for (CharaInfo* ch = SevergCharaHead; ch && objectIndex < MAX_OBJECTS; ch = ch->next){
            if (ch->type == CT_COIN || ch->type == CT_TRAIN ||ch->type ==  CT_MOUSE || ch -> type == CT_TRAININSIDE|| ch -> type == CT_TRAININSIDEDOOR){
                objectPack[objectIndex].x = ch->point.x;
                objectPack[objectIndex].y = ch->point.y;
                objectPack[objectIndex].rect.x = ch->rect.x;
                objectPack[objectIndex].rect.y = ch->rect.y;
                
                objectPack[objectIndex].visible = ch->stts;

                objectPack[objectIndex].Movestts = ch->movestts;
                objectIndex++;
                if(ch->stts==CS_Holded){
                     printf("[HOLD DEBUG] Object(type=%d) pos=(%.1f, %.1f) rect=(%d,%d)\n",
               ch->type,
               ch->point.x, ch->point.y,
               ch->rect.x, ch->rect.y);
                  printf("--------------------------------------------------------\n");
                }
             
    
                
            }
        }


    // 送信
    pthread_mutex_lock(&mtx);
    for (int i = 0; i < MAX_CLIENT; i++){
        if (alive[i] && csock[i] != -1){    

            if (writen(csock[i], pack, sizeof(pack)) < 0){
                close(csock[i]);
                csock[i] = -1;
                alive[i] = 0;
                continue;  // 次のクライアントへ
            }

            if (writen(csock[i], objectPack, sizeof(objectPack)) < 0){
                close(csock[i]);
                csock[i] = -1;
                alive[i] = 0;
                continue;
            }
        }
    }
        pthread_mutex_unlock(&mtx);
    }
    return NULL;
}

//========================
// メイン
//========================
int main()
{    
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    // ソケットオプション（アドレス再利用）
    int opt = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    bind(s, (struct sockaddr*)&addr, sizeof(addr));
    listen(s, MAX_CLIENT);
    printf("Server ready.\n");

    // プレイヤー初期化
    for (int i=0;i<MAX_CLIENT;i++){
        csock[i]=-1; 
        alive[i]=0;
        memset(&players[i].input,0,sizeof(players[i].input));
    }

    // NPC/プレイヤー情報を linked list に初期化
    InitServerChara("position.data", players, MAX_CLIENT);

    // ゲームループスレッド作成
    pthread_t gl;
    pthread_create(&gl,NULL,GameLoop,NULL);
    pthread_detach(gl);

    SDL_AddTimer(16, PhysicsTimerCallback, NULL);

    // クライアント接続待ち
    while(1){
        int cs = accept(s,NULL,NULL);
        pthread_mutex_lock(&mtx);

        // 空きID検索
        int id=-1;
        for (int i=0;i<MAX_CLIENT;i++) 
            if(!alive[i]){id=i;break;}

        if(id<0){close(cs); pthread_mutex_unlock(&mtx); continue;}  // 空きなし

        csock[id]=cs; 
        alive[id]=1;

        // 클라이언트에게 플레이어 id 전달
        writen(cs, &id, sizeof(int));

        pthread_mutex_unlock(&mtx);

        printf("Client %d connected\n", id);

        // 受信スレッド作成
        int *pid = malloc(sizeof(int)); 
        *pid=id;
        pthread_t th;
        pthread_create(&th,NULL,RecvThread,pid);
        pthread_detach(th);
    }
    return 0;
}
