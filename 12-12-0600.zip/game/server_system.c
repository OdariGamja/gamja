// system_server.c
#include "server_system.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <sys/time.h>

//初期化
int InitServerChara(const char* position_data_file, CharaInfo players[], int max_players)
{
    int ret = 0;
    SevergCharaHead = NULL;

    FILE* fp = fopen(position_data_file, "r");
    if (!fp) return PrintError("failed to open position data file.");

    char linebuf[MAX_LINEBUF];

    while (fgets(linebuf, MAX_LINEBUF, fp)) {
        if (linebuf[0] == '#') continue;

        unsigned int type;
        float px, py;
        int rx, ry, rw, rh;
         

        if (7 != sscanf(linebuf, "%u%f%f%d%d%d%d", &type, &px, &py, &rx, &ry, &rw, &rh)) {
            PrintError("failed to parse line in position data");
            continue;
        }

        if (type >= CT_PLAYER0 && type < CT_PLAYER0 + max_players) {
            // プレイヤーの初期化
            int i = type - CT_PLAYER0;
         
            players[i].type = type;
            players[i].point.x = px;
            players[i].point.y = py;
            players[i].rect.x = (int)px;
            players[i].rect.y = 150 + (int)py;
            players[i].rect.w = rw;
            players[i].rect.h = rh;
            players[i].Baserect.w = rw;
            players[i].Baserect.h = rh;
            players[i].playerdir = Down;
            players[i].stts = CS_Normal;
            players[i].movestts = ANI_Stop;
            players[i].hold = 0;
            players[i].holder = NULL;
            players[i].holdTarget = NULL;
            memset(&players[i].input, 0, sizeof(players[i].input));
            UpdateAttackRects(&players[i]);

            // linked list に追加
            players[i].next = SevergCharaHead;
            SevergCharaHead = &players[i];

        } else {
            // その他のNPCなど
            CharaInfo* ch = malloc(sizeof(CharaInfo));
            if (!ch) { ret = PrintError("failed to allocate NPC"); break; }

            ch->type = type;
            ch->point.x = px;
            ch->point.y = py;
            ch->rect.x = (int)px;
            ch->rect.y = (int)py;
            ch->rect.w = rw;
            ch->rect.h = rh;
            ch->Baserect.w = rw;
            ch->Baserect.h = rh;
            ch->stts = CS_Normal;
            ch->vel.x = ch->vel.y = 0;
            ch->ani.x = 0;
            ch->entity = NULL; // サーバーでは画像不要
            ch->holder = NULL;
            ch->holdTarget = NULL;
            ch->coinRespawnTime = 0;
            ch->hp=0;

            if(ch->type == CT_MOUSE){
                ch->hp=5;
            }
            

            // linked list に追加
            ch->next = SevergCharaHead;
            SevergCharaHead = ch;
        }
    }

    fclose(fp);
    return ret;
}


//y軸値によるスケール値をrectにも適用
void UpdateScaleServer(CharaInfo* ch)
{
    float yMin = 500.0f;
    float yMax = 800.0f;
    float scaleMin = 1.0f;  
    float scaleMax = 1.8f;   

    float py = ch->point.y + ch->rect.h / 2;

    float t = (py - yMin) / (yMax - yMin);
    if (t < 0) t = 0;
    if (t > 1) t = 1;

    float scale = scaleMax - t * (scaleMax - scaleMin);

    ch->rect.w = (int)(ch->Baserect.w / scale);
    ch->rect.h = (int)(ch->Baserect.h / scale);
}

void AddScore(CharaInfo* ch, int event)
{
    switch(event){
        case 1: // コイン取得
            ch->score += 100;  // スコア+1
            printf("Score Up! Player %d → score=%d\n",
                ch->type - CT_PLAYER0, ch->score);
            break;
    }
}

CharaInfo* SevergCharaHead = NULL;
void UpdateAttackRects(CharaInfo* ch)//攻撃判定の範囲更新、色々合って初期化も兼ねてる
{
    int w = ch->rect.w;
    int h = ch->rect.h;

    // 上
    ch->attackrectUp.x = ch->rect.x;
    ch->attackrectUp.y = ch->rect.y - h;
    ch->attackrectUp.w = w;
    ch->attackrectUp.h = h;

    // 下
    ch->attackrectDown.x = ch->rect.x;
    ch->attackrectDown.y = ch->rect.y + ch->rect.h;
    ch->attackrectDown.w = w;
    ch->attackrectDown.h = h;

    // 左
    ch->attackrectLeft.x = ch->rect.x - w;
    ch->attackrectLeft.y = ch->rect.y;
    ch->attackrectLeft.w = w;
    ch->attackrectLeft.h = h;

    // 右
    ch->attackrectRight.x = ch->rect.x + ch->rect.w;
    ch->attackrectRight.y = ch->rect.y;
    ch->attackrectRight.w = w;
    ch->attackrectRight.h = h;
}

//========================
// 物体を持ち上げる処理
//========================
void LiftObject(CharaInfo* ch, CharaInfo* obj)
{
    if (!ch || !obj) return;

    // 持ち上げ状態に変更
    obj->stts = CS_Holded;
     // 持ち主を記録
      obj->holder = ch;
      ch->holdTarget =obj;


    // プレイヤーの位置
    float px = ch->point.x;
    float py = ch->point.y;
    int   pw = ch->rect.w;


    // 物体のサイズ
    int ow = obj->rect.w;
    int oh = obj->rect.h;

    // きれいに中心合わせ
    float ox = px + (pw - ow) / 2.0f;
    float oy = py - oh - 60;     

    // 位置を更新
    obj->point.x = ox;
    obj->point.y = oy;
    obj->rect.x  = (int)ox;
    obj->rect.y  = (int)oy;

    ch->hold = 1;     // 「持っている」状態に

    printf("LiftObject: type=%d  stts %d placed at (%.1f, %.1f)\n", obj->type,obj->stts, ox, oy);
    printf("LiftObject: type=%d placed at (%.1f, %.1f)\n", ch->type, px, py);
    
}


void Attack(CharaInfo* ch) //攻撃処理　
{
    SDL_Rect* atk = NULL;
    if (ch->playerdir == Up)    atk = &ch->attackrectUp;
    if (ch->playerdir == Down)  atk = &ch->attackrectDown;
    if (ch->playerdir == Left)  atk = &ch->attackrectLeft;
    if (ch->playerdir == Right) atk = &ch->attackrectRight;

    if (!atk) return;
    

    const float knockbackPower = 100.0f;   // ← ノックバック量

    for (CharaInfo* target = SevergCharaHead; target; target = target->next) {
        if(ch->hold==0){//持ってないとき

        if (target == ch) continue;
        if (target->stts != CS_Normal) continue;

          if (target->type == CT_COIN){
            if (SDL_HasIntersection(atk, &target->rect)) {
               LiftObject(ch, target);
               printf("LIFTUP");
          }
        }

        if (target->type == CT_MOUSE) {//ネズミへの攻撃

            if (SDL_HasIntersection(atk, &target->rect)) {

                printf("Attack hit! target=%d\n", target->type);

                // ダメージ
                target->hp -= 1;

                //ノックバック
                switch (ch->playerdir) {
                case Up:
                    target->point.y -= knockbackPower;
                    break;
                case Down:
                    target->point.y += knockbackPower;
                    break;
                case Left:
                    target->point.x -= knockbackPower;
                    break;
                case Right:
                    target->point.x += knockbackPower;
                    break;
                }

                // rect 更新（プレイヤー以外はそのまま）
                target->rect.x = (int)target->point.x;
                target->rect.y = (int)target->point.y;
                UpdateAttackRects(target);

                // 倒されたかチェック
                if (target->hp <= 0) {
                    target->stts = CS_Disable;
                    printf("Enemy %d defeated!\n", target->type);
                }
            }
        }

        }

    }
}



// --- CollisionPlayer の修正 ---
SDL_bool CollisionPlayer(CharaInfo* a, CharaInfo* b)
{
    if (a->stts == CS_Disable || b->stts == CS_Disable) return SDL_FALSE;

    if (a->stts == CS_Holded || b->stts == CS_Holded)
    return SDL_FALSE;


    SDL_Rect ra = a->rect;
    SDL_Rect rb = b->rect;
    SDL_Rect ir;
    if (!SDL_IntersectRect(&ra, &rb, &ir)) return SDL_FALSE;
    int overlapW = ir.w;
    int overlapH = ir.h;

    // ← ここを point を使うのではなく rect を基準にする
    float ax = (float)a->rect.x + a->rect.w / 2.0f;
    float ay = (float)a->rect.y + a->rect.h / 2.0f;
    float bx = (float)b->rect.x + b->rect.w / 2.0f;
    float by = (float)b->rect.y + b->rect.h / 2.0f;

    float dx = ax - bx;
    float dy = ay - by;

    if (overlapW < overlapH) {
        float push = overlapW / 2.0f;
        a->point.x += (dx > 0 ? push : -push);
        b->point.x -= (dx > 0 ? push : -push);
    } else {
        float push = overlapH / 2.0f;
        a->point.y += (dy > 0 ? push : -push);
        b->point.y -= (dy > 0 ? push : -push);
    }

    // 移動制限（そのまま）
    if (a->point.x < 0) a->point.x = 0;
    if (a->point.y < 0) a->point.y = 0;
    if (a->point.x + a->rect.w > MAP_Width) a->point.x = MAP_Width - a->rect.w;
    if (a->point.y + a->rect.h > MAP_Height) a->point.y = MAP_Height - a->rect.h;

    if (b->point.x < 0) b->point.x = 0;
    if (b->point.y < 0) b->point.y = 0;
    if (b->point.x + b->rect.w > MAP_Width) b->point.x = MAP_Width - b->rect.w;
    if (b->point.y + b->rect.h > MAP_Height) b->point.y = MAP_Height - b->rect.h;

    // rect の更新（プレイヤーだけ y を +150）
    if (a->type >=CT_PLAYER0 && a->type <= CT_PLAYER3) {
        a->rect.x = (int)a->point.x;
        a->rect.y = 150 + (int)a->point.y;
    } else {
        a->rect.x = (int)a->point.x;
        a->rect.y = (int)a->point.y;
    }

    if (b->type >=CT_PLAYER0 && b->type <= CT_PLAYER3) {
        b->rect.x = (int)b->point.x;
        b->rect.y = 150 + (int)b->point.y;
    } else {
        b->rect.x = (int)b->point.x;
        b->rect.y = (int)b->point.y;
    }

    UpdateAttackRects(a);
    UpdateAttackRects(b);

    return SDL_TRUE;
}




//当たり判定
SDL_bool Collision(CharaInfo* a, CharaInfo* b)
{
    // stts が Normal でなければ衝突しない
    if (a->stts != CS_Normal || b->stts != CS_Normal)
        return SDL_FALSE;
    if (a->stts == CS_Holded || b->stts == CS_Holded)
    return SDL_FALSE;

    SDL_Rect ir;
    if (!SDL_IntersectRect(&a->rect, &b->rect, &ir))
        return SDL_FALSE;

    int aIsPlayer = (a->type >= CT_PLAYER0 && a->type <= CT_PLAYER3);
    int bIsPlayer = (b->type >= CT_PLAYER0 && b->type <= CT_PLAYER3);
    int aIsCoin   = (a->type == CT_COIN);
    int bIsCoin   = (b->type == CT_COIN);
    int aIsMouse  = (a->type == CT_MOUSE);
    int bIsMouse  = (b->type == CT_MOUSE);

    // --- プレイヤー同士 ---
    if (aIsPlayer && bIsPlayer) {
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }

    // --- プレイヤー & コイン ---
    if (aIsPlayer && bIsCoin) {
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }
    if (bIsPlayer && aIsCoin) {
        CollisionPlayer(b, a);
        return SDL_TRUE;
    }

    // --- プレイヤー & ねずみ ---
    if (aIsPlayer && bIsMouse) {
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }
    if (bIsPlayer && aIsMouse) {
        CollisionPlayer(b, a);
        return SDL_TRUE;
    }

    // --- コイン同士 ---
    if (aIsCoin && bIsCoin) {
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }

    // --- ねずみ同士 ---
    if (aIsMouse && bIsMouse) {
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }

    // --- コイン & ねずみ ---
    if ((aIsCoin && bIsMouse) || (bIsCoin && aIsMouse)) {
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }

    return SDL_FALSE;
}
// 投げの物理パラメータ（調整可）

void ThrowObject(CharaInfo* ch)
{
    if (!ch || ch->hold != 1 || !ch->holdTarget) return;

    CharaInfo* obj = ch->holdTarget;

    float vx = 0.0f;
    float vy = 0.0f;

    // ---- 初速設定 ----
    switch (ch->playerdir) {
        case Up:
            vx = 0;
            vy = THROW_POWER_UP;        // ※THROW_POWER_UP は負の値
            break;

        case Down:
            vx = 0;
            vy = THROW_POWER_DOWN;      // 正の値
            break;

        case Left:
            vx = -THROW_POWER_X;
            vy = THROW_POWER_UP * 0.35f;  // 少し上向きに
            break;

        case Right:
            vx = THROW_POWER_X;
            vy = THROW_POWER_UP * 0.35f;
            break;
    }

    // --- 手の位置から飛び出す ---
    int pw = ch->rect.w;
    int ow = obj->rect.w;
    float start_x = ch->point.x + (pw - ow) / 2.0f;
    float start_y = ch->point.y - obj->rect.h - 60.0f;

    obj->point.x = start_x;
    obj->point.y = start_y;
    obj->rect.x = (int)start_x;
    obj->rect.y = (int)start_y;

    // 物理初速をセット（ここが一番大事）
    obj->vel.x = vx;
    obj->vel.y = vy;

    // 状態を飛行中へ
    obj->stts = CS_Fly;

    // holder解除
    obj->holder = NULL;
    ch->holdTarget = NULL;
    ch->hold = 0;

    // ---- 着地地点（あなたの条件） ----
    float baseY = ch->rect.y + ch->rect.h;

    switch (ch->playerdir) {
        case Up:    obj->throwLandY = baseY - 70.0f; break;
        case Down:  obj->throwLandY = baseY + 70.0f; break;
        case Left:
        case Right:
            obj->throwLandY = baseY;     break;
        default:
            obj->throwLandY = baseY;     break;
    }

    printf("ThrowObject: start=(%.1f,%.1f) vel=(%.1f,%.1f) targetY=%.1f\n",
        obj->point.x, obj->point.y, obj->vel.x, obj->vel.y, obj->throwLandY);
}





#define TRAIN_START_X   -25000.0f
#define TRAIN_END_X     5000.0f
#define TRAIN_SPEED     3200.0f        // 速度
#define TRAIN_INTERVAL  60000          //1分ごとに入って来る

void TrainMovement(CharaInfo *ch, long long cur)
{
    // 移動状態
    enum {
        TRAIN_STATE_MOVING,
        TRAIN_STATE_DECEL,
        TRAIN_STATE_STOPPED,
        TRAIN_STATE_ACCEL
    };
    static int state = TRAIN_STATE_MOVING;
    
    // 時間保存
    static long long stopEndTime = 0;

    //-----------------------------------------
    // パラメータ
    //-----------------------------------------
    const float decelPoint = 550.0f;     // 目標停車位置
    const float stopDuration = 15000;    // 15秒
    const float maxSpeed = 1600.0f;      // 最高速度
    const float minSpeed = 50.0f;        // ほぼ停止速度
    const float decelDist = 2000.0f;     // 減速区間 長さ(px)
    const float accelDist = 2000.0f;     // 加速区間 長さ(px)

    float dt = TICK_MS / 1000.0f;

    //-----------------------------------------
    // 1) 右に移動 
    //-----------------------------------------
    if (state == TRAIN_STATE_MOVING)
    {
        ch->point.x += maxSpeed * dt;

        // 減速開始地点に到達
        if (ch->point.x >= decelPoint - decelDist)
            state = TRAIN_STATE_DECEL;

        return;
    }

    //-----------------------------------------
    // 2)減速
    //-----------------------------------------
    if (state == TRAIN_STATE_DECEL)
    {
        float distToStop = decelPoint - ch->point.x;
        if (distToStop < 0) distToStop = 0;

        // 0~1
        float t = distToStop / decelDist;
        if (t < 0) t = 0;
        if (t > 1) t = 1;

        float speed = minSpeed + t * (maxSpeed - minSpeed);
        ch->point.x += speed * dt;

        // 停車地点到着
        if (ch->point.x >= decelPoint)
        {
            ch->point.x = decelPoint;
            stopEndTime = cur + (long long)stopDuration;
            state = TRAIN_STATE_STOPPED;
        }

        return;
    }

    //-----------------------------------------
    // 3) 停車(15秒待ち)
    //-----------------------------------------
    if (state == TRAIN_STATE_STOPPED)
    {
        long long remain = stopEndTime - cur;
        TrapHumanSpeed = 0;
        //到着→ドアが開く
        if (remain <= stopDuration && remain > stopDuration - 2000) {
            ch->movestts = ANI_TrainDoorOPEN;
            traindoor = 1;
        }
        // 出発2秒前→ドアを閉める
        else if (remain <= 2000 && remain > 0) {
            ch->movestts = ANI_TrainDoorCLOSE;
            traindoor = 0;
        }

        // 停車時間切れ→ACCELに切り替え
        if (cur >= stopEndTime) {
            state = TRAIN_STATE_ACCEL;
            
        }
        return;
    }
    
    //----------------------------------------- 
    // 4) 加速
    //-----------------------------------------
    if (state == TRAIN_STATE_ACCEL)
    {
        float distFromStop = ch->point.x - decelPoint;
        if (distFromStop < 0) distFromStop = 0;

        float t = distFromStop / accelDist;
        if (t > 1) t = 1;

        float speed = minSpeed + t * (maxSpeed - minSpeed);
        ch->point.x += speed * dt;
        TrapHumanSpeed = speed * dt;

        if (ch->point.x >= TRAIN_END_X)
        {
            ch->point.x = TRAIN_START_X;
            state = TRAIN_STATE_MOVING;
        }

        return;
    }
}





int PrintError(const char* msg)
{
    fprintf(stderr, "Error: %s\n", msg);
    return -1;
}
