#ifndef SERVER_SYSTEM_H
#define SERVER_SYSTEM_H
#define TICK_MS 33

#define THROW_POWER_X 5000.0f
#define THROW_POWER_UP -500.0f
#define THROW_POWER_DOWN 700.0f
#define THROW_GRAVITY 50000.0f

#include "game.h"

extern CharaInfo *SevergCharaHead;

// 位置データファイルから NPC とプレイヤーを初期化
int InitServerChara(const char *position_data_file, CharaInfo players[], int max_players);

// 衝突判定
SDL_bool CollisionPlayer(CharaInfo *a, CharaInfo *b);
SDL_bool Collision(CharaInfo *ci, CharaInfo *cj);
int PrintError(const char *msg);
void UpdateScaleServer(CharaInfo *ch);
long long now_ms();
// edited by sudo
void SpawnCoin(float x, float y);
void HitATM(CharaInfo *atm);
void UpdateATM(CharaInfo *atm, long long cur);
// ここまで
void Attack(CharaInfo *ch); // 攻撃処理　
void UpdateAttackRects(CharaInfo *ch);
void TrapInTrain(CharaInfo *ch);
int traindoor;
int InTheTrain;
int TrapHumanSpeed;

void ThrowObject(CharaInfo *ch);

#endif
