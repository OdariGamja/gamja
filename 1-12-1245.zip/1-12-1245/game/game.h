// game.h

#ifndef GAME_H
#define GAME_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>

#define MAX_PATH 256
#define MAX_LINEBUF 256
#define MOVE_SPEED 20.f
#define WD_Width 1980
#define WD_Height 1080
#define MAP_Width 10312
#define MAP_Height 1391

#define MAX_OBJECTS 30

#define ATM_ConstNumber 225
#define Vendor_ConstNumber 230

/* ??????????????????????????? */
typedef enum
{
    CT_PLAYER0 = 0,
    CT_PLAYER1 = 1,
    CT_PLAYER2 = 2,
    CT_PLAYER3 = 3,
    CT_COIN = 4,
    CT_TRAIN = 5,
    CT_TRAININSIDE = 6,
    CT_TRAININSIDEDOOR = 7,
    CT_MOUSE = 8,
    CT_Vendor = 9,
    CT_ATM = 10,
    CT_TRAIN_PASS = 11,
    CT_IMG = 12
} CharaType;
#define CHARATYPE_NUM 13

/* ???????????????????????????????????? */
typedef struct
{
    int w, h;
    char *path;
    SDL_Point aninum;
    SDL_Texture *img;
} CharaTypeInfo;

/* ??????????????????????????? */
typedef enum
{
    CS_Normal = 0,
    CS_Disable = 1,
    CS_Holded = 2, //?????????????????????????????????
    CS_Fly = 3,
    CS_Knockdown = 4,
    CS_Death = 5,
    CS_FallWait = 6,
    CS_Falling = 7
} CharaStts;

/*??????????????????????????????????????????*/
typedef enum
{
    ANI_Stop = 0,
    ANI_RunRight = 1,
    ANI_RunLeft = 2,
    ANI_RunDown = 3,
    ANI_RunUp = 4,
    ANI_RightAttack = 5,
    ANI_LeftAttack = 6,
    ANI_DownAttack = 7,
    ANI_UpAttack = 8,
    ANI_TrainDoorCLOSE = 9,
    ANI_TrainDoorOPEN = 10,
    ANI_ATM_LIGHTON_DEFALT = 11,
    ANI_ATM_LIGHTOFF_DEFALT = 12,
    ANI_ATM_LIGHTOFF_VIBRATE = 13,
    ANI_VENDER_PUMP = 14
} CharaMoveStts;

/* ????????????????????? */
typedef struct
{
    SDL_bool right;
    SDL_bool left;
    SDL_bool down;
    SDL_bool up;
    SDL_bool space;
    int spacePrev;
    int spacePressed;
} Keystts;

/*????????????????????????*/
typedef enum
{
    Right = 1,
    Left = 2,
    Down = 3,
    Up = 4
} Dir;

/* ??????????????????????????? */
typedef struct CharaInfo_t
{
    CharaStts stts;
    CharaTypeInfo *entity;
    SDL_Rect rect;
    SDL_Rect Vendor_rect;
    SDL_Rect attackrectUp;
    SDL_Rect attackrectDown;
    SDL_Rect attackrectLeft;
    SDL_Rect attackrectRight;
    SDL_Rect Baserect;
    SDL_Rect imgsrc;
    SDL_FPoint vel;
    float knockVX;
    float knockVY;
    float vx, vy;
    int playerdir;
    SDL_FPoint point;
    SDL_Point ani;
    CharaType type;
    CharaMoveStts movestts;
    float aniTimer;
    struct CharaInfo_t *next;
    int exp;
    int level;
    Keystts input;             // ????? ??????
    long long coinRespawnTime; // ?????????????????????????????????
    long long AtmTime;
    long long VibrateEnd;
    long long KnockdownTime;
    int animTimer;
    int score;
    int hp;
    int hold; //???????????????????????????????
    struct CharaInfo_t *holder;
    struct CharaInfo_t *holdTarget;
    float throwBaseY; // ????????????????????????????????????????Y
    float throwLandX;
    float throwLandY; // ?????????????????????????????? Y ?????
    SDL_bool InSubway;
    int inputcount;
    int whoholder; // player0 が1　player1が2 と一個ずつずらしてる
    // CharaInfo に追加
    long long knockRemainMs; // 残りKnockdown時間
    long long knockLastMs;   // 前回更新時刻
    long long lastAttackMs;  // 最後に攻撃したときの時間
    long long deadAtMs;      // 死亡した時刻（ms）
    long long fallStartMs;   // 落下待ち開始時刻
    float fallVy;            // 落下速度

} CharaInfo;

/* ?????????????????? */
typedef enum
{
    GS_Ready = 0,
    GS_Playing = 1,
} GameStts;

typedef struct
{
    int x, y; // ??????? ???????? ?????
    int w, h; // ????? ????? (????????? ?????)
} Camera;

typedef struct
{ // client <-> sever pack
    float x, y;
    SDL_Rect rect;
    int visible; // 1:??��??, 0:???????
    int score;
    CharaMoveStts Movestts;
    SDL_bool InSubway;
    Dir direction;
    int whoholder;
    CharaStts stts;
} NetPack;

/* ?????????????????? */
typedef struct
{
    CharaInfo *player;
    GameStts stts;
    SDL_Window *window;
    SDL_Renderer *render;
    SDL_Texture *bg;
    SDL_Texture *Texture_UI;
    SDL_Rect image_src_UI;
    SDL_Texture *Texture_Number; // 数字画像用のテクスチャ by sudo
    SDL_Point dp;
    Keystts input;
    Camera cam;
    float timeDelta;

} GameInfo;

enum
{
    THROWtoVendor
};

/* ???? ?????? ????? ??????*/
extern GameInfo gGames[CHARATYPE_NUM];
extern CharaTypeInfo gCharaType[CHARATYPE_NUM];

/* ???? ?????? ?????? */
int InitSystem(const char *chara_file, const char *pos_file, int my_id);
void DestroySystem(void);
void InitCharaInfo(CharaInfo *ch);
SDL_bool InputEvent(GameInfo *game);
void MoveChara(CharaInfo *ch, GameInfo *game);
SDL_bool InputEvent(GameInfo *game);

int InitWindow(GameInfo *game, const char *title, const char *bg_file, int width, int height);
void CloseWindow(GameInfo *game);
void UpdateAnimation(GameInfo *game, float deltaTime);
void DrawGame(GameInfo *game);
int PrintError(const char *msg);
CharaInfo *GetPlayerChara(int my_id);
void UpdateCamera(GameInfo *gGame, CharaInfo *player);
void StartMenu(GameInfo *gGame);
void TrainMovement(CharaInfo *ch, long long cur);
void TrainMovement_Pass(CharaInfo *ch);
void IMGMovement(CharaInfo *ch);
void UpdateKnockback(CharaInfo *ch);
void UpdateATM(CharaInfo *atm);
#endif