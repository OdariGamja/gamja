// client.c
// 빌드: gcc client.c -o client -lpthread -lSDL2 -lSDL2_image

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "game.h"

#define SERVER_PORT 5000
#define MAX_CLIENT 4

char server_ip[64];

int my_id;
int sock;
struct sockaddr_in server_addr;

extern GameInfo gGames[CHARATYPE_NUM];
extern CharaInfo* gCharaHead;

// 네트워크용 가벼운 포지션 구조
typedef struct {
    float x, y;
} NetCharaPos;

ssize_t readn(int fd, void *buf, size_t n) {
    size_t left = n;
    ssize_t r;
    char *p = buf;
    while (left > 0) {
        r = read(fd, p, left);
        if (r < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (r == 0) return (n - left);
        left -= r;
        p += r;
    }
    return n;
}

ssize_t writen(int fd, const void *buf, size_t n) {
    size_t left = n;
    ssize_t w;
    const char *p = buf;
    while (left > 0) {
        w = write(fd, p, left);
        if (w <= 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        left -= w;
        p += w;
    }
    return n;
}

Uint32 AnimationCallback(Uint32 interval, void* param) {
    GameInfo* game = (GameInfo*)param;
    UpdateAnimation(game, interval / 1000.0f);
    return interval;
}

// 스레드 안전하게 서버에서 받은 최신 포지션을 저장
NetCharaPos latestPos[MAX_CLIENT];
pthread_mutex_t pos_mutex = PTHREAD_MUTEX_INITIALIZER;

void* ReceiveThread(void* arg) {
    (void)arg;
    while (1) {
        NetCharaPos buf[MAX_CLIENT];
        ssize_t r = readn(sock, buf, sizeof(buf));
        if (r <= 0) {
            perror("readn");
            break;
        }

        pthread_mutex_lock(&pos_mutex);
        for (int i = 0; i < MAX_CLIENT; i++) {
            latestPos[i] = buf[i];
        }
        pthread_mutex_unlock(&pos_mutex);
    }
    return NULL;
}

void SendInput(Keystts* input) {
    if (writen(sock, input, sizeof(Keystts)) != sizeof(Keystts)) {
        perror("write failed");
    }
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        printf("Usage: %s <my_id> <server_ip>\n", argv[0]);
        return 1;
    }

    my_id = atoi(argv[1]);
    strcpy(server_ip, argv[2]);

    InitSystem("chara.data", "position.data", my_id);
    InitWindow(&gGames[my_id], "Test", "bg.png", 1280, 720);

    // 초기 latestPos를 파일에서 읽은 초기 위치로 세팅
    for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
        if (ch->type >= CT_PLAYER0 && ch->type < CT_PLAYER0 + MAX_CLIENT) {
            int idx = ch->type - CT_PLAYER0;
            latestPos[idx].x = ch->point.x;
            latestPos[idx].y = ch->point.y;
        }
    }

    sock = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, server_ip, &server_addr.sin_addr);

    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect");
        return 1;
    }

    pthread_t th;
    pthread_create(&th, NULL, ReceiveThread, NULL);

    SDL_AddTimer(16, AnimationCallback, &gGames[my_id]);

    Uint32 lastTime = SDL_GetTicks();
    SDL_bool running = SDL_TRUE;
    while (running) {
        Uint32 now = SDL_GetTicks();
        gGames[my_id].timeDelta = (now - lastTime) / 1000.0f;
        lastTime = now;

        running = InputEvent(&gGames[my_id]);

        // 입력 전송
        SendInput(&gGames[my_id].input);

        // 서버에서 받은 latestPos를 이용해 보간 (자기 자신도 보간)
        pthread_mutex_lock(&pos_mutex);
        CharaInfo* ch = gCharaHead;
        for (int i = 0; i < MAX_CLIENT && ch; i++, ch = ch->next) {
            // 보간 계수: 0.2 정도로 부드럽게 따라가게 함
            float blend = 0.2f;
            float targetX = latestPos[i].x;
            float targetY = latestPos[i].y;

            ch->point.x += (targetX - ch->point.x) * blend;
            ch->point.y += (targetY - ch->point.y) * blend;
            ch->rect.x = (int)ch->point.x;
            ch->rect.y = (int)ch->point.y;
        }
        pthread_mutex_unlock(&pos_mutex);

        DrawGame(&gGames[my_id]);

        SDL_Delay(8);
    }

    close(sock);
    CloseWindow(&gGames[my_id]);
    DestroySystem();
    return 0;
}
