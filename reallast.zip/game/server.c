#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/time.h>
#include <math.h>
#include <netinet/tcp.h>
#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <sched.h>
#include "game.h"

#define PORT 5000
#define MAX_CLIENT 4
#define TICK_MS 33

typedef struct { uint32_t seq; float x, y; } NetPos;

int csock[MAX_CLIENT];
int alive[MAX_CLIENT];
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
CharaInfo players[MAX_CLIENT];

ssize_t readn(int fd, void *buf, size_t n) {
    size_t left = n; char *p = buf;
    while (left > 0) {
        ssize_t r = read(fd, p, left);
        if (r < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (r == 0) return (n - left);
        left -= r; p += r;
    }
    return n;
}
ssize_t writen(int fd, const void *buf, size_t n) {
    size_t left = n; const char *p = buf;
    while (left > 0) {
        ssize_t w = write(fd, p, left);
        if (w <= 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        left -= w; p += w;
    }
    return n;
}
long long now_ms() {
    struct timeval tv; gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000 + tv.tv_usec/1000;
}
void MoveServer(CharaInfo *ch) {
    if (!ch || ch->stts == CS_Disable) return;
    float vx=0,vy=0;
    if(ch->input.right) vx+=MOVE_SPEED;
    if(ch->input.left)  vx-=MOVE_SPEED;
    if(ch->input.down)  vy+=MOVE_SPEED;
    if(ch->input.up)    vy-=MOVE_SPEED;
    if(vx&&vy){vx/=sqrtf(2);vy/=sqrtf(2);}
    ch->point.x+=vx; ch->point.y+=vy;
    if(ch->point.x<0) ch->point.x=0;
    if(ch->point.y<0) ch->point.y=0;
    if(ch->point.x+ch->rect.w>MAP_Width) ch->point.x=MAP_Width-ch->rect.w;
    if(ch->point.y+ch->rect.h>MAP_Height) ch->point.y=MAP_Height-ch->rect.h;
    ch->rect.x=(int)ch->point.x;
    ch->rect.y=(int)ch->point.y;
}

// ---------------- RecvThread 최적화 ----------------
void *RecvThread(void *arg){
    int id=*(int*)arg; free(arg);
    int s=csock[id];

    // 1) 소켓 논블로킹 설정
    int flags = fcntl(s,F_GETFL,0);
    fcntl(s,F_SETFL,flags | O_NONBLOCK);

    // 2) 스레드 우선순위 상승
    struct sched_param param;
    param.sched_priority = 20;
    pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);

    Keystts inp;
    while(1){
        ssize_t r = read(s,&inp,sizeof(inp));
        if(r == sizeof(inp)){
            players[id].input = inp;
        } else if(r==0){
            break; // 클라 종료
        }
        // CPU 점유 줄이면서 빠르게 재시도
        usleep(100); // 0.1ms
    }

    pthread_mutex_lock(&mtx);
    if(csock[id]!=-1) close(csock[id]);
    csock[id]=-1; alive[id]=0;
    pthread_mutex_unlock(&mtx);
    printf("Client %d disconnected\n",id);
    return NULL;
}

// ---------------- GameLoop (기존) ----------------
void *GameLoop(void *arg){
    long long last = now_ms();
    uint32_t seq=1;
    long long last_debug_report = last;
    while(1){
        long long cur = now_ms();
        long long dt = cur-last;
        if(dt<TICK_MS){ usleep((TICK_MS-dt)*1000); continue; }
        last = cur;

        for(int i=0;i<MAX_CLIENT;i++) if(alive[i]) MoveServer(&players[i]);

        NetPos pack[MAX_CLIENT];
        for(int i=0;i<MAX_CLIENT;i++){
            pack[i].seq = seq;
            pack[i].x = players[i].point.x;
            pack[i].y = players[i].point.y;
        }
        seq++; if(seq==0) seq=1;

        pthread_mutex_lock(&mtx);
        for(int i=0;i<MAX_CLIENT;i++){
            if(alive[i] && csock[i]!=-1){
                writen(csock[i],pack,sizeof(pack));
            }
        }
        pthread_mutex_unlock(&mtx);

        if(cur-last_debug_report>=1000){
            int connected=0;
            pthread_mutex_lock(&mtx);
            for(int i=0;i<MAX_CLIENT;i++) if(alive[i]) connected++;
            pthread_mutex_unlock(&mtx);
            printf("[SERVER STATUS] time=%lld ms connected=%d seq=%u\n",cur,connected,seq);
            last_debug_report=cur;
        }
    }
    return NULL;
}

// ---------------- main ----------------
int main(){
    int s=socket(AF_INET,SOCK_STREAM,0);
    struct sockaddr_in addr={0};
    addr.sin_family=AF_INET;
    addr.sin_port=htons(PORT);
    addr.sin_addr.s_addr=INADDR_ANY;
    int opt=1;
    setsockopt(s,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));
    bind(s,(struct sockaddr*)&addr,sizeof(addr));
    listen(s,MAX_CLIENT);
    printf("Server ready.\n");

    for(int i=0;i<MAX_CLIENT;i++){
        csock[i]=-1; alive[i]=0;
        players[i].point.x=100+i*50; players[i].point.y=200;
        players[i].rect.w=32; players[i].rect.h=48;
        players[i].stts=CS_Normal;
        memset(&players[i].input,0,sizeof(players[i].input));
    }

    pthread_t gl;
    pthread_create(&gl,NULL,GameLoop,NULL);
    pthread_detach(gl);

    while(1){
        int cs = accept(s,NULL,NULL);
        if(cs<0){ perror("accept"); continue; }

        pthread_mutex_lock(&mtx);
        int id=-1;
        for(int i=0;i<MAX_CLIENT;i++) if(!alive[i]){ id=i; break; }
        if(id<0){ close(cs); pthread_mutex_unlock(&mtx); continue; }
        csock[id]=cs; alive[id]=1;
        pthread_mutex_unlock(&mtx);

        int flag=1;
        setsockopt(csock[id],IPPROTO_TCP,TCP_NODELAY,&flag,sizeof(flag));

        printf("Client %d connected (fd=%d)\n",id,csock[id]);

        int *pid = malloc(sizeof(int)); *pid=id;
        pthread_t th;
        pthread_create(&th,NULL,RecvThread,pid);
        pthread_detach(th);
    }
    return 0;
}
