// server.c
// 빌드: gcc server.c -o server -lpthread

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/time.h>
#include <errno.h>

#include "game.h"

#define SERVER_PORT 5000
#define MAX_CLIENT 4
#define TICK_MS 33 // 약 30Hz

int client_sock[MAX_CLIENT];
int client_connected[MAX_CLIENT];
pthread_mutex_t clients_mutex = PTHREAD_MUTEX_INITIALIZER;

// 서버 내부에서 전송할 최소 구조체 — 포인터/텍스처 등은 전송하지 않음
typedef struct
{
    float x, y;
} NetCharaPos;

// 서버 내부 플레이어 배열 (간단히 position+input 저장)
CharaInfo players[MAX_CLIENT];

// 안전한 읽기/쓰기 (readn/writen)
ssize_t readn(int fd, void *buf, size_t n)
{
    size_t left = n;
    ssize_t r;
    char *p = buf;
    while (left > 0)
    {
        r = read(fd, p, left);
        if (r < 0)
        {
            if (errno == EINTR)
                continue;
            return -1;
        }
        if (r == 0)
            return (n - left); // EOF
        left -= r;
        p += r;
    }
    return n;
}

ssize_t writen(int fd, const void *buf, size_t n)
{
    size_t left = n;
    ssize_t w;
    const char *p = buf;
    while (left > 0)
    {
        w = write(fd, p, left);
        if (w <= 0)
        {
            if (errno == EINTR)
                continue;
            return -1;
        }
        left -= w;
        p += w;
    }
    return n;
}

// 각 클라이언트로부터 입력을 받고 players[id].input 에 저장
void *ClientRecvThread(void *arg)
{
    int id = *(int *)arg;
    free(arg);

    int sock = client_sock[id];
    while (1)
    {
        Keystts input;
        ssize_t r = readn(sock, &input, sizeof(input));
        if (r <= 0)
            break;

        // 입력을 players[id].input 으로 복사 (뮤텍스 필요 X, main loop가 읽기 전까지 최신 값 덮어써도 OK)
        players[id].input = input;
        // optional: 로그
        // if (input.up || input.down || input.left || input.right) {
        //     printf("recv id=%d up=%d down=%d left=%d right=%d\n", id, input.up, input.down, input.left, input.right);
        // }
    }

    // 연결 종료
    pthread_mutex_lock(&clients_mutex);
    close(client_sock[id]);
    client_sock[id] = -1;
    client_connected[id] = 0;
    pthread_mutex_unlock(&clients_mutex);
    printf("Client %d disconnected\n", id);
    return NULL;
}

// 서버 전용 간단한 이동 함수 (system.c 의 MoveChara와 동일 로직, GameInfo 불필요하게 만들지 않음)
void ServerMoveChara(CharaInfo *ch)
{
    if (!ch)
        return;
    if (ch->stts == CS_Disable)
        return;

    float vx = 0.0f, vy = 0.0f;
    Keystts *input = &ch->input;

    if (input->right)
        vx += MOVE_SPEED;
    if (input->left)
        vx -= MOVE_SPEED;
    if (input->down)
        vy += MOVE_SPEED;
    if (input->up)
        vy -= MOVE_SPEED;

    if (vx != 0.0f && vy != 0.0f)
    {
        vx /= sqrtf(2.0f);
        vy /= sqrtf(2.0f);
    }

    ch->point.x += vx;
    ch->point.y += vy;

    if (ch->point.x < 0)
        ch->point.x = 0;
    if (ch->point.y < 0)
        ch->point.y = 0;
    if (ch->point.x + ch->rect.w > MAP_Width)
        ch->point.x = MAP_Width - ch->rect.w;
    if (ch->point.y + ch->rect.h > MAP_Height)
        ch->point.y = MAP_Height - ch->rect.h;

    ch->rect.x = (int)ch->point.x;
    ch->rect.y = (int)ch->point.y;
}

long long now_ms()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

int main()
{
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        perror("socket");
        return 1;
    }

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(SERVER_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    int opt = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    if (bind(sockfd, (struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
        perror("bind");
        return 1;
    }
    if (listen(sockfd, MAX_CLIENT) < 0)
    {
        perror("listen");
        return 1;
    }

    // 초기화
    for (int i = 0; i < MAX_CLIENT; i++)
    {
        client_sock[i] = -1;
        client_connected[i] = 0;
        players[i].point.x = 100 + i * 50;
        players[i].point.y = 200;
        players[i].rect.w = 32;
        players[i].rect.h = 48; // 기본값 (game.h 기준)
        players[i].stts = CS_Normal;
        memset(&players[i].input, 0, sizeof(players[i].input));
    }

    printf("Server listening on port %d\n", SERVER_PORT);

    // accept 스레드 대체: 메인 루프에서 accept 비블로킹으로 처리 가능하지만 간단히 accept 한 뒤 recv 스레드 생성
    while (1)
    {
        int csock = accept(sockfd, NULL, NULL);
        if (csock < 0)
        {
            perror("accept");
            continue;
        }

        pthread_mutex_lock(&clients_mutex);
        int id = -1;
        for (int i = 0; i < MAX_CLIENT; i++)
        {
            if (!client_connected[i])
            {
                id = i;
                break;
            }
        }
        if (id == -1)
        {
            // 여유 슬롯 없음
            printf("Rejecting client (no slot)\n");
            close(csock);
            pthread_mutex_unlock(&clients_mutex);
            continue;
        }
        client_sock[id] = csock;
        client_connected[id] = 1;
        pthread_mutex_unlock(&clients_mutex);

        printf("Client %d connected (fd=%d)\n", id, csock);

        // recv 스레드 생성
        pthread_t th;
        int *pid = malloc(sizeof(int));
        *pid = id;
        pthread_create(&th, NULL, ClientRecvThread, pid);
        pthread_detach(th);

        // 브로드캐스트/게임루프는 아래에서 수행. 단순 구현: accept 후에도 계속 루프
        // 메인 게임 루프와 브로드캐스트를 수행
        // 우리는 accept 후에도 계속 돌아야 하므로 break 하지는 않는다.

        // --- Start game loop here (single threaded loop) ---
        // To avoid starting multiple loops on each accept, we'll spawn a single "game loop" thread on first connection.
        static int gameloop_started = 0;
        if (!gameloop_started)
        {
            gameloop_started = 1;
            pthread_t glth;
            pthread_create(&glth, NULL, (void *(*)(void *))(void *)({
                void *__fn(void *_)
                {
                    (void)_; // unused
                    long long last = now_ms();
                    while (1)
                    {
                        long long cur = now_ms();
                        long long elapsed = cur - last;
                        if (elapsed < TICK_MS)
                        {
                            usleep((TICK_MS - elapsed) * 1000);
                            continue;
                        }
                        last = cur;

                        // 1) 게임 로직: 각 플레이어에 대해 ServerMoveChara 호출
                        for (int i = 0; i < MAX_CLIENT; i++)
                        {
                            if (client_connected[i])
                            {
                                ServerMoveChara(&players[i]);
                            }
                        }

                        // 2) 브로드캐스트: NetCharaPos 배열 생성 후 모든 연결된 클라이언트로 전송
                        NetCharaPos net[MAX_CLIENT];
                        for (int i = 0; i < MAX_CLIENT; i++)
                        {
                            net[i].x = players[i].point.x;
                            net[i].y = players[i].point.y;
                        }

                        pthread_mutex_lock(&clients_mutex);
                        for (int i = 0; i < MAX_CLIENT; i++)
                        {
                            if (client_connected[i] && client_sock[i] != -1)
                            {
                                if (writen(client_sock[i], net, sizeof(net)) != sizeof(net))
                                {
                                    // 오류시 연결 끊김으로 표시 (recv 스레드가 닫을 수도 있음)
                                    perror("writen to client");
                                    close(client_sock[i]);
                                    client_sock[i] = -1;
                                    client_connected[i] = 0;
                                }
                            }
                        }
                        pthread_mutex_unlock(&clients_mutex);

                    } // while
                    return NULL;
                }
                __fn;
            }),
                           NULL);
            pthread_detach(glth);
        }
    } // while accept

    close(sockfd);
    return 0;
}
