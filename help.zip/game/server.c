// server.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include "game.h"

#define SERVER_PORT 5000
#define MAX_CLIENT 4
#define MOVE_SPEED 4   // 필요하면 조절

int client_sock[MAX_CLIENT];

// 플레이어 정보 (id = 0~3)
CharaInfo players[MAX_CLIENT];

// 각 클라이언트 스레드
void* ClientThread(void* arg) {
    int id = *(int*)arg;
    free(arg);

    printf("Client %d connected.\n", id);

    while (1) {
        Keystts input;
        int r = read(client_sock[id], &input, sizeof(input));
        if (r <= 0) break;   // 연결 끊김

        // 입력 debug
        if (input.up || input.down || input.left || input.right) {
            printf("Client %d input: up=%d down=%d left=%d right=%d\n",
                id, input.up, input.down, input.left, input.right);
        }

        // 서버에서 직접 이동 계산
        if (input.up)    players[id].point.y -= MOVE_SPEED;
        if (input.down)  players[id].point.y += MOVE_SPEED;
        if (input.left)  players[id].point.x -= MOVE_SPEED;
        if (input.right) players[id].point.x += MOVE_SPEED;

        // 위치 전체 브로드캐스트
        for (int i = 0; i < MAX_CLIENT; i++) {
            if (client_sock[i] != -1) {
                ssize_t ret = write(client_sock[i], players, sizeof(players));
                if (ret < 0) {
                    perror("write");
                }
            }
        }
    }

    printf("Client %d disconnected.\n", id);
    close(client_sock[id]);
    client_sock[id] = -1;
    return NULL;
}

int main() {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(SERVER_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    bind(sockfd, (struct sockaddr*)&addr, sizeof(addr));
    listen(sockfd, MAX_CLIENT);

    // 초기화
    for (int i = 0; i < MAX_CLIENT; i++) {
        client_sock[i] = -1;
        players[i].point.x = 100 + i * 50;  // 각자 시작 위치
        players[i].point.y = 200;
    }

    printf("Server listening on port %d\n", SERVER_PORT);

    while (1) {
        int csock = accept(sockfd, NULL, NULL);

        // 빈 슬롯 찾기
        int id = -1;
        for (int i = 0; i < MAX_CLIENT; i++) {
            if (client_sock[i] == -1) {
                client_sock[i] = csock;
                id = i;
                break;
            }
        }

        // 슬롯 없으면 거절
        if (id == -1) {
            printf("No slot left, rejecting client.\n");
            close(csock);
            continue;
        }

        // 스레드 생성
        pthread_t th;
        int* pid = malloc(sizeof(int));
        *pid = id;
        pthread_create(&th, NULL, ClientThread, pid);
        pthread_detach(th);
    }

    return 0;
}
