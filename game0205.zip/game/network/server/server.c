// server/server.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#include "../constants.h"

static CLIENT clients[MAX_NUM_CLIENTS];
static int num_clients;
static int num_socks;
static fd_set mask;


void setup_server(int, u_short);
int control_requests();
void terminate_server();

static void send_data(int, void *, int);
static int receive_data(int, void *, int);
static void handle_error(char *);
static void handle_client_input(CONTAINER *data);

/*---------------------- サーバーを構築する関数 ----------------------*/
void setup_server(int num_cl, u_short port) {
    int rsock, sock = 0;
    struct sockaddr_in sv_addr, cl_addr;

    fprintf(stderr, "Server setup is started.\n");
    num_clients = num_cl;

    // ソケット生成
    rsock = socket(AF_INET, SOCK_STREAM, 0);
    if (rsock < 0) handle_error("socket()");
    fprintf(stderr, "socket() done.\n");

    // ソケット設定
    sv_addr.sin_family = AF_INET;
    sv_addr.sin_port = htons(port);
    sv_addr.sin_addr.s_addr = INADDR_ANY;

    int opt = 1;
    setsockopt(rsock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    if (bind(rsock, (struct sockaddr *)&sv_addr, sizeof(sv_addr)) != 0)
        handle_error("bind()");
    fprintf(stderr, "bind() done.\n");

    if (listen(rsock, num_clients) != 0)
        handle_error("listen()");
    fprintf(stderr, "listen() started.\n");

    int i, max_sock = 0;
    socklen_t len;
    char src[MAX_LEN_ADDR];

    // クライアント接続受け入れ
    // 클라이언트 접속 수락
    for (i = 0; i < num_clients; i++) {
        len = sizeof(cl_addr);
        sock = accept(rsock, (struct sockaddr *)&cl_addr, &len);
        if (sock < 0) handle_error("accept()");
        if (max_sock < sock) max_sock = sock;

        clients[i].cid = i;
        clients[i].sock = sock;
        clients[i].addr = cl_addr;

        // read() 대신 임시 이름 설정
        snprintf(clients[i].name, MAX_LEN_NAMES, "client%d", i);

        memset(src, 0, sizeof(src));
        inet_ntop(AF_INET, &(cl_addr.sin_addr), src, sizeof(src));

        fprintf(stderr, "Client %d accepted (name=%s, address=%s, port=%d)\n",
                i, clients[i].name, src, ntohs(cl_addr.sin_port));

        // 각 클라이언트에 ID 전송
        send_data(i, &clients[i].cid, sizeof(int));
    }

    close(rsock);

    num_socks = max_sock + 1;
    FD_ZERO(&mask);
    for (i = 0; i < num_clients; i++) {
        FD_SET(clients[i].sock, &mask);
    }

    fprintf(stderr, "Server setup done.\n");
}


/*---------------------- クライアントの要請を処理する関数 ----------------------*/
int control_requests() {
    fd_set read_flag = mask;

    if (select(num_socks, &read_flag, NULL, NULL, NULL) == -1)
        handle_error("select()");

    for (int i = 0; i < num_clients; i++) {
        if (FD_ISSET(clients[i].sock, &read_flag)) {
            CONTAINER data;
            memset(&data, 0, sizeof(data));

            int n = receive_data(i, &data, sizeof(data));
            if (n <= 0) {
                fprintf(stderr, "client[%d] disconnected.\n", i);
                close(clients[i].sock);
                FD_CLR(clients[i].sock, &mask);
                continue;
            }

            if (data.command != 0) {
                switch (data.command) {
                    case COMMAND_MOVE_UP:
                    case COMMAND_MOVE_DOWN:
                    case COMMAND_MOVE_LEFT:
                    case COMMAND_MOVE_RIGHT:
                        handle_client_input(&data);
                        break;
                    case COMMAND_POSITION_UPDATE:
                        send_data(BROADCAST, &data, sizeof(data));
                        break;
                    default:
                        fprintf(stderr, "unknown command %d\n", data.command);
                        break;
                }
            }
        }
    }

    return 1;
}




//====================== クライアント入力処理関数======================//
static void handle_client_input(CONTAINER *data) {
    if (!data) return;

    int id = data->cid;
    float speed = 10.0f;

    // 移動処理
    switch (data->command) {
        case COMMAND_MOVE_UP:
            data->y -= speed;
            break;
        case COMMAND_MOVE_DOWN:
            data->y += speed;
            break;
        case COMMAND_MOVE_LEFT:
            data->x -= speed;
            break;
        case COMMAND_MOVE_RIGHT:    
            data->x += speed;
            break;
        default:
            return; // 処理する命令でなければ無視
    }

    // 移動結果の出力(サーバーログ用)
    fprintf(stderr, "client[%d] move cmd=%d -> pos=(%.2f, %.2f)\n",
            id, data->command, data->x, data->y);

    // 位置更新コマンドでブロードキャスト
    CONTAINER send_data = {0};
    send_data.cid = id;
    send_data.command = COMMAND_POSITION_UPDATE;
    send_data.x = data->x;
    send_data.y = data->y;

    // 브로드캐스트 전에
    fprintf(stderr, "[DEBUG SERVER SEND] cid=%d pos=(%.2f,%.2f)\n",
            send_data.cid, send_data.x, send_data.y);

    for (int i = 0; i < num_clients; i++) {
        ssize_t w = write(clients[i].sock, &send_data, sizeof(CONTAINER));
        (void)w; // 使用しなくても良い(警告防止)
    }
}





/*---------------------- データ送信関数 ----------------------*/
static void send_data(int cid, void *data, int size) {
    if ((cid != BROADCAST) && (0 > cid || cid >= num_clients)) {
        fprintf(stderr, "send_data(): client id illegal.\n");
        return;
    }
    if ((data == NULL) || (size <= 0)) {
        fprintf(stderr, "send_data(): data illegal.\n");
        return;
    }

    if (cid == BROADCAST) {
        for (int i = 0; i < num_clients; i++) {
            if (write(clients[i].sock, data, size) < 0)
                handle_error("write()");
        }
    } else {
        if (write(clients[cid].sock, data, size) < 0)
            handle_error("write()");
    }
}


/*---------------------- データ受信関数 ----------------------*/
static int receive_data(int cid, void *data, int size) {
    if ((cid != BROADCAST) && (0 > cid || cid >= num_clients)) {
        fprintf(stderr, "receive_data(): client id illegal.\n");
        return -1;
    }
    if ((data == NULL) || (size <= 0)) {
        fprintf(stderr, "receive_data(): data illegal.\n");
        return -1;
    }
    return read(clients[cid].sock, data, size);
}


/*---------------------- エラー報告関数 ----------------------*/
static void handle_error(char *message) {
    perror(message);
    fprintf(stderr, "%d\n", errno);
    exit(1);
}


/*---------------------- サーバーを破棄する関数 ----------------------*/
void terminate_server(void) {
    for (int i = 0; i < num_clients; i++) {
        close(clients[i].sock);
    }
    fprintf(stderr, "All connections closed.\n");
    exit(0);
}
