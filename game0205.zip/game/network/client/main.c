// client/main.c
#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include "../constants.h"
#include "../../general/game.h"

extern void setup_client(char *, u_short);
extern int control_requests(void);   // client.c 에서 수정된 버전 사용
extern void terminate_client(void);
extern GameInfo gGames[CHARATYPE_NUM];
extern int my_id;
extern CharaInfo* gCharaHead;

// 전역 락 (client.c 와 공유)
SDL_mutex* stateMutex = NULL;

GameInfo *gGame = NULL;
SDL_bool gRunning = SDL_TRUE;

// 서버에서 받은 최신 좌표 (optional, 남겨둠)
typedef struct { float x, y; SDL_bool valid; } NetPos;
NetPos gServerPos[CHARATYPE_NUM];

//====================
// 좌표 보간 함수 (stateMutex 잠근 상태에서 호출해야 안전)
//====================
void LerpPosition(CharaInfo* ch, float targetX, float targetY, float alpha) {
    ch->point.x += (targetX - ch->point.x) * alpha;
    ch->point.y += (targetY - ch->point.y) * alpha;
    ch->rect.x = (int)ch->point.x;
    ch->rect.y = (int)ch->point.y;
}

//====================
// 애니메이션 전용 스레드
//====================
int AnimateThread(void* data) {
    while (gRunning) {
        SDL_LockMutex(stateMutex);
        for (int i = 0; i < CHARATYPE_NUM; i++)
            UpdateAnimation(&gGames[i], gGames[i].timeDelta);
        SDL_UnlockMutex(stateMutex);

        SDL_Delay(16); // 약 60Hz
    }
    return 0;
}

//====================
// 이동 처리 스레드 (MoveChara를 주기적으로 호출)
//====================
int MoveThread(void* data) {
    GameInfo* localGame = (GameInfo*)data;
    while (gRunning) {
        SDL_LockMutex(stateMutex);
        if (localGame && localGame->player)
            MoveChara(localGame->player, localGame);
        SDL_UnlockMutex(stateMutex);

        SDL_Delay(8); // 이동 업데이트는 더 자주 (약 120Hz) — CPU 상황에 맞게 조절
    }
    return 0;
}

//====================
// 네트워크(송수신) 스레드
// control_requests() 내부에서 gGames를 읽고 쓴다. 그 읽기/쓰기 구간은
// control_requests() 안에서 stateMutex로 보호되도록 client.c 쪽을 수정해놨음.
// 여기서는 주기적으로 control_requests() 호출.
//====================
int NetworkThread(void* arg) {
    (void)arg;
    while (gRunning) {
        // control_requests 내부에서 필요한 부분만 lock 하도록 구현되어 있음
        if (!control_requests()) {
            // 서버와 연결 끊김 등 처리
            gRunning = SDL_FALSE;
            break;
        }
        SDL_Delay(8); // 네트워크 처리 주기 (약 125Hz), 필요시 16ms로 낮춤
    }
    return 0;
}

//====================
// 메인
//====================
int main(int argc, char *argv[]) {
    char server_name[MAX_LEN_NAMES] = "localhost";
    u_short port = DEF_PORT;

    if (argc >= 2) sprintf(server_name, "%s", argv[1]);
    if (argc >= 3) port = (u_short)atoi(argv[2]);

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) < 0) {
        fprintf(stderr, "SDL_Init Error: %s\n", SDL_GetError());
        return 1;
    }

    setup_client(server_name, port);

    if (InitSystem("../../general/chara.data", "../../general/position.data", my_id) < 0) {
        PrintError("failed to initialize System");
        EndGame();
    }

    gGame = &gGames[my_id];
    if (!gGame) { fprintf(stderr, "Error: gGame is NULL\n"); SDL_Quit(); return 1; }

    if (InitWindow(gGame, "Game Window", "../../general/img/bg.png", WD_Width, WD_Height) < 0) {
        SDL_Quit();
        return 1;
    }

    // mutex 생성
    stateMutex = SDL_CreateMutex();

    // server pos 초기화 (선택)
    for (int i = 0; i < CHARATYPE_NUM; ++i) {
        gServerPos[i].x = 0.0f;
        gServerPos[i].y = 0.0f;
        gServerPos[i].valid = SDL_FALSE;
    }

    // 스레드 시작
    SDL_Thread* animThread = SDL_CreateThread(AnimateThread, "AnimateThread", NULL);
    SDL_Thread* moveThread = SDL_CreateThread(MoveThread, "MoveThread", gGame);
    SDL_Thread* netThread  = SDL_CreateThread(NetworkThread, "NetworkThread", NULL);

    Uint64 lastTick = SDL_GetPerformanceCounter();
    double freq = (double)SDL_GetPerformanceFrequency();

    while (gRunning) {
        Uint64 now = SDL_GetPerformanceCounter();
        float delta = (float)((now - lastTick) / freq);
        lastTick = now;

        // 입력만 메인 스레드에서 처리 (InputEvent은 내부적으로 이벤트 큐에서 꺼내므로 메인에서)
        gRunning = InputEvent(gGame);

        // 시간 갱신 (애니/이동이 읽을 수 있도록 전역에 저장)
        // Lock 없이 저장해도 되지만 다른 스레드에서 사용하지 않으므로 여기서만 씀
        gGame->timeDelta = delta;

        // 서버에서 받은 좌표로 보간 (gServerPos가 valid일 때만)
        SDL_LockMutex(stateMutex);
        for (CharaInfo* ch = gCharaHead; ch; ch = ch->next) {
            int cid = ch->type;
            if (cid >= 0 && cid < CHARATYPE_NUM && gServerPos[cid].valid) {
                LerpPosition(ch, gServerPos[cid].x, gServerPos[cid].y, 0.2f);
            }
        }
        // 렌더링 직전 상태는 stateMutex 로 보호하여 DrawGame이 일관된 상태를 읽게 함
        DrawGame(gGame);
        SDL_UnlockMutex(stateMutex);

        // 프레임 제한 (약 60fps)
        Uint64 frameTime = (SDL_GetPerformanceCounter() - now) * 1000.0 / freq;
        if (frameTime < 8) SDL_Delay(8 - (Uint32)frameTime);
    }

    // 종료: 스레드 기다림
    gRunning = SDL_FALSE;
    SDL_WaitThread(netThread, NULL);
    SDL_WaitThread(moveThread, NULL);
    SDL_WaitThread(animThread, NULL);

    if (stateMutex) SDL_DestroyMutex(stateMutex);
    CloseWindow(gGame);
    terminate_client();
    SDL_Quit();
    return 0;
}

// 종료
void EndGame(void) {
    gRunning = SDL_FALSE;
    SDL_Quit();
    exit(0);
}
