// client/client.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <arpa/inet.h>
#include <SDL2/SDL.h>
#include <fcntl.h>

#include "../constants.h"
#include "../../general/game.h"

int my_id;
static int sock;
static fd_set mask;

void setup_client(char *, u_short);
int control_requests();
void terminate_client();

static void send_data(void *, int);
static int receive_data(void *, int);
static void handle_error(char *msg);
static void handle_server_container(CONTAINER *c);
static void UpdateRemotePlayerPosition(int cid, float x, float y);

// main.c 에서 정의된 mutex를 외부에서 사용
extern SDL_mutex* stateMutex;

extern GameInfo gGames[CHARATYPE_NUM];
extern CharaInfo* gCharaHead;

//********** クライアント初期化**********//
void setup_client(char *server_name, u_short port) {
    struct hostent *server;
    struct sockaddr_in sv_addr;

    fprintf(stderr, "Connecting to server %s (port %d)\n", server_name, port);

    if ((server = gethostbyname(server_name)) == NULL)
        handle_error("gethostbyname()");

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0)   
        handle_error("socket()");

    sv_addr.sin_family = AF_INET;
    sv_addr.sin_port = htons(port);
    sv_addr.sin_addr.s_addr = *(u_int *)server->h_addr_list[0];

    if (connect(sock, (struct sockaddr *)&sv_addr, sizeof(sv_addr)) != 0)
        handle_error("connect()");

    fcntl(sock, F_SETFL, O_NONBLOCK);

    // 名前転送
    char user_name[MAX_LEN_NAMES];
    fprintf(stderr, "Input your name: ");
    if (fgets(user_name, sizeof(user_name), stdin) == NULL)
        handle_error("fgets()");
    user_name[strlen(user_name) - 1] = '\0';
    send_data(user_name, MAX_LEN_NAMES);

    // サーバからID受信
    receive_data(&my_id, sizeof(int));
    fprintf(stderr, "Connected. Your ID = %d\n", my_id);

    FD_ZERO(&mask);
    FD_SET(sock, &mask);
}
//********** クライアント初期化 **********//


int control_requests(void) {
    fd_set read_flag = mask;
    struct timeval timeout = {0, 10000}; // 10ms
    static Uint32 lastSendTime = 0;

    if (select(sock + 1, &read_flag, NULL, NULL, &timeout) == -1) {
        perror("select()");
        return 0;
    }

    if (FD_ISSET(sock, &read_flag)) {
        CONTAINER data;
        memset(&data, 0, sizeof(CONTAINER));
        int r = receive_data(&data, sizeof(data));

        if (r <= 0) {
            fprintf(stderr, "server closed or read error\n");
            return 0;
        }

        // 수신 처리: 상태 변경을 하므로 stateMutex 로 보호
        if (stateMutex) SDL_LockMutex(stateMutex);
        handle_server_container(&data);
        if (stateMutex) SDL_UnlockMutex(stateMutex);
    }

    // 자기 입력/위치 읽기: 상태를 읽으므로 stateMutex 로 최소 영역 보호
    GameInfo *myGame = &gGames[my_id];
    // 복사해서 락을 최소화
    if (stateMutex) SDL_LockMutex(stateMutex);
   
    SDL_bool up = myGame->input.up;
    SDL_bool down = myGame->input.down;
    SDL_bool left = myGame->input.left;
    SDL_bool right = myGame->input.right;
    float px = 0.0f, py = 0.0f;
    if (myGame->player) {
        px = myGame->player->point.x;
        py = myGame->player->point.y;
    }
    if (stateMutex) SDL_UnlockMutex(stateMutex);

    CONTAINER move_data = {0};
    move_data.cid = my_id;

    if (up) move_data.command = COMMAND_MOVE_UP;
    else if (down) move_data.command = COMMAND_MOVE_DOWN;
    else if (left) move_data.command = COMMAND_MOVE_LEFT;
    else if (right) move_data.command = COMMAND_MOVE_RIGHT;
    else move_data.command = 0;

    move_data.x = px;
    move_data.y = py;

    if (move_data.command != 0) {
        Uint32 now = SDL_GetTicks();
        if (now - lastSendTime > 10) { 
            send_data(&move_data, sizeof(CONTAINER));
            fprintf(stderr, "[DEBUG SEND] cid=%d cmd=%d pos=(%.2f,%.2f)\n",
                move_data.cid, move_data.command, move_data.x, move_data.y);
            lastSendTime = now;
        }
    }

    return 1;
}

static void handle_server_container(CONTAINER *c) {
    if (!c) return;

    // サーバーから何の命令も送っていない場合は無視
    if (c->command == 0) return;

    switch (c->command) {
        case COMMAND_MOVE_UP:
        case COMMAND_MOVE_DOWN:
        case COMMAND_MOVE_LEFT:
        case COMMAND_MOVE_RIGHT:
        case COMMAND_POSITION_UPDATE:
            UpdateRemotePlayerPosition(c->cid, c->x, c->y);

            fprintf(stderr, "[DEBUG RECV] cid=%d cmd=%d pos=(%.2f,%.2f)\n",
            c->cid, c->command, c->x, c->y);
            break;

        case COMMAND_INTERACT:
            fprintf(stderr, "Server: player %d interact\n", c->cid);
            break;

        default:
            fprintf(stderr, "handle_server_container(): unknown command %d\n", c->command);
            break;
    }
}

static void UpdateRemotePlayerPosition(int cid, float x, float y) {
    if (cid < 0 || cid >= CHARATYPE_NUM) return;

    // 먼저 gGames[cid].player 사용
    GameInfo *g = &gGames[cid];
    CharaInfo *ch = g->player;

    // 없으면 리스트에서 찾는다
    if (!ch) {
        for (CharaInfo *iter = gCharaHead; iter; iter = iter->next) {
            if (iter->type == (CT_PLAYER0 + cid)) {
                ch = iter;
                g->player = ch; // 캐시
                break;
            }
        }
    }

    if (ch) {
        // stateMutex 로 보호된 상태에서 호출되어야 함
        ch->point.x = x;
        ch->point.y = y;
        ch->rect.x = (int)x;
        ch->rect.y = (int)y;

        fprintf(stderr, "[DEBUG UPDATE] cid=%d new_pos=(%.2f,%.2f)\n",
            cid, x, y);
    } else {
        fprintf(stderr, "UpdateRemotePlayerPosition: couldn't find player cid=%d\n", cid);
    }
}

//自分のキャラクタの位置情報を送る (다른 곳에서 호출 가능)
void send_player_position() {
    GameInfo *myGame = &gGames[my_id];
    if (!myGame->player) return;

    CONTAINER data = {0};
    data.command = COMMAND_POSITION_UPDATE;
    data.cid = my_id;
    data.x = myGame->player->point.x;
    data.y = myGame->player->point.y;

    send_data(&data, sizeof(CONTAINER));
}

static void send_data(void *data, int size) {
    if (!data || size <= 0) return;
    int n = write(sock, data, size);
    if (n == -1 && !(errno == EAGAIN || errno == EWOULDBLOCK))
        handle_error("write()");
}

static int receive_data(void *data, int size) {
    int r = read(sock, data, size);
    if (r == -1 && (errno == EAGAIN || errno == EWOULDBLOCK))
        return 0; // 읽을 데이터 없음
    return r;
}

static void handle_error(char *msg) {
    perror(msg);
    exit(1);
}

void terminate_client() {
    fprintf(stderr, "Connection closed.\n");
    close(sock);
    exit(0);
}
