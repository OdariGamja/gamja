// system_server.c
#include "server_system.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <sys/time.h>

//初期化
int InitServerChara(const char* position_data_file, CharaInfo players[], int max_players)
{
    int ret = 0;
    SevergCharaHead = NULL;

    FILE* fp = fopen(position_data_file, "r");
    if (!fp) return PrintError("failed to open position data file.");

    char linebuf[MAX_LINEBUF];

    while (fgets(linebuf, MAX_LINEBUF, fp)) {
        if (linebuf[0] == '#') continue;

        unsigned int type;
        float px, py;
        int rx, ry, rw, rh;
         

        if (7 != sscanf(linebuf, "%u%f%f%d%d%d%d", &type, &px, &py, &rx, &ry, &rw, &rh)) {
            PrintError("failed to parse line in position data");
            continue;
        }

        if (type >= CT_PLAYER0 && type < CT_PLAYER0 + max_players) {
            // プレイヤーの初期化
            int i = type - CT_PLAYER0;
         
            players[i].type = type;
            players[i].point.x = px;
            players[i].point.y = py;
            players[i].rect.x = (int)px;
            players[i].rect.y = 150 + (int)py;
            players[i].rect.w = rw;
            players[i].rect.h = rh;
            players[i].Baserect.w = rw;
            players[i].Baserect.h = rh;
            players[i].playerdir = Down;
            players[i].stts = CS_Normal;
            players[i].movestts = ANI_Stop;
            players[i].hold = 0;
            players[i].holder = NULL;
            players[i].holdTarget = NULL;
            players[i].hp = 3;
            players[i].inputcount = 0;
            players[i].whoholder = 0;

            memset(&players[i].input, 0, sizeof(players[i].input));
            UpdateAttackRects(&players[i]);

            // linked list に追加
            players[i].next = SevergCharaHead;
            SevergCharaHead = &players[i];

        } else {
            // その他のNPCなど
            CharaInfo* ch = malloc(sizeof(CharaInfo));
            if (!ch) { ret = PrintError("failed to allocate NPC"); break; }

            ch->type = type;
            ch->point.x = px;
            ch->point.y = py;
            ch->rect.x = (int)px;
            ch->rect.y = (int)py;
            ch->rect.w = rw;
            ch->rect.h = rh;
            if(ch->type == CT_Vendor){
            ch->Vendor_rect.x = ch -> point.x - 30; //自販機のゴール矩形
            ch->Vendor_rect.y = ch-> point.y;
            ch->Vendor_rect.w = ch-> rect.w + 60;
            ch->Vendor_rect.h = ch -> rect.h + 245; //コイン投げて入れるとき違和感合ったらここ変えて
            }
            if(ch->type == CT_ATM){
                ch->movestts= ANI_ATM_LIGHTON_DEFALT;
            }
            ch->Baserect.w = rw;
            ch->Baserect.h = rh;
            ch->stts = CS_Normal;
            if (ch->type == CT_COIN && ch->point.x < -1000) {

                    ch->stts = CS_Disable;   
                }

            ch->vel.x = ch->vel.y = 0;
            ch->ani.x = 0;
            ch->entity = NULL; // サーバーでは画像不要
            ch->holder = NULL;
            ch->holdTarget = NULL;
            ch->coinRespawnTime = 0;
            ch->whoholder =0;
            ch->hp=0;

            if(ch->type == CT_MOUSE){
                ch->hp=5;
            }

            if (ch->type == CT_COIN) {
    printf("COIN init x=%f stts=%d\n", ch->point.x, ch->stts);
}

            

            // linked list に追加
            ch->next = SevergCharaHead;
            SevergCharaHead = ch;
        }
    }

    fclose(fp);
    return ret;
}


//y軸値によるスケール値をrectにも適用
void UpdateScaleServer(CharaInfo* ch)
{
    float yMin = 500.0f;
    float yMax = 1200.0f;
    float scaleMin = 0.5f;
    float scaleMax = 1.8f;

    float py = ch->point.y + ch->rect.h / 2;

    // ★ 여기 중요 : 560 이하에서는 고정
    if (py < 560.0f)
        py = 560.0f;

    float t = (py - yMin) / (yMax - yMin);
    if (t < 0) t = 0;
    if (t > 1) t = 1;

    float scale = scaleMax - t * (scaleMax - scaleMin);

    ch->rect.w = (int)(ch->Baserect.w / scale);
    ch->rect.h = (int)(ch->Baserect.h / scale);
}

void AddScore(CharaInfo* ch, int event)
{
    if (!ch){
       return; 
    } 

    switch(event){
        case THROWtoVendor:     // 자판기에 던짐
            ch->score += 100;
            printf("Score Up! Player %d → score=%d\n",
                ch->type - CT_PLAYER0, ch->score);
            

            break;
    }
}

CharaInfo* SevergCharaHead = NULL;
void UpdateAttackRects(CharaInfo* ch)//攻撃判定の範囲更新、色々合って初期化も兼ねてる
{
    int w = ch->rect.w;
    int h = ch->rect.h;
    int margin = 50; // 여유치, 원하는 값으로 조절 가능

    // 上
    ch->attackrectUp.x = ch->rect.x - margin;
    ch->attackrectUp.y = ch->rect.y - h - margin;
    ch->attackrectUp.w = w + 2*margin;
    ch->attackrectUp.h = h + margin;

    // 下
    ch->attackrectDown.x = ch->rect.x - margin;
    ch->attackrectDown.y = ch->rect.y + ch->rect.h;
    ch->attackrectDown.w = w + 2*margin;
    ch->attackrectDown.h = h + margin;

    // 左
    ch->attackrectLeft.x = ch->rect.x - w - margin;
    ch->attackrectLeft.y = ch->rect.y - margin;
    ch->attackrectLeft.w = w + margin;
    ch->attackrectLeft.h = h + 2*margin;

    // 右
    ch->attackrectRight.x = ch->rect.x + ch->rect.w;
    ch->attackrectRight.y = ch->rect.y - margin;
    ch->attackrectRight.w = w + margin;
    ch->attackrectRight.h = h + 2*margin;
}


//========================
// 物体を持ち上げる処理
//========================
void LiftObject(CharaInfo* ch, CharaInfo* obj)
{
    if (!ch || !obj) return;

    // 持ち上げ状態に変更
    obj->stts = CS_Holded;
    obj->InSubway = SDL_FALSE;
    // 持ち主を記録
    obj->holder = ch;
    ch->holdTarget =obj;
    


    // プレイヤーの位置
    float px = ch->point.x;
    float py = ch->point.y;
    int   pw = ch->rect.w;
    

    // 物体のサイズ
    int ow = obj->rect.w;
    int oh = obj->rect.h;

        // 持ち上げ量を切り替える
    float liftMul = 5.0f;

    // 対象がプレイヤーなら、もっと上に
    if (obj->type >= CT_PLAYER0 && obj->type <= CT_PLAYER3) {
        liftMul = 10.0f;   
    }


    // きれいに中心合わせ
    float ox = 20 + (px + (pw - ow) / 2.0f);
    float oy = py + (liftMul * oh) + 100;    

    // 位置を更新   
    obj->point.x = ox;
    obj->point.y = oy;
    obj->rect.x  = (int)ox;
    obj->rect.y  = (int)oy;

    ch->hold = 1;     // 「持っている」状態に

    if(ch->type == CT_PLAYER0){
        obj->whoholder = 1;//0使うの怖いから一個ずつずらしてる
    }
    if(ch->type == CT_PLAYER1){
        obj->whoholder = 2;
    }
    if(ch->type == CT_PLAYER2){
        obj->whoholder = 3;
    }
    if(ch->type == CT_PLAYER3){
        obj->whoholder = 4;
    }

    if (ch->holdTarget) {
    printf("holdTarget type=%d stts=%d\n",
           ch->holdTarget->type,
           ch->holdTarget->stts);} 
    if (obj->holder) {
    printf("holder type=%d stts=%d\n",
           obj->holder->type,
           obj->holder->stts);
}
}



void UpdateKnockdown(CharaInfo* ch)
{
    if (!ch || ch->stts != CS_Knockdown) return;

    long long now = now_ms();
    long long passed = now - ch->knockLastMs;
    ch->knockLastMs = now;

    ch->knockRemainMs -= passed;
    if (ch->knockRemainMs > 0) return;

    // ===== 復帰 =====
    ch->hold = 0;
    ch->holdTarget = NULL;
    ch->holder = NULL;

    ch->stts = CS_Normal;
    ch->hp = 3;
    ch->knockRemainMs = 0;

    printf("PLAYER %d RECOVERED\n", ch->type);
}



void SpawnCoin(CharaInfo* atm, CharaInfo* ch)
{   printf("[ATM] SpawnCoin called\n");
    for (CharaInfo* coin = SevergCharaHead; coin; coin = coin->next) {
          
            printf(" check coin type=%d stts=%d x=%.1f\n",
               coin->type, coin->stts, coin->point.x);
        if (coin->type != CT_COIN)
            continue;

        if (coin->stts != CS_Disable)
            continue;
        printf(" >>> FOUND DISABLED COIN <<<\n");

        // ---- コイン復活 ----
        coin->stts = CS_Normal;

        // ATMの上に出す
        coin->point.x = atm->point.x + rand() % 40 - 20;
        coin->point.y = atm->point.y - coin->rect.h - 10;

        coin->rect.x = (int)coin->point.x;
        coin->rect.y = (int)coin->point.y;

        // ---- 一瞬持たせる ----
        LiftObject(atm, coin);

        // ---- すぐ投げる ----
          atm-> playerdir= ch->playerdir;
        ThrowObject(atm);

        printf("[ATM] Coin spawned & thrown\n");
        break; // 1枚だけ
    }
}



void UpdateATM(CharaInfo *atm)
{
    if (!atm || atm->type != CT_ATM)
        return;

    long long now = now_ms();

    // 振動終了
    if (atm->VibrateEnd > 0 && now >= atm->VibrateEnd) {
        atm->VibrateEnd = 0;
        atm->movestts = ANI_ATM_LIGHTOFF_DEFALT;
    }

    // 5秒経過 → 再び点灯
    if (atm->AtmTime > 0 && now >= atm->AtmTime) {
        atm->AtmTime = 0;
        atm->movestts = ANI_ATM_LIGHTON_DEFALT;
        printf("ATM LIGHT ON (cooldown end)\n");
    }
}



void UpdateVendor(CharaInfo* ch)
{
    if (ch->animTimer > 0) {
        ch->animTimer--;
        if (ch->animTimer == 0) {
            ch->movestts = ANI_Stop;
        }
    }
}
void VendorPump(CharaInfo* vendor)//アニメーション用
{
    vendor->movestts = ANI_VENDER_PUMP;
    vendor->animTimer = 20;   // 뽈롱 지속 프레임 (조절)
}


void HitATM(CharaInfo *atm, CharaInfo *attacker)
{
    if (!atm || atm->type != CT_ATM)
        return;

    long long now = now_ms();

    // 振動は常に可能
    atm->movestts   = ANI_ATM_LIGHTOFF_VIBRATE;
    atm->VibrateEnd = now + 300;   // 0.3秒振動

    // クールタイムの始まり 初めて殴ったときだけ
    if (atm->AtmTime == 0) {    
        atm->AtmTime = now + 5000;
        printf("ATM HIT (start cooldown)\n");
        SpawnCoin(atm, attacker);
    } else {
        printf("ATM HIT (vibrate only)\n");
    }
}


//========================
// 持ち上げ解除処理
//========================
void ReleaseHold(CharaInfo* holder, CharaInfo* obj)
{
    if (!holder || !obj) return;
if (obj->type >= CT_PLAYER0 && obj->type <= CT_PLAYER3) {
        if(obj->inputcount >= 10){
            obj->stts = CS_Normal;
        }else {
            obj->stts = CS_Knockdown;
            obj->knockLastMs = now_ms(); 
            printf("[KNOCKDOWN RESUME] remain=%lldms\n", obj->knockRemainMs);
        }
       
    } else {
        obj->stts = CS_Normal;
    }
    // --- obj 側 ---
   
    obj->holder = NULL;
    obj->inputcount = 0;
    obj->hp = 3;
    obj->whoholder = 0;

    // 位置を少し下に戻す（めり込み防止）
    obj->point.y = holder->point.y + holder->rect.h;
    obj->rect.y  = (int)obj->point.y;

    // --- holder 側 ---
    holder->hold = 0;
    holder->holdTarget = NULL;
    


    printf("[ReleaseHold] holder=%d obj=%d\n",
           holder->type, obj->type);
}




void Attack(CharaInfo* ch) //攻撃処理　
{
    SDL_Rect* atk = NULL;
    if (ch->playerdir == Up)    atk = &ch->attackrectUp;
    if (ch->playerdir == Down)  atk = &ch->attackrectDown;
    if (ch->playerdir == Left)  atk = &ch->attackrectLeft;
    if (ch->playerdir == Right) atk = &ch->attackrectRight;

    if (!atk) return;
    

    const float knockbackPower = 100.0f;   // ← ノックバック量

    for (CharaInfo* target = SevergCharaHead; target; target = target->next) {
        if(ch->hold==0){//持ってないとき

        if (target == ch) continue;
       

        if (target->type == CT_COIN){
            if (target->stts == CS_Normal)
                {
            if (SDL_HasIntersection(atk, &target->rect)) {
               LiftObject(ch, target);
               printf("LIFTUP");
            }
            }
            }else if (target->type == CT_ATM){//ATMを殴る
                if (target->stts == CS_Normal)
                {
                    // target->stts = CS_AtmOFF;
                    if (SDL_HasIntersection(atk, &target->rect))
                    {
                        HitATM(target, ch);

                        printf("Hit ATM!!");
                        return;
                    }
                }
            }else if (target->type >= CT_PLAYER0 && target->type <= CT_PLAYER3)//playerを殴る
                {  
                   
                    if (target->stts == CS_Knockdown) {
                        if (SDL_HasIntersection(atk, &target->rect)) {

                            if (ch->hold == 0 && target->holder == NULL) {

                                // ===== Knockdown時間を一時停止 =====
                                long long now = now_ms();
                                long long passed = now - target->knockLastMs;
                                target->knockRemainMs -= passed;
                                if (target->knockRemainMs < 0)
                                    target->knockRemainMs = 0;

                                printf("[KNOCKDOWN PAUSE] target=%d remain=%lldms\n",
                                    target->type, target->knockRemainMs);

                                LiftObject(ch, target);
                            }

                            return;
                        }
                    }



                    if (target->stts == CS_Normal) {
                        if (SDL_HasIntersection(atk, &target->rect)) {
                            if (target->hp <= 0) continue;
                            target->hp -= 1;
                            printf("You Hit player %d !!! target hp %d\n" , target->type , target->hp);
                            if (target->hp <= 0) {
                                target->hp = 0;

                            if (target->hold && target->holdTarget) {
                                ReleaseHold(target, target->holdTarget);
                            }
                            if (target->holder) {
                                ReleaseHold(target->holder, target);
                            }
                                
                                target->stts = CS_Knockdown;
                               
                                target->knockRemainMs = 5000;      // 5秒
                                target->knockLastMs   = now_ms();  
                                

                                printf("%d Knockdown!  target stts %d\n", target->type , target -> stts);
                                continue;  
                            }
                        }
                    }
                }
            else if (target->type == CT_MOUSE) {//ネズミへを殴る
                if (target->stts == CS_Normal){
                    if (SDL_HasIntersection(atk, &target->rect)) {

                        printf("Attack hit! target=%d\n", target->type);

                        // ダメージ
                        target->hp -= 1;

                        //ノックバック
                        switch (ch->playerdir) {
                        case Up:
                            target->point.y -= knockbackPower;
                            break;
                        case Down:
                            target->point.y += knockbackPower;
                            break;
                        case Left:
                            target->point.x -= knockbackPower;
                            break;
                        case Right:
                            target->point.x += knockbackPower;
                            break;
                        }

                        // rect 更新（プレイヤー以外はそのまま）
                        target->rect.x = (int)target->point.x;
                        target->rect.y = (int)target->point.y;
                        UpdateAttackRects(target);

                        // 倒されたかチェック
                        if (target->hp <= 0) {
                            target->stts = CS_Disable;
                            printf("Enemy %d defeated!\n", target->type);
                        }
                    }
                }
            }
        }

    if(ch->type == CT_ATM){
        printf("ATM stts at EndOfAttack %d\n", ch -> stts);  
    }
    
    
    }
}


//ここに動かないオブジェクトを入れてください
static SDL_bool IsStaticObject(CharaInfo* ch)
{
    return (ch->type == CT_Vendor || ch->type == CT_ATM);
}




// --- CollisionPlayer の修正 ---
SDL_bool CollisionPlayer(CharaInfo* a, CharaInfo* b)
{
    if (a->stts == CS_Disable || b->stts == CS_Disable) return SDL_FALSE;

    if (a->stts == CS_Holded || b->stts == CS_Holded)
    return SDL_FALSE;

    int aStatic = IsStaticObject(a);
    int bStatic = IsStaticObject(b);



    SDL_Rect ra = a->rect;
    SDL_Rect rb = b->rect;
    SDL_Rect ir;
    if (!SDL_IntersectRect(&ra, &rb, &ir)) return SDL_FALSE;
    int overlapW = ir.w;
    int overlapH = ir.h;

    // ← ここを point を使うのではなく rect を基準にする
    float ax = (float)a->rect.x + a->rect.w / 2.0f;
    float ay = (float)a->rect.y + a->rect.h / 2.0f;
    float bx = (float)b->rect.x + b->rect.w / 2.0f;
    float by = (float)b->rect.y + b->rect.h / 2.0f;

    float dx = ax - bx;
    float dy = ay - by;

 if (overlapW < overlapH) {
    float push = overlapW;

    // a が動ける
    if (!aStatic && bStatic) {
        a->point.x += (dx > 0 ? push : -push);
    }
    // b が動ける
    else if (aStatic && !bStatic) {
        b->point.x -= (dx > 0 ? push : -push);
    }
    // 両方動ける
    else if (!aStatic && !bStatic) {
        float half = push / 2.0f;
        a->point.x += (dx > 0 ? half : -half);
        b->point.x -= (dx > 0 ? half : -half);
    }
}
else {
    float push = overlapH;

    if (!aStatic && bStatic) {
        a->point.y += (dy > 0 ? push : -push);
    }
    else if (aStatic && !bStatic) {
        b->point.y -= (dy > 0 ? push : -push);
    }
    else if (!aStatic && !bStatic) {
        float half = push / 2.0f;
        a->point.y += (dy > 0 ? half : -half);
        b->point.y -= (dy > 0 ? half : -half);
    }
}


    // 移動制限（そのまま）
    if (a->point.x < 0) a->point.x = 0;
    if (a->point.y < 0) a->point.y = 0;
    
    if (a->point.x + a->rect.w > MAP_Width) a->point.x = MAP_Width - a->rect.w;
    if (a->point.y + a->rect.h > MAP_Height) a->point.y = MAP_Height - a->rect.h;

    if (b->point.x < 0) b->point.x = 0;
    if (b->point.y < 0) b->point.y = 0;
    if (b->point.x + b->rect.w > MAP_Width) b->point.x = MAP_Width - b->rect.w;
    if (b->point.y + b->rect.h > MAP_Height) b->point.y = MAP_Height - b->rect.h;

    // rect の更新
    if (a->type >= CT_PLAYER0 && a->type <= CT_PLAYER3) {
        a->rect.x =  (int)a->point.x;
        a->rect.y = 150 + (int)a->point.y;  // プレイヤー +150
    }
    else if (a->type == CT_COIN) {
        a->rect.x = (int)a->point.x;
        a->rect.y = 48 + (int)a->point.y;   // coin +48
    }
    else if(a->type == CT_Vendor){
        a->rect.x = (int)a->point.x;
        a->rect.y = (int)a->point.y;
        a->rect.w = 80 + (int)a->rect.w;
        
    } else if(a->type == CT_ATM){
        a->rect.x = (int)a->point.x -50;
        a->rect.y =  (int)a->point.y;
        
    }
    else {
        a->rect.x = (int)a->point.x;
        a->rect.y = (int)a->point.y;        // その他
    }

    if (b->type >= CT_PLAYER0 && b->type <= CT_PLAYER3) {
        b->rect.x = (int)b->point.x;
        b->rect.y = 150 + (int)b->point.y;
    }
    else if (b->type == CT_COIN) {
        b->rect.x = (int)b->point.x;
        b->rect.y = 48 + (int)b->point.y;
    }
     else if(b->type == CT_Vendor){
        b->rect.x = (int)b->point.x;
        b->rect.y = (int)b->point.y;
        a->rect.w = 80 + (int)a->rect.w;
        
    } else if(b->type == CT_ATM){
        b->rect.x = (int)b->point.x -50;
        b->rect.y = (int)b->point.y;
        
    }
    else {
        b->rect.x = (int)b->point.x;
        b->rect.y = (int)b->point.y;
    }

    UpdateAttackRects(a);
    UpdateAttackRects(b);

    return SDL_TRUE;
}

//a当たり判定ができるかを判別する関数
static SDL_bool ObjectSorting(const CharaInfo* ch)
{
    if (!ch) return SDL_FALSE;

    // 完全除外
    if (ch->stts == CS_Disable)
        return SDL_FALSE;

    // 掴まれている間は物理衝突しない
    if (ch->stts == CS_Holded)
        return SDL_FALSE;

    // ATM は常に当たる
    if (ch->type == CT_ATM)
        return SDL_TRUE;

    // プレイヤー
    if (ch->type >= CT_PLAYER0 && ch->type <= CT_PLAYER3) {
        return (ch->stts == CS_Normal ||
                ch->stts == CS_Knockdown);
    }

    // その他
    return (ch->stts == CS_Normal);
}




//当たり判定
SDL_bool Collision(CharaInfo* a, CharaInfo* b)
{   
     if (!ObjectSorting(a) || !ObjectSorting(b))
        return SDL_FALSE;


    SDL_Rect ir;
    if (!SDL_IntersectRect(&a->rect, &b->rect, &ir))
        return SDL_FALSE;

    int aIsPlayer = (a->type >= CT_PLAYER0 && a->type <= CT_PLAYER3);
    int bIsPlayer = (b->type >= CT_PLAYER0 && b->type <= CT_PLAYER3);
    int aIsCoin   = (a->type == CT_COIN);
    int bIsCoin   = (b->type == CT_COIN);
    int aIsMouse  = (a->type == CT_MOUSE);
    int bIsMouse  = (b->type == CT_MOUSE);
    int aIsVendor = (a->type == CT_Vendor);
    int bIsVendor = (b->type == CT_Vendor);
    int aIsATM = (a->type == CT_ATM);
    int bIsATM = (b->type == CT_ATM);


    // --- プレイヤー同士 ---
    if (aIsPlayer && bIsPlayer) {
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }

    // --- プレイヤー & コイン ---
    if ((aIsPlayer && bIsCoin) || (bIsPlayer && aIsCoin)) {
        CollisionPlayer(a, b);
        if(b->type== CT_COIN)
        b->holder = a; //bがコインでaがプレイヤーのとき
        if(a->type== CT_COIN)
        a->holder = b; //aがコインでbがプレイヤーのとき

        return SDL_TRUE;
    }

    // --- プレイヤー & ねずみ ---
    if (aIsPlayer && bIsMouse) {
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }
    if (bIsPlayer && aIsMouse) {
        CollisionPlayer(b, a);
        return SDL_TRUE;
    }

    // --- コイン同士 ---
    if (aIsCoin && bIsCoin) {
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }

    // --- ねずみ同士 ---
    if (aIsMouse && bIsMouse) {
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }

    // --- コイン & ねずみ ---
    if ((aIsCoin && bIsMouse) || (bIsCoin && aIsMouse)) {
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }

   // 自販機とコイン
    if (bIsVendor && aIsCoin) {

        // スコア加算（holder がいる時だけ）
        if (a->holder){
            AddScore(a->holder, THROWtoVendor);
            VendorPump(b);
        }
            

        // ★ Normal コインなら押し返す
        if (a->stts == CS_Normal) {
            CollisionPlayer(a, b);
        }

        // ★ 最後に消す
        a->stts = CS_Disable;
        return SDL_TRUE;
    }

    if (aIsVendor && bIsCoin) {

        if (b->holder){
            AddScore(b->holder, THROWtoVendor);
            VendorPump(a);
        }
            

        if (b->stts == CS_Normal) {
            CollisionPlayer(a, b);
        }

        b->stts = CS_Disable;
        return SDL_TRUE;
    }

     //自販機とプレイヤー
    if((aIsVendor && bIsPlayer) || (bIsVendor && aIsPlayer)){
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }


    if (aIsATM || bIsATM) {
        // 純粋に物理衝突のみ
        CollisionPlayer(a, b);
        return SDL_TRUE;
    }


    // --- ねずみ & 自販機 ---
if ((aIsMouse && bIsVendor) || (bIsMouse && aIsVendor)) {
    CollisionPlayer(a, b);
    return SDL_TRUE;
}

// --- ねずみ & ATM ---
if ((aIsMouse && bIsATM) || (bIsMouse && aIsATM)) {
    CollisionPlayer(a, b);
    return SDL_TRUE;
}


    return SDL_FALSE;
}


//=================================================
// 空中のキャラクターへの動作
//=================================================
SDL_bool FlyCollison(CharaInfo* a, CharaInfo* b)
{
    CharaInfo* coin   = NULL;
    CharaInfo* vendor = NULL;

    // Fly中コイン + Vendor 判定
    if (a->type == CT_COIN && a->stts == CS_Fly && b->type == CT_Vendor) {
        coin = a;
        vendor = b;
    }
    else if (b->type == CT_COIN && b->stts == CS_Fly && a->type == CT_Vendor) {
        coin = b;
        vendor = a;
    }
    else {
        return SDL_FALSE;
    }

    // 衝突判定
    SDL_Rect ir;
    if (SDL_IntersectRect(&coin->rect, &vendor->Vendor_rect, &ir)){
        printf("Add Score in FlyCollision\n");
        AddScore(coin->holder, THROWtoVendor);
        VendorPump(vendor);//アニメーション用

        coin->stts = CS_Disable;
        coin->holder = NULL; 
        return SDL_TRUE;
    }else{
        return SDL_FALSE;
    }
        

    // holder 체크 (디버그용)
    if (coin->holder == NULL) {
        printf("ERROR: coin has no holder (FlyCollision)\n");
        coin->stts = CS_Disable;
        return SDL_TRUE;
    }



    
    return SDL_TRUE;
}


    /*if(a->stts == CS_Fly || b->stts == CS_Fly){

        int aIsCoin   = (a->type == CT_COIN);
        int bIsCoin   = (b->type == CT_COIN);
        int aIsVendor = (a->type == CT_Vendor);
        int bIsVendor = (b->type == CT_Vendor);
        
        SDL_Rect ir;
        if(a->type == CT_Vendor){
        if (!SDL_IntersectRect(&a->Vendor_rect, &b->rect, &ir))
        return SDL_FALSE;
        }
        else if(b->type == CT_Vendor){
        if (!SDL_IntersectRect(&a->rect, &b->Vendor_rect, &ir))
        return SDL_FALSE;
        }
        else if (!SDL_IntersectRect(&a->rect, &b->rect, &ir))
        return SDL_FALSE;



    //自販機とコイン
    if(aIsVendor && bIsCoin){
        AddScore(b->holder, THROWtoVendor);
        b->stts = CS_Disable;
        return SDL_TRUE; 
    }
    if(bIsVendor && aIsCoin){
        AddScore(a->holder, THROWtoVendor);
        a->stts = CS_Disable;
        return SDL_TRUE;
    }


        }

       return SDL_FALSE;
}*/





// 投げの物理パラメータ（調整可）

void ThrowObject(CharaInfo* ch)
{
    if (!ch || ch->hold != 1 || !ch->holdTarget) return;

    CharaInfo* obj = ch->holdTarget;

    float vx = 0.0f;
    float vy = 0.0f;

    // ---- 初速設定 ----
    switch(ch->playerdir){
        case Up:
            vy = -THROW_POWER_UP;  // 위로 던지기
            vx = 0;
            break;
        case Down:
            vx= THROW_POWER_DOWN; // 아래로 던지기
            vx = 0;
            break;
        case Left:
            vx = -THROW_POWER_UP*0.5f;  // 약간 위로 띄우기
            vx= -THROW_POWER_X;        // 왼쪽으로
            break;
        case Right:
            vx = -THROW_POWER_UP*0.5f;  // 약간 위로 띄우기
            vx = THROW_POWER_X;          // 오른쪽으로
            break;
    }


    // --- 手の位置から飛び出す ---
    int pw = ch->rect.w;
    int ow = obj->rect.w;
    float start_x = ch->point.x + (pw - ow) / 2.0f;
    float start_y = ch->point.y - obj->rect.h - 60.0f;

    obj->point.x = start_x;
    obj->point.y = start_y;
    obj->rect.x = (int)start_x;
    obj->rect.y = (int)start_y;

    // 物理初速をセット（ここが一番大事）
    obj->vel.x = vx;
    obj->vel.y = vy;

    // 상태를 Fly로 
    if (obj->type == CT_COIN) {
        obj->stts = CS_Fly;
    }else if (obj->type >= CT_PLAYER0 && obj->type <= CT_PLAYER3) {
        obj->stts = CS_Fly;     
        obj->hp =3;   
    }

    // 플레이어 hold 해제
    if(obj->type ==CT_COIN){
        if(obj->stts !=CS_Fly){
            obj->holder = NULL;
        }
    }else{
       obj->holder = NULL; 
    }
    
    ch->holdTarget = NULL;
    ch->hold = 0;

    obj->whoholder = 0;
    
    

    // ---- 着地地点（あなたの条件） ----
   float baseY = ch->point.y + (3 * ch->rect.h);


    printf("ch rect y %d  rect h %d\n" , ch->rect.y , ch->rect.h);
    printf("base Y %f   \n" , baseY);

    switch (ch->playerdir) {
        case Up:    obj->throwLandY = baseY - 240.0f; break;
        case Down:  obj->throwLandY = baseY + 140.0f; break;
        case Left:
        case Right:
            obj->throwLandY = baseY -10;     
            break;
        default:
            obj->throwLandY = baseY;     break;
    }

    printf("ThrowObject: start=(%.1f,%.1f) vel=(%.1f,%.1f) targetY=%.1f\n",
        obj->point.x, obj->point.y, obj->vel.x, obj->vel.y, obj->throwLandY);


}





#define TRAIN_START_X   -25000.0f
#define TRAIN_END_X     5000.0f
#define TRAIN_SPEED     0.0f        // 速度 3200.0f  ここ使われてなかった
#define TRAIN_INTERVAL  60000          //1分ごとに入って来る 60000  

void TrainMovement(CharaInfo *ch, long long cur)
{
    // 移動状態
    enum {
        TRAIN_STATE_MOVING,
        TRAIN_STATE_DECEL,
        TRAIN_STATE_STOPPED,
        TRAIN_STATE_ACCEL
    };
    static int state = TRAIN_STATE_MOVING;
    
    // 時間保存
    static long long stopEndTime = 0;

    //-----------------------------------------
    // パラメータ
    //-----------------------------------------
    const float decelPoint = 550.0f;     // 目標停車位置
    const float stopDuration = 15000;    // 15秒
    const float maxSpeed = 0.0f;      // 最高速度 1600がもとの値
    const float minSpeed = 50.0f;        // ほぼ停止速度
    const float decelDist = 2000.0f;     // 減速区間 長さ(px)
    const float accelDist = 2000.0f;     // 加速区間 長さ(px)

    float dt = TICK_MS / 1000.0f;

    //-----------------------------------------
    // 1) 右に移動 
    //-----------------------------------------
    if (state == TRAIN_STATE_MOVING)
    {
        ch->point.x += maxSpeed * dt;

        // 減速開始地点に到達
        if (ch->point.x >= decelPoint - decelDist)
            state = TRAIN_STATE_DECEL;

        return;
    }

    //-----------------------------------------
    // 2)減速
    //-----------------------------------------
    if (state == TRAIN_STATE_DECEL)
    {
        float distToStop = decelPoint - ch->point.x;
        if (distToStop < 0) distToStop = 0;

        // 0~1
        float t = distToStop / decelDist;
        if (t < 0) t = 0;
        if (t > 1) t = 1;

        float speed = minSpeed + t * (maxSpeed - minSpeed);
        ch->point.x += speed * dt;

        // 停車地点到着
        if (ch->point.x >= decelPoint)
        {
            ch->point.x = decelPoint;
            stopEndTime = cur + (long long)stopDuration;
            state = TRAIN_STATE_STOPPED;
        }

        return;
    }

    //-----------------------------------------
    // 3) 停車(15秒待ち)
    //-----------------------------------------
    if (state == TRAIN_STATE_STOPPED)
    {
        long long remain = stopEndTime - cur;
        TrapHumanSpeed = 0;
        //到着→ドアが開く
        if (remain <= stopDuration && remain > stopDuration - 2000) {
            ch->movestts = ANI_TrainDoorOPEN;
            traindoor = 1;
        }
        // 出発2秒前→ドアを閉める
        else if (remain <= 2000 && remain > 0) {
            ch->movestts = ANI_TrainDoorCLOSE;
            traindoor = 0;
        }

        // 停車時間切れ→ACCELに切り替え
        if (cur >= stopEndTime) {
            state = TRAIN_STATE_ACCEL;
            
        }
        return;
    }
    
    //----------------------------------------- 
    // 4) 加速
    //-----------------------------------------
    if (state == TRAIN_STATE_ACCEL)
    {
        float distFromStop = ch->point.x - decelPoint;
        if (distFromStop < 0) distFromStop = 0;

        float t = distFromStop / accelDist;
        if (t > 1) t = 1;

        float speed = minSpeed + t * (maxSpeed - minSpeed);
        ch->point.x += speed * dt;
        TrapHumanSpeed = speed * dt;

        if (ch->point.x >= TRAIN_END_X)
        {
            ch->point.x = TRAIN_START_X;
            state = TRAIN_STATE_MOVING;
        }

        return;
    }
}


void TrapInTrain(CharaInfo* ch)
{
    ch->point.x += TrapHumanSpeed;

    if (ch->point.y < 500) ch->point.y = 500;
    if (ch->point.y > 530) ch->point.y = 530;
}


int PrintError(const char* msg)
{
    fprintf(stderr, "Error: %s\n", msg);
    return -1;
}

//=================================================
//自販機
//コインが投げられると投げたプレイヤーが加点される
//=================================================
//void Vendor(CharaInfo* p, CharaInfo* q){

//コインをｑで指すように並べ替える
//if(p->type==CT_COIN && q->type==CT_Vendor){
//    CharaInfo* tmp;
//    tmp = p;
//    p = q;
//    q = p;
//}

//q->holder->score++; //最後に持ったプレイヤーのスコアが増える


//}