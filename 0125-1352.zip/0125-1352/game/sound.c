#include<SDL2/SDL_mixer.h>
#include<stdio.h>
#include<stdlib.h>
#include"game.h"

extern int my_id;
extern CharaInfo *gCharaHead;

void InitAudio(void)//0124追加
{
    if(SDL_Init(SDL_INIT_AUDIO) < 0){
        PrintError("failed to SDL_Init\n");
        return;
    }

    if(Mix_Init(MIX_INIT_MP3) == 0){
        PrintError("failed to Mix_Init\n");
        return;
    }

    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT, 2, 1024) == -1){
        PrintError("failed to Mix_OpenAudio\n");
        return;
    }

    return;
} 

typedef enum{
    SE_Throw,
    SE_KnockDown,
    SE_Spin
} SE_Type;



//効果音の読み込み（クライアント）
void InitSound_Load(GameInfo *gGame){
    //gGame->SE_Load[Attack] = Mix_LoadWAV("");
    gGame->SE_Load[SE_Throw] = Mix_LoadWAV("sound/Motion-Swish06-1.wav");
    gGame->SE_Load[SE_KnockDown] = Mix_LoadWAV("sound/dizze.wav");
    gGame->SE_Load[SE_Spin] = Mix_LoadWAV("sound/big-explosion-1.wav");
    
}

//===================================================
//キャラクタのmovesttsの値が変わると効果音を再生する
//===================================================
void PlayAudio(GameInfo *gGame){
    CharaInfo *myplayer = GetPlayerChara(my_id);//自分の情報

    for(CharaInfo *ch = gCharaHead; ch; ch = ch->next){
        
        //前の状態と同じなら再生しない
        if(ch->movestts == ch->audio_state.beforeMovestts)
            continue;

    //==============
    //再生する場合
    //=============
        //再生されている効果音を止める
        if(ch->audio_state.chanel != -1){//再生されている場合
            Mix_HaltChannel(ch->audio_state.chanel);
            ch->audio_state.chanel = -1;
        } 

        int kindofSE = GetSE(ch);

        //対応する効果音があれば再生する
        if(kindofSE != -1){
            ch->audio_state.chanel = Mix_PlayChannel(-1, gGame->SE_Load[kindofSE], 0);
        }

        //現在のmovesttsを保存
        ch->audio_state.beforeMovestts = ch->movestts;
        
        //距離に応じた音量の調整
        UpdateVolume(myplayer,ch);
    }
}

//===============================
//movesttsに対応する効果音を返す
//===============================
int GetSE(CharaInfo *ch){
    switch(ch->movestts){
        /*
            case ANI_RightAttack:
            case ANI_LeftAttack:
            case ANI_DownAttack:
            case ANI_UpAttack:
                return SE_Attack;
                break;
            case ANI_TrainDoorCLOSE:
            case ANI_TrainDoorOPEN:
                return SE_Train_Door;
                break;
            case ANI_ATM_LIGHTOFF_VIBRATE:
                return SE_ATM_Shake;
                break;
            case ANI_VENDER_PUMP:
                return SE_CointoVendor;
                break;
            case ANI_HIT_RIGHT:
            case ANI_HIT_LEFT:
            case ANI_HIT_DOWN:
            case ANI_HIT_UP:
                break;*/
            case ANI_KNOCKDOWN:
                return SE_KnockDown;
                break;
            case ANI_RAISE_RIGHT:
            case ANI_RAISE_LEFT:
            case ANI_RAISE_DOWN:
            case ANI_RAISE_UP:
                return SE_Throw;
                break;
            case ANI_SPIN:
                return SE_Spin;
                break;
            default:
                return -1;
                break;
        }
}

//=================================================
//操作プレイヤーと音源の距離に応じて音量を調整する
//=================================================
#define MAXDistance 1920 //全画面表示のときの画面端まで

void UpdateVolume(CharaInfo *myplayer, CharaInfo *sound_sorce)
{

    //再生していない場合
    if(sound_sorce->audio_state.chanel == -1)
        return;

//距離に応じて音量を調整する
    //音源と自分の距離を計算（x軸のみ）
    float d_x = myplayer->point.x - sound_sorce->point.x;
    float distance = fabsf(d_x);//絶対値

    float scale = 1.0f - distance / MAXDistance;
    if(scale < 0)
        scale = 0;

    int SoundVolume = (int)(MIX_MAX_VOLUME *scale);

//自分の音は最大にする
    if(sound_sorce == myplayer)
        SoundVolume = MIX_MAX_VOLUME;

    Mix_Volume(sound_sorce->audio_state.chanel, SoundVolume);//距離に応じた音量に設定
} 


void CloseAudio(void){

    Mix_CloseAudio();
    Mix_Quit();
}


//SoundInfoの初期化（サーバ）
//void InitSoundInfo(GameInfo *gGame){
    //全部0で初期化
//    for(int i = 0; i < MAX_SE_NUMBER; i++){
//        gGame->SE_Info[i].PlayerID = 0;//初期化できてないかも
//       gGame->SE_Info[i].x = 0;
//    }
    //動かないやつの座標を代入
//    for(CharaInfo *ch = ServergCharaHead; ch; ch->next){
//        switch(ch->type){
//            case CT_ATM:
//                gGame->SE_Info[ATM_Shake].x = ch->point.x;
//                break;
//            case CT_Vendor:
//                gGame->SE_Info[CointoVendor].x = ch->point.x;
//                break;
//        }
//    }
//}

//扱いやすいように関数化しました(サーバで使いたい)
//void PlaySound_Server(GameInfo *gGame, int event, int playerID){ //引数：イベント、なるやつ、myid
//gGame->SE_Info[event].PlayerID = playerID;

//動くやつ
 /*   for(CharaInfo *ch = ServergCharaHead; ch; ch->next){
        switch(ch->type){
            case CT_TRAIN:
                gGame->SE_Info[Train_Moving].x = ch->point.x;
                gGame->SE_Info[Train_Door].x = ch->point.x;
                break;

            case CT_IMG:
                gGame->SE_Info[Shinkansen_Moving].x = ch->point.x;
                break; 
            case CT_Lever:
                gGame->SE_Info[EmergencyButton].x = ch->point.x;
                break;
            default:
            break;
        }
               
    }

}*/



//効果音を鳴らす（クライアント）
//#define MAXDistance 1920 / 2 //全画面表示のときの画面端まで
//void PlaySound_Client(GameInfo *gGame, SoundInfo *SE_Info){

//    CharaInfo *myplayer = GetPlayerChara(my_id);//自分の情報

//空いているチャンネルを取得
//    int ChunkChunel = Mix_PlayChannel(-1, gGame->SE_Load[SE_Info->event], 0);
//    if(ChunkChunel == -1) return;

//音と自分の距離を計算（x軸のみ）
//    float d_x = myplayer->point.x - SE_Info->x;
//    float distance = abs(d_x);//絶対値

//距離に応じて音量を調整する
//    float scale = 1.0f - distance / MAXDistance;
//    if(scale < 0)
//        scale = 0;

//    int SoundVolume = (int)(MIX_MAX_VOLUME *scale);

//自分の音は最大
//    if(SE_Info->playerID == my_id)
//        SoundVolume = MIX_MAX_VOLUME;//音源の最大音量

//    Mix_Volume(ChunkChunel ,SoundVolume);//距離に応じた音量に設定
//}
