

// =============================================================
// simplified_client_fixed.c
// =============================================================


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/tcp.h>
#include "game.h"


#define PORT 5000
#define MAX_CLIENT 4


typedef struct { float x,y; } NetPos;


int my_id, sock;
NetPos latest[MAX_CLIENT];
pthread_mutex_t pm = PTHREAD_MUTEX_INITIALIZER;




extern CharaInfo *gCharaHead; // これがgame.cで定義されていることを確認


ssize_t writen(int fd,const void*buf,size_t n){
size_t l=n;
const char*p=buf;
while(l>0){
ssize_t w=write(fd,p,l);
if(w<=0) return -1;
l-=w;
p+=w;
}
return n;
}


// Non-blocking, accumulate-and-process recv loop
void *RecvLoop(void *a){
const size_t PACKSZ = sizeof(NetPos) * MAX_CLIENT;
unsigned char rbuf[1024]; // 충분히 큰 버퍼
size_t rpos = 0;


while (1) {
ssize_t r = read(sock, rbuf + rpos, sizeof(rbuf) - rpos);
if (r > 0) {
rpos += (size_t)r;
// process any full packets
while (rpos >= PACKSZ) {
pthread_mutex_lock(&pm);
memcpy(latest, rbuf, PACKSZ);
pthread_mutex_unlock(&pm);
// shift remainder
size_t remain = rpos - PACKSZ;
if (remain > 0) memmove(rbuf, rbuf + PACKSZ, remain);
rpos = remain;
}
continue;
}
else if (r == 0) {
// server closed
printf("server closed\n");
break;
}
else { // r < 0
if (errno == EAGAIN || errno == EWOULDBLOCK) {
// no data currently
usleep(1000);
continue;
}
else {
perror("recv error");
break;
}
}