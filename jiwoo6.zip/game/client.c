#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <netinet/tcp.h>
#include "net.h"
#include "game.h"
#include <math.h>


#define PORT 5000
int my_id, sock;
Packet latestPkt;
pthread_mutex_t pm = PTHREAD_MUTEX_INITIALIZER;

extern CharaInfo *gCharaHead;

ssize_t readn(int fd, void *buf, size_t n){
    size_t left=n; char*p=buf;
    while(left>0){
        ssize_t r=read(fd,p,left);
        if(r<=0) return (r==0?n-left:-1);
        left-=r; p+=r;
    }
    return n;
}

void *RecvLoop(void *a){
    while(1){
        Packet pkt;
        if(readn(sock,&pkt,sizeof(pkt))!=sizeof(pkt)) break;

        pthread_mutex_lock(&pm);
        latestPkt = pkt;
        pthread_mutex_unlock(&pm);
    }
    return NULL;
}

void SendInput(Keystts *input){
    ssize_t w = write(sock, input, sizeof(Keystts));
    if(w!=sizeof(Keystts)) perror("write failed");
}

Uint32 AnimCB(Uint32 i, void *p){ UpdateAnimation((GameInfo*)p,i/1000.0f); return i; }

int main(int argc,char*argv[]){
    if(argc<3){ printf("usage: <id> <server-ip>\n"); return 0; }
    my_id=atoi(argv[1]);

    InitSystem("chara.data","position.data",my_id);
    InitWindow(&gGames[my_id],"Test","bg.png",1280,720);

    for(CharaInfo*ch=gCharaHead;ch;ch=ch->next)
        if(ch->type>=CT_PLAYER0 && ch->type<CT_PLAYER0+MAX_CLIENT){
            int i=ch->type-CT_PLAYER0;
            ch->point.x = 100+i*50;
            ch->point.y = 200;
            ch->rect.x=(int)ch->point.x;
            ch->rect.y=(int)ch->point.y;
        }

    sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in sv={0};
    sv.sin_family=AF_INET;
    sv.sin_port=htons(PORT);
    inet_pton(AF_INET, argv[2], &sv.sin_addr);
    connect(sock,(struct sockaddr*)&sv,sizeof(sv));

    int flag=1; setsockopt(sock,IPPROTO_TCP,TCP_NODELAY,&flag,sizeof(flag));

    pthread_t th; pthread_create(&th,NULL,RecvLoop,NULL);

    SDL_AddTimer(16,AnimCB,&gGames[my_id]);

    Uint32 last=SDL_GetTicks();
    SDL_bool run=SDL_TRUE;
    while(run){
        Uint32 now=SDL_GetTicks();
        gGames[my_id].timeDelta=(now-last)/1000.0f;
        last=now;

        run = InputEvent(&gGames[my_id]);
        SendInput(&gGames[my_id].input);

        // 서버 보간
        pthread_mutex_lock(&pm);
        CharaInfo *ch=gCharaHead;
        for(int i=0;i<MAX_CLIENT && ch;i++,ch=ch->next){
            float dx=latestPkt.pos[i].x - ch->point.x;
            float dy=latestPkt.pos[i].y - ch->point.y;
            float dist = sqrtf(dx*dx+dy*dy);
            if(dist>50.0f) printf("[WARN] teleport jump player %d: %.2f\n", i, dist);

            float t=0.3f;
            ch->point.x += dx*t; ch->point.y += dy*t;
            ch->rect.x=(int)ch->point.x; ch->rect.y=(int)ch->point.y;
        }
        pthread_mutex_unlock(&pm);

        DrawGame(&gGames[my_id]);
        SDL_Delay(8);
    }

    CloseWindow(&gGames[my_id]);
    DestroySystem();
    close(sock);
    return 0;
}
