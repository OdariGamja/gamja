#ifndef GAME_NET_H
#define GAME_NET_H

#include <stdint.h>
#include "game.h"

#define MAX_CLIENT 4

typedef struct { float x, y; } NetPos;

// 서버에서 보내는 패킷 (tick 단위)
typedef struct {
    uint32_t tick;          // tick 번호
    NetPos pos[MAX_CLIENT]; // 플레이어 위치
} Packet;

#endif
