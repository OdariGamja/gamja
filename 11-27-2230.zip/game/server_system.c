// system_server.c
#include "server_system.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL2/SDL.h>


CharaInfo* SevergCharaHead = NULL;
//初期化
int InitServerChara(const char* position_data_file, CharaInfo players[], int max_players)
{
    int ret = 0;
    SevergCharaHead = NULL;

    FILE* fp = fopen(position_data_file, "r");
    if (!fp) return PrintError("failed to open position data file.");

    char linebuf[MAX_LINEBUF];

    while (fgets(linebuf, MAX_LINEBUF, fp)) {
        if (linebuf[0] == '#') continue;

        unsigned int type;
        float px, py;
        int rx, ry, rw, rh;

        if (7 != sscanf(linebuf, "%u%f%f%d%d%d%d", &type, &px, &py, &rx, &ry, &rw, &rh)) {
            PrintError("failed to parse line in position data");
            continue;
        }

        if (type >= CT_PLAYER0 && type < CT_PLAYER0 + max_players) {
            // プレイヤーの初期化
            int i = type - CT_PLAYER0;
            players[i].type = type;
            players[i].point.x = px;
            players[i].point.y = py;
            players[i].rect.x = (int)px;
            players[i].rect.y = (int)py;
            players[i].rect.w = rw;
            players[i].rect.h = rh;
            players[i].Baserect.w = rw;
            players[i].Baserect.h = rh;
            players[i].stts = CS_Normal;
            memset(&players[i].input, 0, sizeof(players[i].input));

            // linked list に追加
            players[i].next = SevergCharaHead;
            SevergCharaHead = &players[i];

        } else {
            // その他のNPCなど
            CharaInfo* ch = malloc(sizeof(CharaInfo));
            if (!ch) { ret = PrintError("failed to allocate NPC"); break; }

            ch->type = type;
            ch->point.x = px;
            ch->point.y = py;
            ch->rect.x = (int)px;
            ch->rect.y = (int)py;
            ch->rect.w = rw;
            ch->rect.h = rh;
            ch->Baserect.w = rw;
            ch->Baserect.h = rh;
            ch->stts = CS_Normal;
            ch->vel.x = ch->vel.y = 0;
            ch->ani.x = 0;
            ch->entity = NULL; // サーバーでは画像不要
            ch->coinRespawnTime = 0;

            // linked list に追加
            ch->next = SevergCharaHead;
            SevergCharaHead = ch;
        }
    }

    fclose(fp);
    return ret;
}


//y軸値によるスケール値をrectにも適用
void UpdateScaleServer(CharaInfo* ch)
{
    float yMin = 500.0f;
    float yMax = 800.0f;
    float scaleMin = 1.0f;  
    float scaleMax = 1.8f;   

    float py = ch->point.y + ch->rect.h / 2;

    float t = (py - yMin) / (yMax - yMin);
    if (t < 0) t = 0;
    if (t > 1) t = 1;

    float scale = scaleMax - t * (scaleMax - scaleMin);

    ch->rect.w = (int)(ch->Baserect.w / scale);
    ch->rect.h = (int)(ch->Baserect.h / scale);
}

void AddScore(CharaInfo* ch, int event)
{
    switch(event){
        case 1: // コイン取得
            ch->score += 100;  // スコア+1
            printf("Score Up! Player %d → score=%d\n",
                ch->type - CT_PLAYER0, ch->score);
            break;
    }
}



//プレイヤー同士の当たり判定処理
SDL_bool CollisionPlayer(CharaInfo* a, CharaInfo* b)
{
    if (a->stts == CS_Disable || b->stts == CS_Disable) return SDL_FALSE;

    SDL_Rect ra = a->rect;
    SDL_Rect rb = b->rect;
    SDL_Rect ir;
    if (!SDL_IntersectRect(&ra, &rb, &ir)) return SDL_FALSE;
    int overlapW = ir.w;
    int overlapH = ir.h;

    float ax = a->point.x + a->rect.w / 2.0f;
    float ay = a->point.y + a->rect.h / 2.0f;
    float bx = b->point.x + b->rect.w / 2.0f;
    float by = b->point.y + b->rect.h / 2.0f;

    float dx = ax - bx;
    float dy = ay - by;

    if (overlapW < overlapH) {
        float push = overlapW / 2.0f;
        a->point.x += (dx > 0 ? push : -push);
        b->point.x -= (dx > 0 ? push : -push);
    } else {
        float push = overlapH / 2.0f;
        a->point.y += (dy > 0 ? push : -push);
        b->point.y -= (dy > 0 ? push : -push);
    }

    // 移動制限
    if (a->point.x < 0) a->point.x = 0;
    if (a->point.y < 0) a->point.y = 0;
    if (a->point.x + a->rect.w > MAP_Width) a->point.x = MAP_Width - a->rect.w;
    if (a->point.y + a->rect.h > MAP_Height) a->point.y = MAP_Height - a->rect.h;

    if (b->point.x < 0) b->point.x = 0;
    if (b->point.y < 0) b->point.y = 0;
    if (b->point.x + b->rect.w > MAP_Width) b->point.x = MAP_Width - b->rect.w;
    if (b->point.y + b->rect.h > MAP_Height) b->point.y = MAP_Height - b->rect.h;

    a->rect.x = (int)a->point.x;
    a->rect.y = (int)a->point.y;
    b->rect.x = (int)b->point.x;
    b->rect.y = (int)b->point.y;

    return SDL_TRUE;
}

//当たり判定
SDL_bool Collision(CharaInfo* ci, CharaInfo* cj)
{
    if (ci->stts == CS_Disable || cj->stts == CS_Disable) 
        return SDL_FALSE;

    SDL_Rect ir;
    if (!SDL_IntersectRect(&(ci->rect), &(cj->rect), &ir)) 
        return SDL_FALSE;

    if ((ci->type >= CT_PLAYER0 && ci->type <= CT_PLAYER3) &&
        (cj->type >= CT_PLAYER0 && cj->type <= CT_PLAYER3)){
        CollisionPlayer(ci, cj);   
    }


    // プレイヤーとコイン
    if ((ci->type >= CT_PLAYER0 && ci->type <= CT_PLAYER3) && cj->type == CT_COIN) {
        if (cj->stts == CS_Normal) {
            printf("Player %d collected a coin!\n", ci->type - CT_PLAYER0);
            cj->stts = CS_Disable;                    // コイン非表示
            cj->coinRespawnTime = now_ms() + 5000;   // 5秒後に再出現
           AddScore(ci, 1);    // コイン取得でスコア加算

        }
        return SDL_TRUE;
    } 
    else if ((cj->type >= CT_PLAYER0 && cj->type <= CT_PLAYER3) && ci->type == CT_COIN) {
        if (ci->stts == CS_Normal) {
            printf("Player %d collected a coin!\n", cj->type - CT_PLAYER0);
            ci->stts = CS_Disable;
            ci->coinRespawnTime = now_ms() + 5000;
            AddScore(cj, 1);    //  コイン取得でスコア加算

        }
        return SDL_TRUE;
    }
    
    return SDL_FALSE;
}

int PrintError(const char* msg)
{
    fprintf(stderr, "Error: %s\n", msg);
    return -1;
}
