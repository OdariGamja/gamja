// system_server.c
#include "server_system.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <sys/time.h>

CharaInfo* SevergCharaHead = NULL;
void UpdateAttackRects(CharaInfo* ch)//攻撃判定の範囲更新、色々合って初期化も兼ねてる
{
    int w = ch->rect.w;
    int h = ch->rect.h;

    // 上
    ch->attackrectUp.x = ch->rect.x;
    ch->attackrectUp.y = ch->rect.y - h;
    ch->attackrectUp.w = w;
    ch->attackrectUp.h = h;

    // 下
    ch->attackrectDown.x = ch->rect.x;
    ch->attackrectDown.y = ch->rect.y + ch->rect.h;
    ch->attackrectDown.w = w;
    ch->attackrectDown.h = h;

    // 左
    ch->attackrectLeft.x = ch->rect.x - w;
    ch->attackrectLeft.y = ch->rect.y;
    ch->attackrectLeft.w = w;
    ch->attackrectLeft.h = h;

    // 右
    ch->attackrectRight.x = ch->rect.x + ch->rect.w;
    ch->attackrectRight.y = ch->rect.y;
    ch->attackrectRight.w = w;
    ch->attackrectRight.h = h;
}

//初期化
int InitServerChara(const char* position_data_file, CharaInfo players[], int max_players)
{
    int ret = 0;
    SevergCharaHead = NULL;

    FILE* fp = fopen(position_data_file, "r");
    if (!fp) return PrintError("failed to open position data file.");

    char linebuf[MAX_LINEBUF];

    while (fgets(linebuf, MAX_LINEBUF, fp)) {
        if (linebuf[0] == '#') continue;

        unsigned int type;
        float px, py;
        int rx, ry, rw, rh;
         

        if (7 != sscanf(linebuf, "%u%f%f%d%d%d%d", &type, &px, &py, &rx, &ry, &rw, &rh)) {
            PrintError("failed to parse line in position data");
            continue;
        }

        if (type >= CT_PLAYER0 && type < CT_PLAYER0 + max_players) {
            // プレイヤーの初期化
            int i = type - CT_PLAYER0;
         
            players[i].type = type;
            players[i].point.x = px;
            players[i].point.y = py;
            players[i].rect.x = (int)px;
            players[i].rect.y = 150 + (int)py;
            players[i].rect.w = rw;
            players[i].rect.h = rh;
            players[i].Baserect.w = rw;
            players[i].Baserect.h = rh;
            players[i].playerdir = Down;
            players[i].stts = CS_Normal;
            players[i].movestts = ANI_Stop;
            memset(&players[i].input, 0, sizeof(players[i].input));
            UpdateAttackRects(&players[i]);

            // linked list に追加
            players[i].next = SevergCharaHead;
            SevergCharaHead = &players[i];

        } else {
            // その他のNPCなど
            CharaInfo* ch = malloc(sizeof(CharaInfo));
            if (!ch) { ret = PrintError("failed to allocate NPC"); break; }

            ch->type = type;
            ch->point.x = px;
            ch->point.y = py;
            ch->rect.x = (int)px;
            ch->rect.y = (int)py;
            ch->rect.w = rw;
            ch->rect.h = rh;
            ch->Baserect.w = rw;
            ch->Baserect.h = rh;
            ch->stts = CS_Normal;
            ch->vel.x = ch->vel.y = 0;
            ch->ani.x = 0;
            ch->entity = NULL; // サーバーでは画像不要
            ch->coinRespawnTime = 0;
            ch->hp=0;
            if(ch->type == CT_MOUSE){
                ch->hp=5;
            }

            // linked list に追加
            ch->next = SevergCharaHead;
            SevergCharaHead = ch;
        }
    }

    fclose(fp);
    return ret;
}


//y軸値によるスケール値をrectにも適用
void UpdateScaleServer(CharaInfo* ch)
{
    float yMin = 500.0f;
    float yMax = 800.0f;
    float scaleMin = 1.0f;  
    float scaleMax = 1.8f;   

    float py = ch->point.y + ch->rect.h / 2;

    float t = (py - yMin) / (yMax - yMin);
    if (t < 0) t = 0;
    if (t > 1) t = 1;

    float scale = scaleMax - t * (scaleMax - scaleMin);

    ch->rect.w = (int)(ch->Baserect.w / scale);
    ch->rect.h = (int)(ch->Baserect.h / scale);
}

void AddScore(CharaInfo* ch, int event)
{
    switch(event){
        case 1: // コイン取得
            ch->score += 100;  // スコア+1
            printf("Score Up! Player %d → score=%d\n",
                ch->type - CT_PLAYER0, ch->score);
            break;
    }
}

void Attack(CharaInfo* ch) //攻撃処理　
{
    SDL_Rect* atk = NULL;
    if (ch->playerdir == Up)    atk = &ch->attackrectUp;
    if (ch->playerdir == Down)  atk = &ch->attackrectDown;
    if (ch->playerdir == Left)  atk = &ch->attackrectLeft;
    if (ch->playerdir == Right) atk = &ch->attackrectRight;

    if (!atk) return;

    const float knockbackPower = 100.0f;   // ← ノックバック量

    for (CharaInfo* target = SevergCharaHead; target; target = target->next) {

        if (target == ch) continue;
        if (target->stts != CS_Normal) continue;

        if (target->type == CT_MOUSE) {

            if (SDL_HasIntersection(atk, &target->rect)) {

                printf("Attack hit! target=%d\n", target->type);

                // ダメージ
                target->hp -= 1;

                //ノックバック
                switch (ch->playerdir) {
                case Up:
                    target->point.y -= knockbackPower;
                    break;
                case Down:
                    target->point.y += knockbackPower;
                    break;
                case Left:
                    target->point.x -= knockbackPower;
                    break;
                case Right:
                    target->point.x += knockbackPower;
                    break;
                }

                // rect 更新（プレイヤー以外はそのまま）
                target->rect.x = (int)target->point.x;
                target->rect.y = (int)target->point.y;
                UpdateAttackRects(target);

                // 倒されたかチェック
                if (target->hp <= 0) {
                    target->stts = CS_Disable;
                    printf("Enemy %d defeated!\n", target->type);
                }
            }
        }
    }
}



//プレイヤー同士の当たり判定処理
SDL_bool CollisionPlayer(CharaInfo* a, CharaInfo* b)
{
    if (a->stts == CS_Disable || b->stts == CS_Disable) return SDL_FALSE;

    SDL_Rect ra = a->rect;
    SDL_Rect rb = b->rect;
    SDL_Rect ir;
    if (!SDL_IntersectRect(&ra, &rb, &ir)) return SDL_FALSE;
    int overlapW = ir.w;
    int overlapH = ir.h;

    float ax = a->point.x + a->rect.w / 2.0f;
    float ay = a->point.y + a->rect.h / 2.0f;
    float bx = b->point.x + b->rect.w / 2.0f;
    float by = b->point.y + b->rect.h / 2.0f;

    float dx = ax - bx;
    float dy = ay - by;

    if (overlapW < overlapH) {
        float push = overlapW / 2.0f;
        a->point.x += (dx > 0 ? push : -push);
        b->point.x -= (dx > 0 ? push : -push);
    } else {
        float push = overlapH / 2.0f;
        a->point.y += (dy > 0 ? push : -push);
        b->point.y -= (dy > 0 ? push : -push);
    }

    // 移動制限
    if (a->point.x < 0) a->point.x = 0;
    if (a->point.y < 0) a->point.y = 0;
    if (a->point.x + a->rect.w > MAP_Width) a->point.x = MAP_Width - a->rect.w;
    if (a->point.y + a->rect.h > MAP_Height) a->point.y = MAP_Height - a->rect.h;

    if (b->point.x < 0) b->point.x = 0;
    if (b->point.y < 0) b->point.y = 0;
    if (b->point.x + b->rect.w > MAP_Width) b->point.x = MAP_Width - b->rect.w;
    if (b->point.y + b->rect.h > MAP_Height) b->point.y = MAP_Height - b->rect.h;

   // rect の更新（プレイヤーだけ y を +150）
if (a->type >=CT_PLAYER0 && a->type <= CT_PLAYER3) {
    a->rect.x = (int)a->point.x;
    a->rect.y = 150 + (int)a->point.y;
} else {
    a->rect.x = (int)a->point.x;
    a->rect.y = (int)a->point.y;
}

if (b->type >=CT_PLAYER0 && b->type <= CT_PLAYER3) {
    b->rect.x = (int)b->point.x;
    b->rect.y = 150 + (int)b->point.y;
} else {
    b->rect.x = (int)b->point.x;
    b->rect.y = (int)b->point.y;
}

UpdateAttackRects(a);
UpdateAttackRects(b);


    return SDL_TRUE;
}

//当たり判定
SDL_bool Collision(CharaInfo* ci, CharaInfo* cj)
{
    if (ci->stts == CS_Disable || cj->stts == CS_Disable) 
        return SDL_FALSE;

    SDL_Rect ir;
    if (!SDL_IntersectRect(&(ci->rect), &(cj->rect), &ir)) 
        return SDL_FALSE;

    if ((ci->type >= CT_PLAYER0 && ci->type <= CT_PLAYER3) &&
        (cj->type >= CT_PLAYER0 && cj->type <= CT_PLAYER3)){
        CollisionPlayer(ci, cj);   
    }

    if (((ci->type >= CT_PLAYER0 && ci->type <= CT_PLAYER3 )&& cj->type == CT_MOUSE) ||
        ((cj->type >= CT_PLAYER0 && cj->type <= CT_PLAYER3 )&& ci->type == CT_MOUSE))
    {
         CollisionPlayer(ci, cj);   
    }

     // プレイヤーとコイン
    if ((ci->type >= CT_PLAYER0 && ci->type <= CT_PLAYER3) && cj->type ==  CT_MOUSE) {
        if (cj->stts == CS_Normal) {
       CollisionPlayer(ci, cj);   
        }
        return SDL_TRUE;
    } 
    else if ((cj->type >= CT_PLAYER0 && cj->type <= CT_PLAYER3) && ci->type ==  CT_MOUSE) {
        if (ci->stts == CS_Normal) {
      CollisionPlayer(ci, cj);   
        }
        return SDL_TRUE;
    }


    // プレイヤーとコイン
    if ((ci->type >= CT_PLAYER0 && ci->type <= CT_PLAYER3) && cj->type == CT_COIN) {
        if (cj->stts == CS_Normal) {
            printf("Player %d collected a coin!\n", ci->type - CT_PLAYER0);
            cj->stts = CS_Disable;                    // コイン非表示
            cj->coinRespawnTime = now_ms() + 5000;   // 5秒後に再出現
           AddScore(ci, 1);    // コイン取得でスコア加算

        }
        return SDL_TRUE;
    } 
    else if ((cj->type >= CT_PLAYER0 && cj->type <= CT_PLAYER3) && ci->type == CT_COIN) {
        if (ci->stts == CS_Normal) {
            printf("Player %d collected a coin!\n", cj->type - CT_PLAYER0);
            ci->stts = CS_Disable;
            ci->coinRespawnTime = now_ms() + 5000;
            AddScore(cj, 1);    //  コイン取得でスコア加算

        }
        return SDL_TRUE;
    }
    
    return SDL_FALSE;
}




#define TRAIN_START_X   -25000.0f
#define TRAIN_END_X     15000.0f
#define TRAIN_SPEED     3200.0f        // 速度
#define TRAIN_INTERVAL  60000          //1分ごとに入って来る

void TrainMovement(CharaInfo *ch, long long cur)
{
    // 移動状態
    enum {
        TRAIN_STATE_MOVING,
        TRAIN_STATE_DECEL,
        TRAIN_STATE_STOPPED,
        TRAIN_STATE_ACCEL
    };
    static int state = TRAIN_STATE_MOVING;

    // 時間保存
    static long long stopEndTime = 0;

    //-----------------------------------------
    // パラメータ
    //-----------------------------------------
    const float decelPoint = 550.0f;     // 目標停車位置
    const float stopDuration = 15000;    // 15秒
    const float maxSpeed = 1600.0f;      // 最高速度
    const float minSpeed = 50.0f;        // ほぼ停止速度
    const float decelDist = 2000.0f;     // 減速区間 長さ(px)
    const float accelDist = 2000.0f;     // 加速区間 長さ(px)

    float dt = TICK_MS / 1000.0f;

    //-----------------------------------------
    // 1) 右に移動 
    //-----------------------------------------
    if (state == TRAIN_STATE_MOVING)
    {
        ch->point.x += maxSpeed * dt;

        // 減速開始地点に到達
        if (ch->point.x >= decelPoint - decelDist)
            state = TRAIN_STATE_DECEL;

        return;
    }

    //-----------------------------------------
    // 2)減速
    //-----------------------------------------
    if (state == TRAIN_STATE_DECEL)
    {
        float distToStop = decelPoint - ch->point.x;
        if (distToStop < 0) distToStop = 0;

        // 0~1
        float t = distToStop / decelDist;
        if (t < 0) t = 0;
        if (t > 1) t = 1;

        float speed = minSpeed + t * (maxSpeed - minSpeed);
        ch->point.x += speed * dt;

        // 停車地点到着
        if (ch->point.x >= decelPoint)
        {
            ch->point.x = decelPoint;
            stopEndTime = cur + (long long)stopDuration;
            state = TRAIN_STATE_STOPPED;
        }

        return;
    }

    //-----------------------------------------
    // 3) 停車(15秒待ち)
    //-----------------------------------------
    if (state == TRAIN_STATE_STOPPED)
    {
        long long remain = stopEndTime - cur;

        //到着→ドアが開く
        if (remain <= stopDuration && remain > stopDuration - 2000) {
            ch->movestts = ANI_TrainDoorOPEN;
        }
        // 出発2秒前→ドアを閉める
        else if (remain <= 2000 && remain > 0) {
            ch->movestts = ANI_TrainDoorCLOSE;
        }

        // 停車時間切れ→ACCELに切り替え
        if (cur >= stopEndTime) {
            state = TRAIN_STATE_ACCEL;
        }
        return;
    }
    
    //-----------------------------------------
    // 4) 加速
    //-----------------------------------------
    if (state == TRAIN_STATE_ACCEL)
    {
        float distFromStop = ch->point.x - decelPoint;
        if (distFromStop < 0) distFromStop = 0;

        float t = distFromStop / accelDist;
        if (t > 1) t = 1;

        float speed = minSpeed + t * (maxSpeed - minSpeed);
        ch->point.x += speed * dt;

        if (ch->point.x >= TRAIN_END_X)
        {
            ch->point.x = TRAIN_START_X;
            state = TRAIN_STATE_MOVING;
        }

        return;
    }
}





int PrintError(const char* msg)
{
    fprintf(stderr, "Error: %s\n", msg);
    return -1;
}
